"""Linux server health check — SSH + robust system metrics."""
import socket, datetime, subprocess
from config_store import resolve_credentials

def check_linux(srv):
    result = {
        'id': srv['id'], 'server_name': srv.get('server_name',''),
        'environment': srv.get('environment',''), 'host': srv.get('host',''),
        'ip_address': '—',
        'status': 'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'os': '—', 'os_version': '—',
        'memory_gb': '—', 'memory_usage_pct': '—',
        'cpu_count': '—', 'cpu_load_avg': '—',
        'worst_disk': '—', 'worst_disk_pct': '—',
        'uptime': '—',
    }

    host = srv.get('host', '')
    try:   port = int(srv.get('ssh_port', 22))
    except: port = 22

    # TCP reachability + resolve actual IP
    start = datetime.datetime.now()
    try:
        sock = socket.create_connection((host, port), timeout=5)
        sock.recv(256)
        sock.close()
        result['response_ms'] = round((datetime.datetime.now()-start).total_seconds()*1000, 1)
        try:
            result['ip_address'] = socket.gethostbyname(host)
        except Exception:
            result['ip_address'] = host
    except Exception as e:
        result.update(status='critical', check_status='completed',
                      error=f'SSH port {port} unreachable: {e}')
        return result

    username, password = resolve_credentials(srv)
    key_path = srv.get('ssh_key_path', '')

    if not username:
        result.update(status='reachable', check_status='completed',
                      error='No credentials configured. Add in Settings → Credential Store.')
        return result

    try:
        import paramiko  # type: ignore

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kwargs = dict(hostname=host, port=port, username=username, timeout=15)
        if key_path:
            kwargs['key_filename'] = key_path
        elif password:
            kwargs['password'] = password
        client.connect(**kwargs)

        def run(cmd):
            try:
                _, out, err = client.exec_command(cmd, timeout=10)
                output = out.read().decode(errors='replace').strip()
                return output if output else ''
            except Exception:
                return ''

        # ── OS ────────────────────────────────────────────────────────────
        result['os'] = run("uname -s") or 'Linux'

        # OS version — try multiple sources
        os_ver = run("cat /etc/os-release 2>/dev/null | grep '^PRETTY_NAME' | cut -d= -f2 | tr -d '\"'")
        if not os_ver:
            os_ver = run("cat /etc/redhat-release 2>/dev/null || cat /etc/debian_version 2>/dev/null")
        if not os_ver:
            os_ver = run("uname -r")
        result['os_version'] = os_ver or '—'

        # ── Uptime (always in days) ────────────────────────────────────────
        uptime_raw = run("cat /proc/uptime 2>/dev/null | awk '{print $1}'")
        if uptime_raw and uptime_raw.replace('.','',1).isdigit():
            try:
                secs  = float(uptime_raw)
                days  = int(secs // 86400)
                hours = int((secs % 86400) // 3600)
                mins  = int((secs % 3600) // 60)
                result['uptime'] = f"{days}d {hours}h {mins}m" if days > 0 else f"{hours}h {mins}m"
            except Exception:
                result['uptime'] = run("uptime") or '—'
        else:
            result['uptime'] = run("uptime") or '—'

        # ── CPU ───────────────────────────────────────────────────────────
        cpu_count = run("nproc 2>/dev/null")
        if not cpu_count:
            cpu_count = run("grep -c '^processor' /proc/cpuinfo 2>/dev/null")
        result['cpu_count'] = cpu_count or '—'

        load = run("cat /proc/loadavg 2>/dev/null | awk '{print $1, $2, $3}'")
        result['cpu_load_avg'] = load or '—'

        # ── Memory — use /proc/meminfo for maximum compatibility ──────────
        meminfo = run("cat /proc/meminfo 2>/dev/null")
        if meminfo:
            mem_vals = {}
            for line in meminfo.split('\n'):
                parts = line.split()
                if len(parts) >= 2:
                    key = parts[0].rstrip(':')
                    try:
                        mem_vals[key] = int(parts[1])  # kB
                    except (ValueError, IndexError):
                        pass
            total_kb = mem_vals.get('MemTotal', 0)
            avail_kb = mem_vals.get('MemAvailable', mem_vals.get('MemFree', 0))
            if total_kb > 0:
                used_kb  = total_kb - avail_kb
                result['memory_gb'] = round(total_kb / 1048576, 1)
                result['memory_usage_pct'] = f"{round((used_kb / total_kb) * 100, 1)}%"
        else:
            # Fallback to free -m
            mem_line = run("free -m 2>/dev/null | awk '/^Mem:/{print $2, $3}'")
            if mem_line:
                parts = mem_line.split()
                if len(parts) >= 2:
                    try:
                        total_mb = int(parts[0]); used_mb = int(parts[1])
                        result['memory_gb'] = round(total_mb / 1024, 1)
                        result['memory_usage_pct'] = f"{round((used_mb / total_mb) * 100, 1)}%"
                    except (ValueError, ZeroDivisionError):
                        pass

        # ── Disk — portable df without --output flag ──────────────────────
        # "df -P" uses POSIX format: Filesystem 1024-blocks Used Available Use% Mounted
        disk_out = run("df -P 2>/dev/null | awk 'NR>1 && $6 != \"/dev\" && $6 !~ /^(\\/dev\\/sr|udev|tmpfs|devtmpfs)/ {gsub(/%/,\"\",$5); print $5, $6}' | sort -rn | head -10")
        if disk_out:
            for line in disk_out.strip().split('\n'):
                parts = line.split()
                if len(parts) >= 2:
                    try:
                        pct = float(parts[0])
                        mount = parts[1]
                        # Skip pseudo filesystems
                        if any(x in mount for x in ['/proc','/sys','/dev','/run/user']):
                            continue
                        result['worst_disk']     = mount
                        result['worst_disk_pct'] = f"{int(pct)}%"
                        break
                    except (ValueError, IndexError):
                        pass

        client.close()
        result.update(status='healthy', check_status='completed', message='SSH connected')

    except ImportError:
        result.update(status='reachable', check_status='completed',
                      error='SSH port open. Install paramiko: pip install paramiko --break-system-packages')
    except paramiko.AuthenticationException:
        result.update(status='critical', check_status='completed',
                      error='SSH authentication failed — check credentials in Credential Store')
    except Exception as e:
        result.update(status='warning', check_status='completed',
                      error=f'SSH error: {str(e)[:200]}')

    return result
