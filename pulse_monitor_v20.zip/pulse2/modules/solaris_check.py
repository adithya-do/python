"""Solaris server health check via SSH — Solaris-specific commands."""
import socket, datetime, re
from config_store import resolve_credentials

def check_solaris(srv):
    result = {
        'id': srv['id'], 'server_name': srv.get('server_name',''),
        'environment': srv.get('environment',''), 'host': srv.get('host',''),
        'ip_address': '—',
        'status': 'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'os': 'Solaris', 'os_version': '—',
        'memory_gb': '—', 'memory_usage_pct': '—',
        'cpu_count': '—', 'cpu_load_avg': '—',
        'worst_disk': '—', 'worst_disk_pct': '—',
        'uptime': '—',
    }

    host = srv.get('host', '')
    try:   port = int(srv.get('ssh_port', 22))
    except: port = 22

    start = datetime.datetime.now()
    try:
        sock = socket.create_connection((host, port), timeout=5)
        sock.recv(256)
        sock.close()
        result['response_ms'] = round((datetime.datetime.now()-start).total_seconds()*1000, 1)
        try:
            result['ip_address'] = socket.gethostbyname(host)
        except Exception:
            result['ip_address'] = host
    except Exception as e:
        result.update(status='critical', check_status='completed',
                      error=f'SSH port {port} unreachable: {e}')
        return result

    username, password = resolve_credentials(srv)
    key_path = srv.get('ssh_key_path', '')

    if not username:
        result.update(status='reachable', check_status='completed',
                      error='No credentials. Add in Settings → Credential Store.')
        return result

    try:
        import paramiko  # type: ignore

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kwargs = dict(hostname=host, port=port, username=username, timeout=15)
        if key_path:   kwargs['key_filename'] = key_path
        elif password: kwargs['password'] = password
        client.connect(**kwargs)

        def run(cmd):
            try:
                _, out, _ = client.exec_command(cmd, timeout=10)
                return out.read().decode(errors='replace').strip()
            except Exception:
                return ''

        # ── OS version ────────────────────────────────────────────────────
        uname_r = run("uname -r")   # e.g. 5.11
        result['os']         = 'Solaris'
        result['os_version'] = f"Solaris {uname_r}" if uname_r else 'Solaris'

        # ── Uptime ────────────────────────────────────────────────────────
        # /proc/uptime may exist on Solaris 11 zones; fallback to uptime cmd
        uptime_raw = run("cat /proc/uptime 2>/dev/null | awk '{print $1}'")
        if uptime_raw and uptime_raw.replace('.','',1).isdigit():
            secs  = float(uptime_raw)
            days  = int(secs // 86400)
            hours = int((secs % 86400) // 3600)
            mins  = int((secs % 3600) // 60)
            result['uptime'] = f"{days}d {hours}h {mins}m" if days > 0 else f"{hours}h {mins}m"
        else:
            ut = run("uptime 2>/dev/null")
            # Parse "X day(s), HH:MM" from uptime output
            if ut:
                result['uptime'] = ut.split(',')[0].strip()

        # ── CPU ───────────────────────────────────────────────────────────
        # psrinfo -p: number of physical processors
        ncpu = run("psrinfo 2>/dev/null | wc -l | tr -d ' '")
        if not ncpu or not ncpu.strip().isdigit():
            ncpu = run("kstat -p cpu_info:::core_id 2>/dev/null | wc -l | tr -d ' '")
        result['cpu_count'] = ncpu.strip() if ncpu and ncpu.strip().isdigit() else '—'

        # Load average from uptime
        load = run("uptime 2>/dev/null | awk -F'average:' '{print $2}' | awk '{print $1,$2,$3}' | tr -d ','")
        result['cpu_load_avg'] = load.strip() or '—'

        # ── Memory ────────────────────────────────────────────────────────
        # Method 1: prtconf for total RAM (MB)
        prtconf_out = run("prtconf 2>/dev/null | grep -i 'Memory size'")
        # Output: "Memory size: 16384 Megabytes" or "Memory size: 16 Gigabytes"
        mem_mb = None
        if prtconf_out:
            m = re.search(r'Memory size:\s*(\d+)\s*(Megabytes?|Gigabytes?|MB|GB)', prtconf_out, re.I)
            if m:
                val   = int(m.group(1))
                unit  = m.group(2).upper()
                mem_mb = val * 1024 if unit.startswith('G') else val

        if mem_mb and mem_mb > 0:
            result['memory_gb'] = round(mem_mb / 1024, 1)

            # Method 1: kstat -p for physmem and freemem (page counts)
            page_sz_str = run("pagesize 2>/dev/null")
            try:
                page_sz = int(page_sz_str) if page_sz_str and page_sz_str.isdigit() else 4096
            except Exception:
                page_sz = 4096

            physmem_str = run("kstat -p unix:0:system_pages:physmem 2>/dev/null | awk '{print $NF}'")
            freemem_str = run("kstat -p unix:0:system_pages:freemem 2>/dev/null | awk '{print $NF}'")

            if physmem_str and physmem_str.isdigit() and freemem_str and freemem_str.isdigit():
                total_bytes = int(physmem_str) * page_sz
                free_bytes  = int(freemem_str) * page_sz
                used_pct    = round((1 - free_bytes / total_bytes) * 100, 1) if total_bytes > 0 else 0
                result['memory_usage_pct'] = f"{used_pct}%"
            else:
                # Method 2: vmstat -s — "pages active" calculation
                vmstat = run("vmstat -s 2>/dev/null")
                if vmstat:
                    total_pages = free_pages = None
                    for line in vmstat.split('\n'):
                        line = line.strip()
                        if 'total memory' in line.lower() or 'memory pages' in line.lower():
                            m2 = re.search(r'(\d+)', line)
                            if m2: total_pages = int(m2.group(1))
                        elif 'free memory' in line.lower() or 'free pages' in line.lower():
                            m2 = re.search(r'(\d+)', line)
                            if m2: free_pages = int(m2.group(1))
                    if total_pages and free_pages and total_pages > 0:
                        used_pct = round((1 - free_pages / total_pages) * 100, 1)
                        result['memory_usage_pct'] = f"{used_pct}%"

        # ── Disk ──────────────────────────────────────────────────────────
        # df -k on Solaris: Filesystem kbytes used avail capacity% Mounted
        disk_out = run("df -k 2>/dev/null | awk 'NR>1 && $4~/[0-9]/ {gsub(/%/,\"\",$5); print $5, $6}' | sort -rn | head -10")
        if disk_out:
            for line in disk_out.strip().split('\n'):
                parts = line.split()
                if len(parts) >= 2:
                    try:
                        pct   = float(parts[0])
                        mount = parts[1]
                        if any(x in mount for x in ['/proc','/dev','/system','/platform']):
                            continue
                        result['worst_disk']     = mount
                        result['worst_disk_pct'] = f"{int(pct)}%"
                        break
                    except (ValueError, IndexError):
                        pass

        client.close()
        result.update(status='healthy', check_status='completed', message='SSH connected')

    except ImportError:
        result.update(status='reachable', check_status='completed',
                      error='Install paramiko: pip install paramiko --break-system-packages')
    except Exception as e:
        err = str(e)
        if 'auth' in err.lower():
            err = f'Authentication failed — check credentials in Credential Store. Detail: {err}'
        result.update(status='warning', check_status='completed', error=err[:250])

    return result
