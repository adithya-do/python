from flask import Flask, render_template, redirect, url_for, session, flash, request, jsonify
from functools import wraps
import json, os, datetime

app = Flask(__name__)
app.secret_key = os.environ.get('PULSE_SECRET_KEY', 'pulse-secret-2024-change-in-prod')

# ── In-memory user store (replace with DB in production) ──────────────────────
USERS = {
    'admin': {'password': 'admin123', 'role': 'admin', 'name': 'Administrator'},
    'user':  {'password': 'user123',  'role': 'user',  'name': 'Operator'},
}

# ── Oracle DB registry (persisted to JSON file) ───────────────────────────────
DB_FILE = os.path.join(os.path.dirname(__file__), 'oracle_databases.json')

def load_oracle_dbs():
    if os.path.exists(DB_FILE):
        with open(DB_FILE) as f:
            return json.load(f)
    return []

def save_oracle_dbs(dbs):
    with open(DB_FILE, 'w') as f:
        json.dump(dbs, f, indent=2)

# ── Auth helpers ──────────────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'username' not in session:
            flash('Please log in to access Pulse.', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))
        if session.get('role') != 'admin':
            flash('Admin privileges required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated

# ── Auth routes ───────────────────────────────────────────────────────────────
@app.route('/', methods=['GET', 'POST'])
@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = USERS.get(username)
        if user and user['password'] == password:
            session['username'] = username
            session['role'] = user['role']
            session['name'] = user['name']
            session['login_time'] = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            flash(f'Welcome back, {user["name"]}!', 'success')
            return redirect(url_for('dashboard'))
        flash('Invalid credentials. Please try again.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))

# ── Dashboard ─────────────────────────────────────────────────────────────────
@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

# ── Oracle Module ─────────────────────────────────────────────────────────────
@app.route('/oracle')
@login_required
def oracle():
    dbs = load_oracle_dbs()
    # Enrich with env-var connection status hint
    for db in dbs:
        env_key = db.get('env_var', '')
        db['env_value_set'] = bool(os.environ.get(env_key)) if env_key else False
    return render_template('oracle.html', databases=dbs)

@app.route('/oracle/check/<int:db_id>')
@login_required
def oracle_check(db_id):
    from modules.oracle_check import check_oracle
    dbs = load_oracle_dbs()
    if db_id >= len(dbs):
        return jsonify({'error': 'DB not found'}), 404
    result = check_oracle(dbs[db_id])
    return jsonify(result)

@app.route('/oracle/add', methods=['GET', 'POST'])
@admin_required
def oracle_add():
    if request.method == 'POST':
        dbs = load_oracle_dbs()
        new_db = {
            'id': len(dbs),
            'name': request.form['name'],
            'host': request.form['host'],
            'port': request.form.get('port', '1521'),
            'service': request.form['service'],
            'env_var': request.form.get('env_var', ''),
            'username_env': request.form.get('username_env', ''),
            'password_env': request.form.get('password_env', ''),
            'description': request.form.get('description', ''),
            'created': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        }
        dbs.append(new_db)
        save_oracle_dbs(dbs)
        flash(f'Oracle database "{new_db["name"]}" added.', 'success')
        return redirect(url_for('oracle'))
    return render_template('oracle_form.html', db=None, action='Add')

@app.route('/oracle/edit/<int:db_id>', methods=['GET', 'POST'])
@admin_required
def oracle_edit(db_id):
    dbs = load_oracle_dbs()
    if db_id >= len(dbs):
        flash('Database not found.', 'danger')
        return redirect(url_for('oracle'))
    if request.method == 'POST':
        dbs[db_id].update({
            'name': request.form['name'],
            'host': request.form['host'],
            'port': request.form.get('port', '1521'),
            'service': request.form['service'],
            'env_var': request.form.get('env_var', ''),
            'username_env': request.form.get('username_env', ''),
            'password_env': request.form.get('password_env', ''),
            'description': request.form.get('description', ''),
            'updated': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        })
        save_oracle_dbs(dbs)
        flash(f'Database "{dbs[db_id]["name"]}" updated.', 'success')
        return redirect(url_for('oracle'))
    return render_template('oracle_form.html', db=dbs[db_id], db_id=db_id, action='Edit')

@app.route('/oracle/delete/<int:db_id>', methods=['POST'])
@admin_required
def oracle_delete(db_id):
    dbs = load_oracle_dbs()
    if db_id < len(dbs):
        name = dbs[db_id]['name']
        dbs.pop(db_id)
        # Re-index
        for i, d in enumerate(dbs):
            d['id'] = i
        save_oracle_dbs(dbs)
        flash(f'Database "{name}" deleted.', 'success')
    return redirect(url_for('oracle'))

# ── SQL Server Module ─────────────────────────────────────────────────────────
@app.route('/sqlserver')
@login_required
def sqlserver():
    from modules.sqlserver_check import get_sqlserver_targets, check_sqlserver
    targets = get_sqlserver_targets()
    return render_template('sqlserver.html', targets=targets)

@app.route('/sqlserver/check')
@login_required
def sqlserver_check():
    from modules.sqlserver_check import get_sqlserver_targets, check_sqlserver
    host = request.args.get('host', '')
    port = int(request.args.get('port', 1433))
    result = check_sqlserver(host, port)
    return jsonify(result)

# ── Linux Servers Module ──────────────────────────────────────────────────────
@app.route('/linux')
@login_required
def linux():
    from modules.linux_check import get_linux_targets, check_linux_server
    targets = get_linux_targets()
    return render_template('linux.html', targets=targets)

@app.route('/linux/check')
@login_required
def linux_check():
    from modules.linux_check import check_linux_server
    host = request.args.get('host', '')
    result = check_linux_server(host)
    return jsonify(result)

# ── Windows Servers Module ────────────────────────────────────────────────────
@app.route('/windows')
@login_required
def windows():
    from modules.windows_check import get_windows_targets, check_windows_server
    targets = get_windows_targets()
    return render_template('windows.html', targets=targets)

@app.route('/windows/check')
@login_required
def windows_check():
    from modules.windows_check import check_windows_server
    host = request.args.get('host', '')
    result = check_windows_server(host)
    return jsonify(result)

# ── API: summary counts for dashboard ────────────────────────────────────────
@app.route('/api/summary')
@login_required
def api_summary():
    oracle_dbs = load_oracle_dbs()
    from modules.sqlserver_check import get_sqlserver_targets
    from modules.linux_check import get_linux_targets
    from modules.windows_check import get_windows_targets
    return jsonify({
        'oracle': len(oracle_dbs),
        'sqlserver': len(get_sqlserver_targets()),
        'linux': len(get_linux_targets()),
        'windows': len(get_windows_targets()),
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
