#!/bin/bash
# ── Pulse — Infrastructure Health Monitor ─────────────────────────────────────
# Startup script for Linux

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo "  ⬡ PULSE — Infrastructure Health Monitor"
echo "  ─────────────────────────────────────────"
echo ""

# Create virtualenv if needed
if [ ! -d "venv" ]; then
  echo "  Creating virtual environment..."
  python3 -m venv venv
fi

source venv/bin/activate

# Install dependencies
echo "  Installing dependencies..."
pip install -q flask

# Optional: uncomment to install Oracle / SQL Server drivers
# pip install -q cx_Oracle
# pip install -q pyodbc

echo ""
echo "  ✓ Ready. Starting Pulse on http://0.0.0.0:5000"
echo ""
echo "  Environment variables for targets:"
echo "    PULSE_LINUX_TARGETS=host1,host2"
echo "    PULSE_WINDOWS_TARGETS=host1,host2"
echo "    PULSE_SQLSERVER_TARGETS=host1:1433,host2:1433"
echo "    PULSE_SQLSERVER_USER=sa"
echo "    PULSE_SQLSERVER_PASSWORD=..."
echo ""
echo "  Oracle env vars are configured per-database in the UI."
echo ""

export FLASK_ENV=production
python app.py
