# ⬡ PULSE — Infrastructure Health Monitor

A lightweight Python/Flask web application for monitoring Oracle databases,
SQL Server instances, Linux servers, and Windows servers from a single dashboard.

---

## Quick Start (Linux)

```bash
chmod +x start.sh
./start.sh
```

Then open: **http://localhost:5000**

**Default credentials:**
| Username | Password | Role  |
|----------|----------|-------|
| admin    | admin123 | Admin |
| user     | user123  | User  |

> **Change these** in `app.py` → `USERS` dict before deploying.

---

## Environment Variables

### Server Targets

| Variable                    | Example                          | Description                        |
|-----------------------------|----------------------------------|------------------------------------|
| `PULSE_LINUX_TARGETS`       | `web01,db01,app01`               | Comma-separated Linux hostnames    |
| `PULSE_WINDOWS_TARGETS`     | `windc01,winapp01`               | Comma-separated Windows hostnames  |
| `PULSE_SQLSERVER_TARGETS`   | `sqlprod:1433,sqldev:1433`       | host:port pairs for SQL Server     |
| `PULSE_SQLSERVER_USER`      | `sa`                             | SQL Server login                   |
| `PULSE_SQLSERVER_PASSWORD`  | `MyPassword!`                    | SQL Server password                |
| `PULSE_SECRET_KEY`          | `change-me-in-production`        | Flask session secret key           |

### Oracle Databases

Oracle credentials are configured **per-database through the UI** (Admin only).
Each database entry stores the *names* of the environment variables to read at check time.

Example:
```bash
export ORACLE_PROD_USER=scott
export ORACLE_PROD_PASS=tiger
```
Then in the UI, set:
- **Username Env Var** → `ORACLE_PROD_USER`
- **Password Env Var** → `ORACLE_PROD_PASS`

---

## Features

### Authentication
- Login-protected — all routes redirect to `/login` if unauthenticated
- Two roles: **admin** (full access) and **user** (read-only)
- Session-based auth with configurable secret key

### Dashboard
- Live count of registered targets across all modules
- Quick-access cards to each monitoring module

### Oracle Module
- Admin: Add / Edit / Delete database registrations
- Connections via OS env vars (never hardcoded)
- TCP port check + cx_Oracle full connect (if installed)
- Displays Oracle version banner and SYSDATE

### SQL Server Module
- Targets from `PULSE_SQLSERVER_TARGETS` env var
- TCP port check + pyodbc full connect (if installed)
- Displays SQL Server version and current DB time

### Linux Servers
- ICMP ping + SSH port (22) TCP check
- SSH banner capture
- Response time measurement

### Windows Servers
- ICMP ping + RDP (3389) + WinRM (5985) TCP checks
- Per-port open/closed status

---

## Optional Dependencies

```bash
# Full Oracle connectivity
pip install cx_Oracle

# Full SQL Server connectivity (requires ODBC Driver 17)
pip install pyodbc
```

Without these, Pulse falls back to TCP-level checks which still give useful status.

---

## Production Deployment

```bash
# Install gunicorn
pip install gunicorn

# Run with gunicorn (4 workers)
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

Or use the included systemd service template (create as `/etc/systemd/system/pulse.service`):

```ini
[Unit]
Description=Pulse Infrastructure Monitor
After=network.target

[Service]
User=pulse
WorkingDirectory=/opt/pulse
Environment=PULSE_SECRET_KEY=your-secret-here
ExecStart=/opt/pulse/venv/bin/gunicorn -w 4 -b 0.0.0.0:5000 app:app
Restart=always

[Install]
WantedBy=multi-user.target
```

---

## Project Structure

```
pulse/
├── app.py                  # Flask application + routes
├── requirements.txt        # Python dependencies
├── start.sh               # Quick-start script
├── oracle_databases.json  # Auto-created: Oracle DB registry
├── modules/
│   ├── oracle_check.py    # Oracle health check logic
│   ├── sqlserver_check.py # SQL Server health check logic
│   ├── linux_check.py     # Linux server check logic
│   └── windows_check.py   # Windows server check logic
└── templates/
    ├── base.html          # Sidebar layout + styles
    ├── login.html         # Standalone login page
    ├── dashboard.html     # Overview dashboard
    ├── oracle.html        # Oracle module
    ├── oracle_form.html   # Add/Edit Oracle DB
    ├── sqlserver.html     # SQL Server module
    ├── linux.html         # Linux servers module
    └── windows.html       # Windows servers module
```
