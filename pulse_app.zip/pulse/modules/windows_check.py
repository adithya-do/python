"""Windows server health check module (WinRM/RDP TCP + ICMP)."""
import os, socket, datetime, subprocess

def get_windows_targets():
    raw = os.environ.get('PULSE_WINDOWS_TARGETS', '')
    targets = []
    for entry in raw.split(','):
        entry = entry.strip()
        if entry:
            targets.append({'host': entry, 'port': 3389})
    if not targets:
        targets = [
            {'host': 'win-app-01',  'port': 3389},
            {'host': 'win-dc-01',   'port': 3389},
        ]
    return targets

def check_windows_server(host: str, port: int = 3389) -> dict:
    result = {
        'host': host,
        'port': port,
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'status': 'unknown',
        'message': '',
        'response_ms': None,
        'details': {},
    }

    # ICMP ping
    try:
        ping = subprocess.run(
            ['ping', '-c', '1', '-W', '2', host],
            capture_output=True, timeout=5
        )
        result['details']['ping'] = 'reachable' if ping.returncode == 0 else 'unreachable'
    except Exception:
        result['details']['ping'] = 'unknown'

    # RDP / WinRM TCP check
    winrm_port = 5985
    for check_port, label in [(port, 'RDP'), (winrm_port, 'WinRM')]:
        start = datetime.datetime.now()
        try:
            sock = socket.create_connection((host, check_port), timeout=4)
            sock.close()
            elapsed = (datetime.datetime.now() - start).total_seconds() * 1000
            result['details'][label.lower()] = 'open'
            if result['response_ms'] is None:
                result['response_ms'] = round(elapsed, 1)
        except Exception:
            result['details'][label.lower()] = 'closed'

    rdp_open = result['details'].get('rdp') == 'open'
    winrm_open = result['details'].get('winrm') == 'open'
    ping_ok = result['details'].get('ping') == 'reachable'

    if rdp_open or winrm_open:
        result['status'] = 'healthy'
        ports_open = ', '.join(
            k.upper() for k, v in result['details'].items() if v == 'open'
        )
        result['message'] = f'Reachable — ports open: {ports_open}.'
    elif ping_ok:
        result['status'] = 'warning'
        result['message'] = 'Host responds to ping but RDP/WinRM ports are closed.'
    else:
        result['status'] = 'critical'
        result['message'] = 'Host is unreachable (no ping, no TCP).'

    return result
