"""Oracle database health check module.
Reads credentials from OS environment variables."""
import os
import socket
import datetime

def check_oracle(db: dict) -> dict:
    """
    Attempt to connect to an Oracle DB using credentials from env vars.
    Returns a status dict.
    """
    result = {
        'name': db.get('name', 'Unknown'),
        'host': db.get('host', ''),
        'port': db.get('port', '1521'),
        'service': db.get('service', ''),
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'status': 'unknown',
        'message': '',
        'response_ms': None,
        'details': {},
    }

    # Read credentials from env
    username_env = db.get('username_env', '')
    password_env = db.get('password_env', '')
    username = os.environ.get(username_env, '') if username_env else ''
    password = os.environ.get(password_env, '') if password_env else ''

    if not username or not password:
        result['status'] = 'warning'
        result['message'] = (
            f'Credentials not found in environment variables '
            f'({username_env}, {password_env}). '
            'Set them and retry.'
        )
        result['details']['env_vars_set'] = False
        # Still try TCP check
    else:
        result['details']['env_vars_set'] = True

    # TCP connectivity check
    host = db.get('host', '')
    try:
        port = int(db.get('port', 1521))
    except ValueError:
        port = 1521

    start = datetime.datetime.now()
    try:
        sock = socket.create_connection((host, port), timeout=5)
        sock.close()
        elapsed = (datetime.datetime.now() - start).total_seconds() * 1000
        result['response_ms'] = round(elapsed, 1)
        result['details']['tcp'] = 'open'
    except (socket.timeout, ConnectionRefusedError, OSError) as e:
        result['status'] = 'critical'
        result['message'] = f'TCP connection failed: {e}'
        result['details']['tcp'] = 'closed'
        return result

    # Try cx_Oracle if available
    try:
        import cx_Oracle  # type: ignore
        if username and password:
            dsn = cx_Oracle.makedsn(host, port, service_name=db.get('service', ''))
            start = datetime.datetime.now()
            conn = cx_Oracle.connect(user=username, password=password, dsn=dsn, timeout=10)
            elapsed = (datetime.datetime.now() - start).total_seconds() * 1000
            result['response_ms'] = round(elapsed, 1)
            cur = conn.cursor()
            cur.execute("SELECT BANNER FROM V$VERSION WHERE ROWNUM = 1")
            banner = cur.fetchone()
            cur.execute("SELECT TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI:SS') FROM DUAL")
            db_time = cur.fetchone()
            cur.close()
            conn.close()
            result['status'] = 'healthy'
            result['message'] = 'Connected successfully via cx_Oracle.'
            result['details']['version'] = banner[0] if banner else 'N/A'
            result['details']['db_time'] = db_time[0] if db_time else 'N/A'
        else:
            result['status'] = 'warning'
            result['message'] = 'TCP reachable but credentials missing — skipping full DB connect.'
    except ImportError:
        # cx_Oracle not installed — TCP result is best we can do
        if result['details'].get('tcp') == 'open':
            result['status'] = 'warning' if not (username and password) else 'reachable'
            result['message'] = (
                'TCP port open. cx_Oracle not installed — install it for full connectivity check.'
            )
    except Exception as e:
        result['status'] = 'critical'
        result['message'] = f'Oracle connect error: {e}'

    return result
