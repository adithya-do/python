"""Linux server health check module (SSH-based + TCP ping)."""
import os, socket, datetime, subprocess

def get_linux_targets():
    raw = os.environ.get('PULSE_LINUX_TARGETS', '')
    targets = []
    for entry in raw.split(','):
        entry = entry.strip()
        if entry:
            targets.append({'host': entry, 'port': 22})
    if not targets:
        targets = [
            {'host': 'linux-app-01', 'port': 22},
            {'host': 'linux-db-01',  'port': 22},
            {'host': 'linux-web-01', 'port': 22},
        ]
    return targets

def check_linux_server(host: str, port: int = 22) -> dict:
    result = {
        'host': host,
        'port': port,
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'status': 'unknown',
        'message': '',
        'response_ms': None,
        'details': {},
    }

    # ICMP ping
    try:
        ping = subprocess.run(
            ['ping', '-c', '1', '-W', '2', host],
            capture_output=True, timeout=5
        )
        result['details']['ping'] = 'reachable' if ping.returncode == 0 else 'unreachable'
    except Exception:
        result['details']['ping'] = 'unknown'

    # SSH TCP check
    start = datetime.datetime.now()
    try:
        sock = socket.create_connection((host, port), timeout=5)
        banner = sock.recv(256).decode(errors='replace').strip()
        sock.close()
        elapsed = (datetime.datetime.now() - start).total_seconds() * 1000
        result['response_ms'] = round(elapsed, 1)
        result['details']['ssh_port'] = 'open'
        result['details']['ssh_banner'] = banner[:60] if banner else ''
        result['status'] = 'healthy'
        result['message'] = f'SSH port {port} open.'
    except (socket.timeout, ConnectionRefusedError, OSError) as e:
        if result['details'].get('ping') == 'reachable':
            result['status'] = 'warning'
            result['message'] = f'Host reachable but SSH port {port} closed: {e}'
        else:
            result['status'] = 'critical'
            result['message'] = f'Host unreachable: {e}'
        result['details']['ssh_port'] = 'closed'

    return result
