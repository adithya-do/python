"""SQL Server health check module."""
import os, socket, datetime

# Read SQL Server targets from env vars:
#   PULSE_SQLSERVER_TARGETS=host1:1433,host2:1433
def get_sqlserver_targets():
    raw = os.environ.get('PULSE_SQLSERVER_TARGETS', '')
    targets = []
    for entry in raw.split(','):
        entry = entry.strip()
        if not entry:
            continue
        parts = entry.split(':')
        host = parts[0]
        port = int(parts[1]) if len(parts) > 1 else 1433
        targets.append({'host': host, 'port': port})
    if not targets:
        # Default demo targets
        targets = [
            {'host': 'sqlserver-prod-01', 'port': 1433},
            {'host': 'sqlserver-dev-01',  'port': 1433},
        ]
    return targets

def check_sqlserver(host: str, port: int = 1433) -> dict:
    result = {
        'host': host,
        'port': port,
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'status': 'unknown',
        'message': '',
        'response_ms': None,
        'details': {},
    }
    start = datetime.datetime.now()
    try:
        sock = socket.create_connection((host, port), timeout=5)
        sock.close()
        elapsed = (datetime.datetime.now() - start).total_seconds() * 1000
        result['response_ms'] = round(elapsed, 1)
        result['details']['tcp'] = 'open'
    except (socket.timeout, ConnectionRefusedError, OSError) as e:
        result['status'] = 'critical'
        result['message'] = f'TCP {host}:{port} unreachable — {e}'
        result['details']['tcp'] = 'closed'
        return result

    # Try pyodbc if available
    try:
        import pyodbc  # type: ignore
        user = os.environ.get('PULSE_SQLSERVER_USER', '')
        pwd  = os.environ.get('PULSE_SQLSERVER_PASSWORD', '')
        if user and pwd:
            conn_str = (
                f'DRIVER={{ODBC Driver 17 for SQL Server}};'
                f'SERVER={host},{port};UID={user};PWD={pwd};Connection Timeout=5;'
            )
            start2 = datetime.datetime.now()
            conn = pyodbc.connect(conn_str, timeout=10)
            elapsed2 = (datetime.datetime.now() - start2).total_seconds() * 1000
            result['response_ms'] = round(elapsed2, 1)
            cur = conn.cursor()
            cur.execute("SELECT @@VERSION, GETDATE()")
            row = cur.fetchone()
            conn.close()
            result['status'] = 'healthy'
            result['message'] = 'Connected successfully.'
            result['details']['version'] = str(row[0])[:80] if row else 'N/A'
            result['details']['db_time']  = str(row[1]) if row else 'N/A'
        else:
            result['status'] = 'warning'
            result['message'] = 'TCP reachable. Set PULSE_SQLSERVER_USER/PASSWORD for full check.'
    except ImportError:
        result['status'] = 'reachable'
        result['message'] = 'TCP port open. Install pyodbc for full connectivity check.'
    except Exception as e:
        result['status'] = 'critical'
        result['message'] = f'SQL Server connect error: {e}'

    return result
