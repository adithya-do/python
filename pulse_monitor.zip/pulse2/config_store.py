"""
config_store.py — JSON-based persistent config for Pulse
Each resource type has its own JSON file.
Passwords are stored encrypted in a separate secrets.json.
"""
import json, os, uuid, datetime
from cryptography.fernet import Fernet

BASE = os.path.dirname(__file__)
DATA_DIR = os.path.join(BASE, 'data')
os.makedirs(DATA_DIR, exist_ok=True)

# ── Encryption key management ─────────────────────────────────────────────────
KEY_FILE = os.path.join(DATA_DIR, '.pulse_key')

def _get_key() -> bytes:
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, 'rb') as f:
            return f.read()
    key = Fernet.generate_key()
    with open(KEY_FILE, 'wb') as f:
        f.write(key)
    os.chmod(KEY_FILE, 0o600)
    return key

_fernet = Fernet(_get_key())

def encrypt_password(plain: str) -> str:
    if not plain:
        return ''
    return _fernet.encrypt(plain.encode()).decode()

def decrypt_password(enc: str) -> str:
    if not enc:
        return ''
    try:
        return _fernet.decrypt(enc.encode()).decode()
    except Exception:
        return ''

# ── Generic JSON store ────────────────────────────────────────────────────────
def _path(name: str) -> str:
    return os.path.join(DATA_DIR, f'{name}.json')

def _load(name: str) -> list:
    p = _path(name)
    if not os.path.exists(p):
        return []
    with open(p) as f:
        return json.load(f)

def _save(name: str, data: list):
    with open(_path(name), 'w') as f:
        json.dump(data, f, indent=2, default=str)

# ── Users (passwords hashed via werkzeug) ────────────────────────────────────
from werkzeug.security import generate_password_hash, check_password_hash

USERS_FILE = _path('users')

def init_default_users():
    if not os.path.exists(USERS_FILE):
        users = [
            {'id': str(uuid.uuid4()), 'username': 'admin',
             'password_hash': generate_password_hash('admin123'),
             'role': 'admin', 'name': 'Administrator',
             'email': 'admin@company.com'},
            {'id': str(uuid.uuid4()), 'username': 'user',
             'password_hash': generate_password_hash('user123'),
             'role': 'user', 'name': 'Operator',
             'email': 'operator@company.com'},
        ]
        _save('users', users)

def get_users() -> list:
    init_default_users()
    return _load('users')

def get_user(username: str) -> dict | None:
    return next((u for u in get_users() if u['username'] == username), None)

def verify_user(username: str, password: str) -> dict | None:
    u = get_user(username)
    if u and check_password_hash(u['password_hash'], password):
        return u
    return None

def save_user(user: dict):
    users = get_users()
    idx = next((i for i, u in enumerate(users) if u['id'] == user['id']), None)
    if idx is not None:
        users[idx] = user
    else:
        users.append(user)
    _save('users', users)

def create_user(username, password, name, role, email):
    users = get_users()
    if any(u['username'] == username for u in users):
        raise ValueError(f'Username "{username}" already exists')
    user = {'id': str(uuid.uuid4()), 'username': username,
            'password_hash': generate_password_hash(password),
            'role': role, 'name': name, 'email': email}
    users.append(user)
    _save('users', users)
    return user

def change_password(username, new_password):
    users = get_users()
    for u in users:
        if u['username'] == username:
            u['password_hash'] = generate_password_hash(new_password)
            break
    _save('users', users)

def delete_user(user_id):
    users = [u for u in get_users() if u['id'] != user_id]
    _save('users', users)

# ── Oracle Databases ──────────────────────────────────────────────────────────
def get_oracle_dbs() -> list:
    return _load('oracle_databases')

def save_oracle_dbs(dbs: list):
    _save('oracle_databases', dbs)

def add_oracle_db(data: dict) -> dict:
    dbs = get_oracle_dbs()
    entry = {
        'id': str(uuid.uuid4()),
        'db_name': data.get('db_name', ''),
        'environment': data.get('environment', 'Non-Prod'),
        'host': data.get('host', ''),
        'port': data.get('port', '1521'),
        'service_name': data.get('service_name', ''),
        'oracle_home': data.get('oracle_home', ''),
        'tns_admin': data.get('tns_admin', ''),
        'username': data.get('username', ''),
        'password_enc': encrypt_password(data.get('password', '')),
        'description': data.get('description', ''),
        'created': datetime.datetime.now().isoformat(),
        'last_check': None,
        'last_result': None,
    }
    dbs.append(entry)
    _save('oracle_databases', dbs)
    return entry

def update_oracle_db(db_id: str, data: dict):
    dbs = get_oracle_dbs()
    for db in dbs:
        if db['id'] == db_id:
            db.update({
                'db_name': data.get('db_name', db['db_name']),
                'environment': data.get('environment', db['environment']),
                'host': data.get('host', db['host']),
                'port': data.get('port', db['port']),
                'service_name': data.get('service_name', db['service_name']),
                'oracle_home': data.get('oracle_home', db.get('oracle_home', '')),
                'tns_admin': data.get('tns_admin', db.get('tns_admin', '')),
                'username': data.get('username', db['username']),
                'description': data.get('description', db.get('description', '')),
                'updated': datetime.datetime.now().isoformat(),
            })
            if data.get('password'):
                db['password_enc'] = encrypt_password(data['password'])
            break
    _save('oracle_databases', dbs)

def delete_oracle_db(db_id: str):
    dbs = [d for d in get_oracle_dbs() if d['id'] != db_id]
    _save('oracle_databases', dbs)

def update_oracle_result(db_id: str, result: dict):
    dbs = get_oracle_dbs()
    for db in dbs:
        if db['id'] == db_id:
            db['last_check'] = datetime.datetime.now().isoformat()
            db['last_result'] = result
            break
    _save('oracle_databases', dbs)

# ── SQL Server Instances ──────────────────────────────────────────────────────
def get_sql_instances() -> list:
    return _load('sqlserver_instances')

def add_sql_instance(data: dict) -> dict:
    instances = get_sql_instances()
    entry = {
        'id': str(uuid.uuid4()),
        'instance_name': data.get('instance_name', ''),
        'environment': data.get('environment', 'Non-Prod'),
        'host': data.get('host', ''),
        'port': data.get('port', '1433'),
        'username': data.get('username', ''),
        'password_enc': encrypt_password(data.get('password', '')),
        'description': data.get('description', ''),
        'created': datetime.datetime.now().isoformat(),
        'last_check': None,
        'last_result': None,
    }
    instances.append(entry)
    _save('sqlserver_instances', instances)
    return entry

def update_sql_instance(inst_id: str, data: dict):
    instances = get_sql_instances()
    for inst in instances:
        if inst['id'] == inst_id:
            inst.update({
                'instance_name': data.get('instance_name', inst['instance_name']),
                'environment': data.get('environment', inst['environment']),
                'host': data.get('host', inst['host']),
                'port': data.get('port', inst['port']),
                'username': data.get('username', inst['username']),
                'description': data.get('description', inst.get('description', '')),
                'updated': datetime.datetime.now().isoformat(),
            })
            if data.get('password'):
                inst['password_enc'] = encrypt_password(data['password'])
            break
    _save('sqlserver_instances', instances)

def delete_sql_instance(inst_id: str):
    instances = [i for i in get_sql_instances() if i['id'] != inst_id]
    _save('sqlserver_instances', instances)

def update_sql_result(inst_id: str, result: dict):
    instances = get_sql_instances()
    for inst in instances:
        if inst['id'] == inst_id:
            inst['last_check'] = datetime.datetime.now().isoformat()
            inst['last_result'] = result
            break
    _save('sqlserver_instances', instances)

# ── Linux Servers ─────────────────────────────────────────────────────────────
def get_linux_servers() -> list:
    return _load('linux_servers')

def add_linux_server(data: dict) -> dict:
    servers = get_linux_servers()
    entry = {
        'id': str(uuid.uuid4()),
        'server_name': data.get('server_name', ''),
        'host': data.get('host', ''),
        'environment': data.get('environment', 'Non-Prod'),
        'ssh_port': data.get('ssh_port', '22'),
        'username': data.get('username', ''),
        'password_enc': encrypt_password(data.get('password', '')),
        'ssh_key_path': data.get('ssh_key_path', ''),
        'description': data.get('description', ''),
        'created': datetime.datetime.now().isoformat(),
        'last_check': None,
        'last_result': None,
    }
    servers.append(entry)
    _save('linux_servers', servers)
    return entry

def update_linux_server(srv_id: str, data: dict):
    servers = get_linux_servers()
    for srv in servers:
        if srv['id'] == srv_id:
            srv.update({k: data[k] for k in ['server_name','host','environment',
                        'ssh_port','username','ssh_key_path','description'] if k in data})
            if data.get('password'):
                srv['password_enc'] = encrypt_password(data['password'])
            srv['updated'] = datetime.datetime.now().isoformat()
            break
    _save('linux_servers', servers)

def delete_linux_server(srv_id: str):
    servers = [s for s in get_linux_servers() if s['id'] != srv_id]
    _save('linux_servers', servers)

def update_linux_result(srv_id: str, result: dict):
    servers = get_linux_servers()
    for srv in servers:
        if srv['id'] == srv_id:
            srv['last_check'] = datetime.datetime.now().isoformat()
            srv['last_result'] = result
            break
    _save('linux_servers', servers)

# ── Windows Servers ───────────────────────────────────────────────────────────
def get_windows_servers() -> list:
    return _load('windows_servers')

def add_windows_server(data: dict) -> dict:
    servers = get_windows_servers()
    entry = {
        'id': str(uuid.uuid4()),
        'server_name': data.get('server_name', ''),
        'host': data.get('host', ''),
        'environment': data.get('environment', 'Non-Prod'),
        'username': data.get('username', ''),
        'password_enc': encrypt_password(data.get('password', '')),
        'description': data.get('description', ''),
        'created': datetime.datetime.now().isoformat(),
        'last_check': None,
        'last_result': None,
    }
    servers.append(entry)
    _save('windows_servers', servers)
    return entry

def update_windows_server(srv_id: str, data: dict):
    servers = get_windows_servers()
    for srv in servers:
        if srv['id'] == srv_id:
            srv.update({k: data[k] for k in ['server_name','host','environment',
                        'username','description'] if k in data})
            if data.get('password'):
                srv['password_enc'] = encrypt_password(data['password'])
            srv['updated'] = datetime.datetime.now().isoformat()
            break
    _save('windows_servers', servers)

def delete_windows_server(srv_id: str):
    servers = [s for s in get_windows_servers() if s['id'] != srv_id]
    _save('windows_servers', servers)

def update_windows_result(srv_id: str, result: dict):
    servers = get_windows_servers()
    for srv in servers:
        if srv['id'] == srv_id:
            srv['last_check'] = datetime.datetime.now().isoformat()
            srv['last_result'] = result
            break
    _save('windows_servers', servers)

# ── Email / Schedule config ───────────────────────────────────────────────────
def get_email_config() -> dict:
    configs = _load('email_config')
    return configs[0] if configs else {
        'smtp_host': '', 'smtp_port': '587', 'smtp_user': '',
        'smtp_password_enc': '', 'from_email': '', 'tls': True,
    }

def save_email_config(data: dict):
    entry = {
        'smtp_host': data.get('smtp_host', ''),
        'smtp_port': data.get('smtp_port', '587'),
        'smtp_user': data.get('smtp_user', ''),
        'smtp_password_enc': encrypt_password(data.get('smtp_password', '')) if data.get('smtp_password') else _load('email_config')[0].get('smtp_password_enc','') if _load('email_config') else '',
        'from_email': data.get('from_email', ''),
        'tls': data.get('tls', True),
    }
    _save('email_config', [entry])

def get_schedules() -> dict:
    sched = _load('schedules')
    return sched[0] if sched else {
        'oracle_interval': 60, 'oracle_enabled': False, 'oracle_email': '',
        'sqlserver_interval': 60, 'sqlserver_enabled': False, 'sqlserver_email': '',
        'linux_interval': 60, 'linux_enabled': False, 'linux_email': '',
        'windows_interval': 60, 'windows_enabled': False, 'windows_email': '',
    }

def save_schedules(data: dict):
    _save('schedules', [data])
