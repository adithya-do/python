"""Pulse — Infrastructure Health Monitor (Production)"""
import os, sys, json, uuid, datetime, threading, time
from functools import wraps
from flask import (Flask, render_template, redirect, url_for, session,
                   flash, request, jsonify, Response)

sys.path.insert(0, os.path.dirname(__file__))
import config_store as cs

app = Flask(__name__)
app.secret_key = os.environ.get('PULSE_SECRET_KEY', 'CHANGE-IN-PRODUCTION-' + str(uuid.uuid4()))

@app.template_filter('statusbadge')
def statusbadge_filter(status):
    labels = {'healthy':'Healthy','warning':'Warning','critical':'Critical',
              'unknown':'Unknown','reachable':'Reachable','in_progress':'Checking…'}
    s = status or 'unknown'
    return f'<span class="badge badge-{s}">{labels.get(s, s)}</span>'

# ── Auth decorators ───────────────────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def deco(*a, **k):
        if 'uid' not in session:
            flash('Please log in.', 'warning')
            return redirect(url_for('login'))
        return f(*a, **k)
    return deco

def admin_required(f):
    @wraps(f)
    def deco(*a, **k):
        if 'uid' not in session:
            return redirect(url_for('login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*a, **k)
    return deco

# ── Auth routes ───────────────────────────────────────────────────────────────
@app.route('/', methods=['GET','POST'])
@app.route('/login', methods=['GET','POST'])
def login():
    if 'uid' in session:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        u = cs.verify_user(request.form.get('username',''), request.form.get('password',''))
        if u:
            session.update({'uid': u['id'], 'username': u['username'],
                            'role': u['role'], 'name': u['name'],
                            'login_time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')})
            return redirect(url_for('dashboard'))
        flash('Invalid credentials.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out.', 'info')
    return redirect(url_for('login'))

# ── Dashboard ─────────────────────────────────────────────────────────────────
@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/api/summary')
@login_required
def api_summary():
    def counts(items):
        results = [i.get('last_result') or {} for i in items]
        return {
            'total': len(items),
            'healthy': sum(1 for r in results if r.get('status')=='healthy'),
            'warning': sum(1 for r in results if r.get('status')=='warning'),
            'critical': sum(1 for r in results if r.get('status')=='critical'),
        }
    return jsonify({
        'oracle':    counts(cs.get_oracle_dbs()),
        'sqlserver': counts(cs.get_sql_instances()),
        'linux':     counts(cs.get_linux_servers()),
        'windows':   counts(cs.get_windows_servers()),
    })

# ── Oracle ────────────────────────────────────────────────────────────────────
@app.route('/oracle')
@login_required
def oracle():
    dbs = cs.get_oracle_dbs()
    return render_template('oracle.html', databases=dbs)

@app.route('/oracle/add', methods=['GET','POST'])
@admin_required
def oracle_add():
    if request.method == 'POST':
        cs.add_oracle_db(request.form.to_dict())
        flash('Oracle database added.', 'success')
        return redirect(url_for('oracle'))
    return render_template('oracle_form.html', db=None, action='Add')

@app.route('/oracle/edit/<db_id>', methods=['GET','POST'])
@admin_required
def oracle_edit(db_id):
    dbs = cs.get_oracle_dbs()
    db = next((d for d in dbs if d['id']==db_id), None)
    if not db:
        flash('Not found.', 'danger'); return redirect(url_for('oracle'))
    if request.method == 'POST':
        cs.update_oracle_db(db_id, request.form.to_dict())
        flash('Updated.', 'success'); return redirect(url_for('oracle'))
    return render_template('oracle_form.html', db=db, action='Edit')

@app.route('/oracle/delete/<db_id>', methods=['POST'])
@admin_required
def oracle_delete(db_id):
    cs.delete_oracle_db(db_id)
    flash('Deleted.', 'success'); return redirect(url_for('oracle'))

@app.route('/api/oracle/check/<db_id>')
@login_required
def oracle_check(db_id):
    from modules.oracle_check import check_oracle
    dbs = cs.get_oracle_dbs()
    db = next((d for d in dbs if d['id']==db_id), None)
    if not db: return jsonify({'error':'Not found'}), 404
    result = check_oracle(db)
    cs.update_oracle_result(db_id, result)
    return jsonify(result)

@app.route('/api/oracle/check-all')
@login_required
def oracle_check_all():
    from modules.oracle_check import check_oracle
    dbs = cs.get_oracle_dbs()
    results = []
    for db in dbs:
        r = check_oracle(db)
        cs.update_oracle_result(db['id'], r)
        results.append(r)
    return jsonify(results)

# ── SQL Server ────────────────────────────────────────────────────────────────
@app.route('/sqlserver')
@login_required
def sqlserver():
    instances = cs.get_sql_instances()
    return render_template('sqlserver.html', instances=instances)

@app.route('/sqlserver/add', methods=['GET','POST'])
@admin_required
def sqlserver_add():
    if request.method == 'POST':
        cs.add_sql_instance(request.form.to_dict())
        flash('SQL Server instance added.', 'success')
        return redirect(url_for('sqlserver'))
    return render_template('sqlserver_form.html', inst=None, action='Add')

@app.route('/sqlserver/edit/<inst_id>', methods=['GET','POST'])
@admin_required
def sqlserver_edit(inst_id):
    instances = cs.get_sql_instances()
    inst = next((i for i in instances if i['id']==inst_id), None)
    if not inst:
        flash('Not found.', 'danger'); return redirect(url_for('sqlserver'))
    if request.method == 'POST':
        cs.update_sql_instance(inst_id, request.form.to_dict())
        flash('Updated.', 'success'); return redirect(url_for('sqlserver'))
    return render_template('sqlserver_form.html', inst=inst, action='Edit')

@app.route('/sqlserver/delete/<inst_id>', methods=['POST'])
@admin_required
def sqlserver_delete(inst_id):
    cs.delete_sql_instance(inst_id)
    flash('Deleted.', 'success'); return redirect(url_for('sqlserver'))

@app.route('/api/sqlserver/check/<inst_id>')
@login_required
def sqlserver_check(inst_id):
    from modules.sqlserver_check import check_sqlserver
    instances = cs.get_sql_instances()
    inst = next((i for i in instances if i['id']==inst_id), None)
    if not inst: return jsonify({'error':'Not found'}), 404
    result = check_sqlserver(inst)
    cs.update_sql_result(inst_id, result)
    return jsonify(result)

@app.route('/api/sqlserver/check-all')
@login_required
def sqlserver_check_all():
    from modules.sqlserver_check import check_sqlserver
    instances = cs.get_sql_instances()
    results = []
    for inst in instances:
        r = check_sqlserver(inst)
        cs.update_sql_result(inst['id'], r)
        results.append(r)
    return jsonify(results)

# ── Linux ─────────────────────────────────────────────────────────────────────
@app.route('/linux')
@login_required
def linux():
    servers = cs.get_linux_servers()
    return render_template('linux.html', servers=servers)

@app.route('/linux/add', methods=['GET','POST'])
@admin_required
def linux_add():
    if request.method == 'POST':
        cs.add_linux_server(request.form.to_dict())
        flash('Linux server added.', 'success')
        return redirect(url_for('linux'))
    return render_template('server_form.html', srv=None, action='Add', module='linux')

@app.route('/linux/edit/<srv_id>', methods=['GET','POST'])
@admin_required
def linux_edit(srv_id):
    servers = cs.get_linux_servers()
    srv = next((s for s in servers if s['id']==srv_id), None)
    if not srv:
        flash('Not found.', 'danger'); return redirect(url_for('linux'))
    if request.method == 'POST':
        cs.update_linux_server(srv_id, request.form.to_dict())
        flash('Updated.', 'success'); return redirect(url_for('linux'))
    return render_template('server_form.html', srv=srv, action='Edit', module='linux')

@app.route('/linux/delete/<srv_id>', methods=['POST'])
@admin_required
def linux_delete(srv_id):
    cs.delete_linux_server(srv_id)
    flash('Deleted.', 'success'); return redirect(url_for('linux'))

@app.route('/api/linux/check/<srv_id>')
@login_required
def linux_check(srv_id):
    from modules.linux_check import check_linux
    servers = cs.get_linux_servers()
    srv = next((s for s in servers if s['id']==srv_id), None)
    if not srv: return jsonify({'error':'Not found'}), 404
    result = check_linux(srv)
    cs.update_linux_result(srv_id, result)
    return jsonify(result)

@app.route('/api/linux/check-all')
@login_required
def linux_check_all():
    from modules.linux_check import check_linux
    servers = cs.get_linux_servers()
    results = []
    for srv in servers:
        r = check_linux(srv)
        cs.update_linux_result(srv['id'], r)
        results.append(r)
    return jsonify(results)

# ── Windows ───────────────────────────────────────────────────────────────────
@app.route('/windows')
@login_required
def windows():
    servers = cs.get_windows_servers()
    return render_template('windows.html', servers=servers)

@app.route('/windows/add', methods=['GET','POST'])
@admin_required
def windows_add():
    if request.method == 'POST':
        cs.add_windows_server(request.form.to_dict())
        flash('Windows server added.', 'success')
        return redirect(url_for('windows'))
    return render_template('server_form.html', srv=None, action='Add', module='windows')

@app.route('/windows/edit/<srv_id>', methods=['GET','POST'])
@admin_required
def windows_edit(srv_id):
    servers = cs.get_windows_servers()
    srv = next((s for s in servers if s['id']==srv_id), None)
    if not srv:
        flash('Not found.', 'danger'); return redirect(url_for('windows'))
    if request.method == 'POST':
        cs.update_windows_server(srv_id, request.form.to_dict())
        flash('Updated.', 'success'); return redirect(url_for('windows'))
    return render_template('server_form.html', srv=srv, action='Edit', module='windows')

@app.route('/windows/delete/<srv_id>', methods=['POST'])
@admin_required
def windows_delete(srv_id):
    cs.delete_windows_server(srv_id)
    flash('Deleted.', 'success'); return redirect(url_for('windows'))

@app.route('/api/windows/check/<srv_id>')
@login_required
def windows_check(srv_id):
    from modules.windows_check import check_windows
    servers = cs.get_windows_servers()
    srv = next((s for s in servers if s['id']==srv_id), None)
    if not srv: return jsonify({'error':'Not found'}), 404
    result = check_windows(srv)
    cs.update_windows_result(srv_id, result)
    return jsonify(result)

@app.route('/api/windows/check-all')
@login_required
def windows_check_all():
    from modules.windows_check import check_windows
    servers = cs.get_windows_servers()
    results = []
    for srv in servers:
        r = check_windows(srv)
        cs.update_windows_result(srv['id'], r)
        results.append(r)
    return jsonify(results)

# ── Email + Schedule ──────────────────────────────────────────────────────────
@app.route('/api/email/send', methods=['POST'])
@login_required
def email_send():
    from modules.email_report import send_report
    data = request.json
    module = data.get('module','')
    to_email = data.get('to_email','')
    items_map = {
        'oracle': cs.get_oracle_dbs,
        'sqlserver': cs.get_sql_instances,
        'linux': cs.get_linux_servers,
        'windows': cs.get_windows_servers,
    }
    if module not in items_map:
        return jsonify({'ok': False, 'msg': 'Unknown module'})
    ok, msg = send_report(module, items_map[module](), to_email)
    return jsonify({'ok': ok, 'msg': msg})

@app.route('/settings', methods=['GET','POST'])
@admin_required
def settings():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'email':
            cs.save_email_config(request.form.to_dict())
            flash('Email settings saved.', 'success')
        elif action == 'schedule':
            data = request.form.to_dict()
            # Convert checkboxes
            for mod in ['oracle','sqlserver','linux','windows']:
                data[f'{mod}_enabled'] = f'{mod}_enabled' in request.form
            cs.save_schedules(data)
            flash('Schedule saved.', 'success')
        elif action == 'add_user':
            try:
                cs.create_user(
                    request.form['username'], request.form['password'],
                    request.form['name'], request.form['role'], request.form.get('email',''))
                flash(f'User {request.form["username"]} created.', 'success')
            except ValueError as e:
                flash(str(e), 'danger')
        elif action == 'delete_user':
            cs.delete_user(request.form['user_id'])
            flash('User deleted.', 'success')
        return redirect(url_for('settings'))

    email_cfg = cs.get_email_config()
    schedules = cs.get_schedules()
    users = cs.get_users()
    return render_template('settings.html',
                           email_cfg=email_cfg, schedules=schedules, users=users)

# ── Preview email HTML ────────────────────────────────────────────────────────
@app.route('/api/email/preview/<module>')
@login_required
def email_preview(module):
    from modules.email_report import build_html_report
    items_map = {
        'oracle': cs.get_oracle_dbs,
        'sqlserver': cs.get_sql_instances,
        'linux': cs.get_linux_servers,
        'windows': cs.get_windows_servers,
    }
    if module not in items_map:
        return 'Unknown module', 404
    html = build_html_report(module, items_map[module]())
    return Response(html, content_type='text/html')

# ── Background scheduler (thread-based, no APScheduler needed) ────────────────
_scheduler_thread = None
_stop_scheduler = threading.Event()

def _scheduler_loop():
    last_run = {}
    while not _stop_scheduler.is_set():
        try:
            schedules = cs.get_schedules()
            modules = {
                'oracle':    (cs.get_oracle_dbs,    'modules.oracle_check',    'check_oracle',    cs.update_oracle_result),
                'sqlserver': (cs.get_sql_instances, 'modules.sqlserver_check', 'check_sqlserver', cs.update_sql_result),
                'linux':     (cs.get_linux_servers, 'modules.linux_check',     'check_linux',     cs.update_linux_result),
                'windows':   (cs.get_windows_servers,'modules.windows_check',  'check_windows',   cs.update_windows_result),
            }
            now = time.time()
            for mod, (get_fn, mod_path, fn_name, update_fn) in modules.items():
                enabled = schedules.get(f'{mod}_enabled', False)
                interval = int(schedules.get(f'{mod}_interval', 60)) * 60  # minutes → seconds
                if not enabled:
                    continue
                last = last_run.get(mod, 0)
                if now - last < interval:
                    continue
                last_run[mod] = now
                import importlib
                m = importlib.import_module(mod_path)
                fn = getattr(m, fn_name)
                items = get_fn()
                for item in items:
                    try:
                        r = fn(item)
                        update_fn(item['id'], r)
                    except Exception:
                        pass
                # Send email if configured
                email = schedules.get(f'{mod}_email', '')
                if email:
                    try:
                        from modules.email_report import send_report
                        send_report(mod, get_fn(), email)
                    except Exception:
                        pass
        except Exception:
            pass
        _stop_scheduler.wait(timeout=30)

def start_scheduler():
    global _scheduler_thread
    if _scheduler_thread is None or not _scheduler_thread.is_alive():
        _stop_scheduler.clear()
        _scheduler_thread = threading.Thread(target=_scheduler_loop, daemon=True)
        _scheduler_thread.start()

# ── Generate self-signed cert for HTTPS ───────────────────────────────────────
def ensure_ssl_cert():
    cert_dir = os.path.join(os.path.dirname(__file__), 'certs')
    os.makedirs(cert_dir, exist_ok=True)
    cert_file = os.path.join(cert_dir, 'pulse.crt')
    key_file  = os.path.join(cert_dir, 'pulse.key')
    if os.path.exists(cert_file) and os.path.exists(key_file):
        return cert_file, key_file
    try:
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        import ipaddress
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, u'pulse.local'),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, u'Pulse Monitor'),
        ])
        cert = (x509.CertificateBuilder()
            .subject_name(name).issuer_name(name)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(datetime.datetime.utcnow())
            .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=3650))
            .add_extension(x509.SubjectAlternativeName([
                x509.DNSName(u'localhost'),
                x509.DNSName(u'pulse.local'),
                x509.IPAddress(ipaddress.IPv4Address('127.0.0.1')),
            ]), critical=False)
            .sign(key, hashes.SHA256()))
        with open(cert_file, 'wb') as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))
        with open(key_file, 'wb') as f:
            f.write(key.private_bytes(serialization.Encoding.PEM,
                    serialization.PrivateFormat.TraditionalOpenSSL,
                    serialization.NoEncryption()))
        os.chmod(key_file, 0o600)
        print(f'  ✓ SSL certificate created: {cert_file}')
        return cert_file, key_file
    except Exception as e:
        print(f'  ⚠ SSL cert generation failed: {e}')
        return None, None

if __name__ == '__main__':
    cs.init_default_users()
    start_scheduler()
    use_https = os.environ.get('PULSE_HTTP_ONLY','').lower() not in ('1','true','yes')
    if use_https:
        cert, key = ensure_ssl_cert()
        if cert and key:
            print('  ✓ Starting Pulse with HTTPS on https://0.0.0.0:5443')
            app.run(host='0.0.0.0', port=5443, ssl_context=(cert, key), debug=False)
        else:
            print('  ⚠ Falling back to HTTP on http://0.0.0.0:5000')
            app.run(host='0.0.0.0', port=5000, debug=False)
    else:
        print('  Starting Pulse (HTTP) on http://0.0.0.0:5000')
        app.run(host='0.0.0.0', port=5000, debug=False)
