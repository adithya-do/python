"""Windows server health check — WMI/WinRM + TCP."""
import socket, datetime, subprocess
from config_store import decrypt_password

def check_windows(srv: dict) -> dict:
    result = {
        'id': srv['id'], 'server_name': srv.get('server_name',''),
        'environment': srv.get('environment',''), 'host': srv.get('host',''),
        'status': 'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'os': 'Windows', 'os_version': '—',
        'memory_gb': '—', 'memory_usage_pct': '—',
        'cpu_count': '—', 'cpu_load_avg': '—',
        'worst_disk': '—', 'worst_disk_pct': '—',
        'uptime': '—',
    }

    host = srv.get('host','')

    try:
        ping = subprocess.run(['ping','-c','1','-W','2', host],
                              capture_output=True, timeout=5)
        ping_ok = ping.returncode == 0
    except:
        ping_ok = False

    rdp_ok = winrm_ok = False
    for check_port, label in [(3389,'rdp'),(5985,'winrm')]:
        try:
            start = datetime.datetime.now()
            sock = socket.create_connection((host, check_port), timeout=4)
            sock.close()
            elapsed = round((datetime.datetime.now()-start).total_seconds()*1000, 1)
            if result['response_ms'] is None:
                result['response_ms'] = elapsed
            if label == 'rdp': rdp_ok = True
            else: winrm_ok = True
        except:
            pass

    if not ping_ok and not rdp_ok and not winrm_ok:
        result['status'] = 'critical'
        result['check_status'] = 'completed'
        result['error'] = 'Host unreachable (no ping, no RDP, no WinRM)'
        return result

    # Try winrm / pywinrm for metrics
    username = srv.get('username','')
    password = decrypt_password(srv.get('password_enc',''))

    if winrm_ok and username and password:
        try:
            import winrm  # type: ignore
            session = winrm.Session(host, auth=(username, password), transport='ntlm')

            def ps(cmd):
                r = session.run_ps(cmd)
                return r.std_out.decode(errors='replace').strip()

            result['os_version'] = ps("(Get-WmiObject Win32_OperatingSystem).Caption")
            result['uptime'] = ps("(Get-Date) - (gcim Win32_OperatingSystem).LastBootUpTime | Select -ExpandProperty TotalHours | ForEach-Object { [math]::Round($_,1).ToString() + ' hours' }")
            result['cpu_count'] = ps("(Get-WmiObject Win32_ComputerSystem).NumberOfLogicalProcessors")
            result['cpu_load_avg'] = ps("Get-WmiObject Win32_Processor | Measure-Object LoadPercentage -Average | Select -ExpandProperty Average") + '%'

            mem_raw = ps("Get-WmiObject Win32_OperatingSystem | Select TotalVisibleMemorySize,FreePhysicalMemory | ConvertTo-Csv -NoTypeInformation | Select -Last 1")
            if ',' in mem_raw:
                parts = mem_raw.replace('"','').split(',')
                if len(parts) >= 2:
                    try:
                        total_kb = float(parts[0]); free_kb = float(parts[1])
                        result['memory_gb'] = round(total_kb/1048576, 1)
                        used_pct = round(((total_kb-free_kb)/total_kb)*100, 1)
                        result['memory_usage_pct'] = f"{used_pct}%"
                    except: pass

            disk_raw = ps("Get-PSDrive -PSProvider FileSystem | Where {$_.Used -gt 0} | Sort {($_.Used/($_.Used+$_.Free))} -Descending | Select -First 1 | ForEach-Object { $pct=[math]::Round($_.Used/($_.Used+$_.Free)*100,1); \"$($_.Name): $pct%\" }")
            if disk_raw:
                result['worst_disk'] = disk_raw.split(':')[0] if ':' in disk_raw else '—'
                import re
                m = re.search(r'(\d+\.?\d*)%', disk_raw)
                if m: result['worst_disk_pct'] = m.group(0)

            result['status'] = 'healthy'
            result['check_status'] = 'completed'
            result['message'] = 'WinRM connected'
            return result

        except ImportError:
            pass
        except Exception as e:
            result['error'] = f'WinRM failed: {str(e)[:100]}'

    # Fallback: TCP-only status
    if rdp_ok or winrm_ok or ping_ok:
        result['status'] = 'reachable'
        result['check_status'] = 'completed'
        ports = []
        if ping_ok: ports.append('ping')
        if rdp_ok:  ports.append('RDP')
        if winrm_ok: ports.append('WinRM')
        result['message'] = f"Reachable via: {', '.join(ports)}"
        if not result['error']:
            result['error'] = 'Install pywinrm for full metrics.' if winrm_ok else 'WinRM port closed — cannot collect metrics.'
    else:
        result['status'] = 'critical'
        result['check_status'] = 'completed'

    return result
