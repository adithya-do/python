"""Oracle health check module — comprehensive metrics."""
import os, socket, datetime
from config_store import decrypt_password

def _set_oracle_env(db: dict):
    if db.get('oracle_home'):
        os.environ['ORACLE_HOME'] = db['oracle_home']
        lib = os.path.join(db['oracle_home'], 'lib')
        existing = os.environ.get('LD_LIBRARY_PATH', '')
        os.environ['LD_LIBRARY_PATH'] = f"{lib}:{existing}" if existing else lib
    if db.get('tns_admin'):
        os.environ['TNS_ADMIN'] = db['tns_admin']

def check_oracle(db: dict) -> dict:
    result = {
        'id': db['id'], 'db_name': db.get('db_name',''),
        'environment': db.get('environment',''), 'host': db.get('host',''),
        'status': 'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'db_version': '—', 'db_size_gb': '—', 'instance_status': '—',
        'startup_time': '—', 'worst_ts_pct': '—', 'worst_ts_name': '—',
        'sessions_current': '—', 'sessions_max': '—',
        'last_full_backup': '—', 'last_inc_backup': '—', 'last_arch_backup': '—',
    }
    _set_oracle_env(db)
    host = db.get('host','')
    try:
        port = int(db.get('port', 1521))
    except ValueError:
        port = 1521

    start = datetime.datetime.now()
    try:
        sock = socket.create_connection((host, port), timeout=5)
        sock.close()
        result['response_ms'] = round((datetime.datetime.now()-start).total_seconds()*1000, 1)
    except Exception as e:
        result['status'] = 'critical'
        result['check_status'] = 'completed'
        result['error'] = f'TCP unreachable: {e}'
        return result

    username = db.get('username','')
    password = decrypt_password(db.get('password_enc',''))
    if not username or not password:
        result['status'] = 'warning'
        result['check_status'] = 'completed'
        result['error'] = 'No credentials configured'
        return result

    conn = None
    try:
        try:
            import oracledb as drv  # type: ignore
            try:
                drv.init_oracle_client(lib_dir=db.get('oracle_home') or None)
            except Exception:
                pass
        except ImportError:
            try:
                import cx_Oracle as drv  # type: ignore
            except ImportError:
                result['status'] = 'reachable'
                result['check_status'] = 'completed'
                result['error'] = 'TCP OK. Install oracledb or cx_Oracle for full check.'
                return result

        dsn = drv.makedsn(host, port, service_name=db.get('service_name',''))
        t0 = datetime.datetime.now()
        conn = drv.connect(user=username, password=password, dsn=dsn)
        result['response_ms'] = round((datetime.datetime.now()-t0).total_seconds()*1000, 1)
        cur = conn.cursor()

        cur.execute("SELECT BANNER FROM V$VERSION WHERE ROWNUM=1")
        row = cur.fetchone()
        result['db_version'] = row[0][:80] if row else '—'

        cur.execute("SELECT STATUS,TO_CHAR(STARTUP_TIME,'YYYY-MM-DD HH24:MI') FROM V$INSTANCE")
        row = cur.fetchone()
        if row:
            result['instance_status'] = row[0]
            result['startup_time'] = row[1] or '—'

        try:
            cur.execute("SELECT ROUND(SUM(BYTES)/1073741824,2) FROM DBA_DATA_FILES")
            row = cur.fetchone()
            result['db_size_gb'] = f"{row[0]} GB" if row and row[0] else '—'
        except Exception:
            result['db_size_gb'] = 'N/A'

        try:
            cur.execute("""SELECT COUNT(*),
                (SELECT VALUE FROM V$PARAMETER WHERE NAME='sessions')
                FROM V$SESSION WHERE STATUS='ACTIVE'""")
            row = cur.fetchone()
            if row:
                result['sessions_current'] = row[0]
                result['sessions_max'] = row[1] or '—'
        except Exception:
            pass

        try:
            cur.execute("""SELECT a.TABLESPACE_NAME,
                ROUND((1-(a.BYTES/b.BYTES))*100,1) PCT
                FROM (SELECT TABLESPACE_NAME,SUM(BYTES) BYTES FROM DBA_FREE_SPACE GROUP BY TABLESPACE_NAME) a,
                     (SELECT TABLESPACE_NAME,SUM(BYTES) BYTES FROM DBA_DATA_FILES GROUP BY TABLESPACE_NAME) b
                WHERE a.TABLESPACE_NAME=b.TABLESPACE_NAME ORDER BY PCT DESC""")
            row = cur.fetchone()
            if row:
                result['worst_ts_name'] = row[0]
                result['worst_ts_pct'] = f"{row[1]}%"
        except Exception:
            pass

        try:
            cur.execute("SELECT MAX(COMPLETION_TIME) FROM V$BACKUP_SET WHERE BACKUP_TYPE='D' AND STATUS='AVAILABLE'")
            row = cur.fetchone()
            result['last_full_backup'] = str(row[0])[:16] if row and row[0] else 'Never'
            cur.execute("SELECT MAX(COMPLETION_TIME) FROM V$BACKUP_SET WHERE BACKUP_TYPE='I' AND STATUS='AVAILABLE'")
            row = cur.fetchone()
            result['last_inc_backup'] = str(row[0])[:16] if row and row[0] else 'Never'
            cur.execute("SELECT MAX(COMPLETION_TIME) FROM V$BACKUP_SET WHERE BACKUP_TYPE='L' AND STATUS='AVAILABLE'")
            row = cur.fetchone()
            result['last_arch_backup'] = str(row[0])[:16] if row and row[0] else 'Never'
        except Exception:
            result['last_full_backup'] = result['last_inc_backup'] = result['last_arch_backup'] = 'N/A'

        cur.close()
        result['status'] = 'healthy'
        result['check_status'] = 'completed'
        result['message'] = 'OK'
    except Exception as e:
        result['status'] = 'critical'
        result['check_status'] = 'completed'
        result['error'] = str(e)[:300]
    finally:
        if conn:
            try: conn.close()
            except: pass

    return result
