"""Linux server health check — SSH + system metrics."""
import socket, datetime, subprocess
from config_store import decrypt_password

def check_linux(srv: dict) -> dict:
    result = {
        'id': srv['id'], 'server_name': srv.get('server_name',''),
        'environment': srv.get('environment',''), 'host': srv.get('host',''),
        'status': 'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'os': '—', 'os_version': '—',
        'memory_gb': '—', 'memory_usage_pct': '—',
        'cpu_count': '—', 'cpu_load_avg': '—',
        'worst_disk': '—', 'worst_disk_pct': '—',
        'uptime': '—',
    }

    host = srv.get('host','')
    try:
        port = int(srv.get('ssh_port', 22))
    except ValueError:
        port = 22

    # Ping
    try:
        ping = subprocess.run(['ping','-c','1','-W','2', host],
                              capture_output=True, timeout=5)
        ping_ok = ping.returncode == 0
    except Exception:
        ping_ok = False

    # SSH TCP
    start = datetime.datetime.now()
    try:
        sock = socket.create_connection((host, port), timeout=5)
        banner = sock.recv(256).decode(errors='replace').strip()
        sock.close()
        result['response_ms'] = round((datetime.datetime.now()-start).total_seconds()*1000, 1)
        ssh_ok = True
    except Exception as e:
        ssh_ok = False
        result['error'] = f'SSH port {port} closed: {e}'

    if not ssh_ok and not ping_ok:
        result['status'] = 'critical'
        result['check_status'] = 'completed'
        result['error'] = 'Host unreachable'
        return result

    if not ssh_ok:
        result['status'] = 'warning'
        result['check_status'] = 'completed'
        return result

    # Try paramiko SSH for full metrics
    username = srv.get('username','')
    password = decrypt_password(srv.get('password_enc',''))
    key_path = srv.get('ssh_key_path','')

    try:
        import paramiko  # type: ignore
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kwargs = dict(hostname=host, port=port, username=username, timeout=15)
        if key_path:
            kwargs['key_filename'] = key_path
        elif password:
            kwargs['password'] = password
        client.connect(**kwargs)

        def run(cmd):
            _, out, _ = client.exec_command(cmd, timeout=10)
            return out.read().decode(errors='replace').strip()

        result['os'] = run("uname -s") or 'Linux'
        result['os_version'] = run("cat /etc/os-release | grep PRETTY_NAME | cut -d= -f2 | tr -d '\"'") or '—'
        result['uptime'] = run("uptime -p") or run("uptime") or '—'
        result['cpu_count'] = run("nproc") or '—'
        result['cpu_load_avg'] = run("cat /proc/loadavg | awk '{print $1,$2,$3}'") or '—'

        mem = run("free -m | awk 'NR==2{printf \"%s %s\", $2, $3}'")
        if mem:
            parts = mem.split()
            if len(parts) >= 2:
                total_mb = int(parts[0]); used_mb = int(parts[1])
                result['memory_gb'] = round(total_mb/1024, 1)
                result['memory_usage_pct'] = f"{round((used_mb/total_mb)*100,1)}%"

        disk = run("df -h --output=pcent,target | sort -rn | grep -v 'Use%' | head -5")
        if disk:
            lines = disk.strip().split('\n')
            for line in lines:
                parts = line.split()
                if parts:
                    pct_str = parts[0].replace('%','')
                    try:
                        pct = float(pct_str)
                        result['worst_disk'] = parts[1] if len(parts)>1 else '/'
                        result['worst_disk_pct'] = f"{pct_str}%"
                        break
                    except:
                        pass

        client.close()
        result['status'] = 'healthy'
        result['check_status'] = 'completed'
        result['message'] = 'SSH connected'

    except ImportError:
        result['status'] = 'reachable'
        result['check_status'] = 'completed'
        result['error'] = 'SSH port open. Install paramiko for full metrics.'
    except Exception as e:
        result['status'] = 'warning'
        result['check_status'] = 'completed'
        result['error'] = f'SSH metrics failed: {str(e)[:200]}'

    return result
