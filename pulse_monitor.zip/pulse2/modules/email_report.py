"""Email health report in HTML format."""
import smtplib, datetime
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config_store import get_email_config, decrypt_password

STATUS_COLOR = {
    'healthy': '#16a34a', 'warning': '#d97706', 'critical': '#dc2626',
    'unknown': '#6b7280', 'reachable': '#2563eb',
}

def _badge(status):
    c = STATUS_COLOR.get(status, '#6b7280')
    return f'<span style="background:{c};color:#fff;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600">{status.upper()}</span>'

def build_html_report(module: str, items: list) -> str:
    now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    total = len(items)
    healthy = sum(1 for i in items if (i.get('last_result') or {}).get('status') == 'healthy')
    critical = sum(1 for i in items if (i.get('last_result') or {}).get('status') == 'critical')

    rows = ''
    if module == 'oracle':
        for idx, db in enumerate(items, 1):
            r = db.get('last_result') or {}
            rows += f"""<tr>
            <td>{idx}</td><td><b>{db.get('db_name','')}</b></td>
            <td>{db.get('environment','')}</td><td>{db.get('host','')}</td>
            <td>{r.get('db_version','—')}</td><td>{r.get('db_size_gb','—')}</td>
            <td>{_badge(r.get('status','unknown'))}</td>
            <td>{r.get('instance_status','—')}</td><td>{r.get('startup_time','—')}</td>
            <td>{r.get('worst_ts_name','—')} {r.get('worst_ts_pct','')}</td>
            <td>{r.get('sessions_current','—')}/{r.get('sessions_max','—')}</td>
            <td>{r.get('last_full_backup','—')}</td><td>{r.get('last_inc_backup','—')}</td>
            <td>{r.get('last_arch_backup','—')}</td>
            <td>{r.get('checked_at','—')}</td>
            <td style="color:#dc2626">{r.get('error','')}</td>
            </tr>"""
        header = '<tr><th>#</th><th>DB Name</th><th>Env</th><th>Host</th><th>Version</th><th>Size</th><th>Status</th><th>Instance</th><th>Startup</th><th>Worst TS%</th><th>Sessions</th><th>Last Full</th><th>Last Inc</th><th>Last Arch</th><th>Checked</th><th>Error</th></tr>'

    elif module == 'sqlserver':
        for idx, inst in enumerate(items, 1):
            r = inst.get('last_result') or {}
            rows += f"""<tr>
            <td>{idx}</td><td><b>{inst.get('instance_name','')}</b></td>
            <td>{inst.get('environment','')}</td>
            <td>{r.get('full_version','—')}</td><td>{r.get('major_version','—')}</td>
            <td>{r.get('cu','—')}</td><td>{_badge(r.get('status','unknown'))}</td>
            <td>{r.get('instance_status','—')}</td><td>{r.get('agent_status','—')}</td>
            <td>{r.get('db_online','—')}/{r.get('db_total','—')}</td>
            <td>{r.get('edition','—')}</td><td>{r.get('os_version','—')}</td>
            <td>{r.get('sessions_current','—')}/{r.get('sessions_max','—')}</td>
            <td>{r.get('last_full_backup','—')}</td><td>{r.get('last_inc_backup','—')}</td>
            <td>{r.get('checked_at','—')}</td>
            <td style="color:#dc2626">{r.get('error','')}</td>
            </tr>"""
        header = '<tr><th>#</th><th>Instance</th><th>Env</th><th>Version</th><th>Year</th><th>CU</th><th>Status</th><th>Instance</th><th>Agent</th><th>DBs</th><th>Edition</th><th>OS</th><th>Sessions</th><th>Last Full</th><th>Last Log</th><th>Checked</th><th>Error</th></tr>'

    else:  # linux / windows
        for idx, srv in enumerate(items, 1):
            r = srv.get('last_result') or {}
            rows += f"""<tr>
            <td>{idx}</td><td><b>{srv.get('server_name','')}</b></td>
            <td>{srv.get('environment','')}</td><td>{_badge(r.get('status','unknown'))}</td>
            <td>{r.get('os','—')}</td><td>{r.get('os_version','—')}</td>
            <td>{r.get('memory_gb','—')}</td><td>{r.get('memory_usage_pct','—')}</td>
            <td>{r.get('cpu_count','—')}</td><td>{r.get('cpu_load_avg','—')}</td>
            <td>{r.get('worst_disk','—')} {r.get('worst_disk_pct','')}</td>
            <td>{r.get('uptime','—')}</td>
            <td>{r.get('checked_at','—')}</td>
            <td style="color:#dc2626">{r.get('error','')}</td>
            </tr>"""
        header = '<tr><th>#</th><th>Server</th><th>Env</th><th>Status</th><th>OS</th><th>OS Version</th><th>Mem (GB)</th><th>Mem%</th><th>CPUs</th><th>Load Avg</th><th>Worst Disk%</th><th>Uptime</th><th>Checked</th><th>Error</th></tr>'

    return f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
  body{{font-family:Segoe UI,sans-serif;background:#f8fafc;color:#1e293b;margin:0;padding:20px}}
  .header{{background:linear-gradient(135deg,#1e3a5f,#2563eb);color:#fff;padding:24px 32px;border-radius:12px;margin-bottom:24px}}
  .header h1{{margin:0;font-size:24px}} .header p{{margin:4px 0 0;opacity:.8;font-size:13px}}
  .summary{{display:flex;gap:16px;margin-bottom:24px}}
  .scard{{background:#fff;border-radius:10px;padding:16px 24px;flex:1;border:1px solid #e2e8f0;text-align:center}}
  .scard .num{{font-size:32px;font-weight:700}} .scard .lbl{{font-size:12px;color:#64748b}}
  .healthy{{color:#16a34a}} .critical{{color:#dc2626}} .total{{color:#2563eb}}
  table{{width:100%;border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.1)}}
  th{{background:#1e3a5f;color:#fff;padding:10px 12px;font-size:11px;text-align:left;white-space:nowrap}}
  td{{padding:9px 12px;border-bottom:1px solid #f1f5f9;font-size:12px;white-space:nowrap}}
  tr:hover td{{background:#f8fafc}}
  .footer{{text-align:center;color:#94a3b8;font-size:11px;margin-top:20px}}
</style></head><body>
<div class="header">
  <h1>⬡ Pulse — {module.upper()} Health Report</h1>
  <p>Generated: {now}</p>
</div>
<div class="summary">
  <div class="scard"><div class="num total">{total}</div><div class="lbl">Total</div></div>
  <div class="scard"><div class="num healthy">{healthy}</div><div class="lbl">Healthy</div></div>
  <div class="scard"><div class="num critical">{critical}</div><div class="lbl">Critical</div></div>
  <div class="scard"><div class="num" style="color:#d97706">{total-healthy-critical}</div><div class="lbl">Other</div></div>
</div>
<table><thead>{header}</thead><tbody>{rows}</tbody></table>
<div class="footer">Pulse Infrastructure Monitor • Automated Report</div>
</body></html>"""

def send_report(module: str, items: list, to_email: str) -> tuple[bool, str]:
    cfg = get_email_config()
    if not cfg.get('smtp_host'):
        return False, 'SMTP not configured'
    html = build_html_report(module, items)
    msg = MIMEMultipart('alternative')
    msg['Subject'] = f'Pulse Health Report — {module.upper()} — {datetime.datetime.now().strftime("%Y-%m-%d %H:%M")}'
    msg['From'] = cfg.get('from_email', cfg.get('smtp_user',''))
    msg['To'] = to_email
    msg.attach(MIMEText(html, 'html'))
    try:
        smtp_pass = decrypt_password(cfg.get('smtp_password_enc',''))
        port = int(cfg.get('smtp_port', 587))
        if cfg.get('tls', True):
            server = smtplib.SMTP(cfg['smtp_host'], port, timeout=15)
            server.starttls()
        else:
            server = smtplib.SMTP_SSL(cfg['smtp_host'], port, timeout=15)
        if cfg.get('smtp_user') and smtp_pass:
            server.login(cfg['smtp_user'], smtp_pass)
        server.sendmail(msg['From'], [to_email], msg.as_string())
        server.quit()
        return True, 'Email sent successfully'
    except Exception as e:
        return False, str(e)
