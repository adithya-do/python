"""Excel export for all Pulse modules using openpyxl."""
import io, datetime
from openpyxl import Workbook
from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side,
                              numbers as opxl_numbers)
from openpyxl.utils import get_column_letter

# Colour palette
HDR_FILL  = PatternFill("solid", fgColor="1A2744")
HDR_FONT  = Font(color="FFFFFF", bold=True, size=10, name="Calibri")
EVEN_FILL = PatternFill("solid", fgColor="EEF2F7")
RED_FILL  = PatternFill("solid", fgColor="FEE2E2")
WARN_FILL = PatternFill("solid", fgColor="FEF9C3")
OK_FILL   = PatternFill("solid", fgColor="DCFCE7")
THIN_BORDER = Border(
    left=Side(style='thin', color='CBD5E1'),
    right=Side(style='thin', color='CBD5E1'),
    top=Side(style='thin', color='CBD5E1'),
    bottom=Side(style='thin', color='CBD5E1'),
)

def _status_fill(status):
    if status == 'healthy':  return OK_FILL
    if status == 'critical': return RED_FILL
    if status in ('warning','reachable'): return WARN_FILL
    return None

# Column definitions per module
# (header, lambda item -> value, width, red_if_fn)
_ORACLE = [
    ("#",             lambda i,r,n: n,                                   5,  None),
    ("DB Name",       lambda i,r,n: i.get('db_name',''),                18, None),
    ("Hostname",      lambda i,r,n: r.get('hostname','—') if r else '—',20, None),
    ("Environment",   lambda i,r,n: i.get('environment',''),            12, None),
    ("TNS Alias",     lambda i,r,n: i.get('tns_alias',''),              18, None),
    ("DB Version",    lambda i,r,n: r.get('db_version','—') if r else '—', 16, None),
    ("DB Size",       lambda i,r,n: r.get('db_size_gb','—') if r else '—', 12, None),
    ("Status",        lambda i,r,n: (r.get('status') or '—') if r else '—', 10, None),
    ("Instance",      lambda i,r,n: r.get('instance_status','—') if r else '—', 10, None),
    ("TS Online",     lambda i,r,n: (f"{r.get('ts_online','—')}/{r.get('ts_total','—')}") if r else '—', 10,
     lambda i,r: r.get('ts_mismatch') if r else False),
    ("Worst TS%",     lambda i,r,n: r.get('worst_ts_pct','—') if r else '—', 10,
     lambda i,r: (r.get('worst_ts_num',0) or 0) >= 95 if r else False),
    ("Sessions",      lambda i,r,n: (f"{r.get('sessions_current','—')}/{r.get('sessions_max','—')}") if r else '—', 12, None),
    ("Last Backup",   lambda i,r,n: r.get('last_backup','—') if r else '—', 18,
     lambda i,r: (r.get('last_backup_days') or 0) > 3 if r else False),
    ("Last Arch",     lambda i,r,n: r.get('last_arch_backup','—') if r else '—', 18,
     lambda i,r: (r.get('last_arch_days') or 0) > 2 if r else False),
    ("Last Checked",  lambda i,r,n: r.get('checked_at','—') if r else '—', 18, None),
    ("Error",         lambda i,r,n: r.get('error','') if r else '',     30, None),
]
_SQL = [
    ("#",             lambda i,r,n: n,                                   5,  None),
    ("Instance",      lambda i,r,n: i.get('instance_name',''),          20, None),
    ("Host",          lambda i,r,n: i.get('host',''),                   18, None),
    ("Environment",   lambda i,r,n: i.get('environment',''),            12, None),
    ("Status",        lambda i,r,n: (r.get('status') or '—') if r else '—', 10, None),
    ("Version",       lambda i,r,n: r.get('full_version','—') if r else '—', 14, None),
    ("Year",          lambda i,r,n: r.get('major_version','—') if r else '—',8, None),
    ("CU",            lambda i,r,n: r.get('cu','—') if r else '—',      8,  None),
    ("Edition",       lambda i,r,n: r.get('edition','—') if r else '—', 12, None),
    ("Agent",         lambda i,r,n: r.get('agent_status','—') if r else '—', 8,
     lambda i,r: r.get('agent_status')=='Down' if r else False),
    ("Databases",     lambda i,r,n: (f"{r.get('db_online','—')}/{r.get('db_total','—')}") if r else '—', 12,
     lambda i,r: r.get('db_mismatch') if r else False),
    ("Sessions",      lambda i,r,n: (f"{r.get('sessions_current','—')}/{r.get('sessions_max','—')}") if r else '—', 12, None),
    ("Encryption",    lambda i,r,n: (f"{r.get('enc_encrypted','—')}/{r.get('enc_total','—')}") if r else '—', 12, None),
    ("Last Backup",   lambda i,r,n: r.get('last_backup','—') if r else '—', 18,
     lambda i,r: (r.get('last_backup_days') or 0) > 3 if r else False),
    ("Last Checked",  lambda i,r,n: r.get('checked_at','—') if r else '—', 18, None),
    ("Error",         lambda i,r,n: r.get('error','') if r else '',     30, None),
]
_SERVER = [
    ("#",            lambda i,r,n: n,                                    5,  None),
    ("Server Name",  lambda i,r,n: i.get('server_name',''),             20, None),
    ("IP Address",   lambda i,r,n: r.get('ip_address', i.get('host','')) if r else i.get('host',''), 15, None),
    ("Environment",  lambda i,r,n: i.get('environment',''),             12, None),
    ("Status",       lambda i,r,n: (r.get('status') or '—') if r else '—', 10, None),
    ("OS Version",   lambda i,r,n: r.get('os_version','—') if r else '—', 20, None),
    ("Mem (GB)",     lambda i,r,n: r.get('memory_gb','—') if r else '—', 10, None),
    ("Mem %",        lambda i,r,n: r.get('memory_usage_pct','—') if r else '—', 10,
     lambda i,r: float(str(r.get('memory_usage_pct','0')).replace('%','') or 0) >= 90 if r else False),
    ("CPUs",         lambda i,r,n: r.get('cpu_count','—') if r else '—', 8, None),
    ("Load Avg",     lambda i,r,n: r.get('cpu_load_avg','—') if r else '—', 12, None),
    ("Worst Disk%",  lambda i,r,n: (f"{r.get('worst_disk','—')} {r.get('worst_disk_pct','')}").strip() if r else '—', 18,
     lambda i,r: float(str(r.get('worst_disk_pct','0')).replace('%','') or 0) >= 90 if r else False),
    ("Uptime",       lambda i,r,n: r.get('uptime','—') if r else '—',  14, None),
    ("Last Checked", lambda i,r,n: r.get('checked_at','—') if r else '—', 18, None),
    ("Error",        lambda i,r,n: r.get('error','') if r else '',      30, None),
]

MODULE_COLS = {
    'oracle':    _ORACLE,
    'sqlserver': _SQL,
    'linux':     _SERVER,
    'windows':   _SERVER,
    'solaris':   _SERVER,
}

MODULE_LABELS = {
    'oracle':'Oracle','sqlserver':'SQL Server',
    'linux':'Linux','windows':'Windows','solaris':'Solaris'
}

def export_module_excel(module: str, items: list) -> bytes:
    """Return xlsx bytes for the given module and items."""
    wb = Workbook()
    ws = wb.active
    ws.title = MODULE_LABELS.get(module, module)

    cols = MODULE_COLS.get(module, _SERVER)

    # Title row
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=len(cols))
    title_cell = ws.cell(1, 1,
        f"Pulse 3 — {MODULE_LABELS.get(module, module)} Health Report  |  "
        f"Generated: {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    title_cell.font  = Font(bold=True, size=12, color="FFFFFF", name="Calibri")
    title_cell.fill  = PatternFill("solid", fgColor="1A2744")
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[1].height = 22

    # Header row
    for ci, (hdr, _, width, _) in enumerate(cols, 1):
        cell = ws.cell(2, ci, hdr)
        cell.font      = HDR_FONT
        cell.fill      = HDR_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border    = THIN_BORDER
        ws.column_dimensions[get_column_letter(ci)].width = width
    ws.row_dimensions[2].height = 18

    # Data rows
    for row_idx, item in enumerate(items, 1):
        r   = item.get('last_result') or {}
        st  = r.get('status', 'unknown') if r else 'unknown'
        sf  = _status_fill(st)
        even = row_idx % 2 == 0

        for ci, (_, fn, _, red_fn) in enumerate(cols, 1):
            try:   val = fn(item, r, row_idx)
            except: val = '—'
            cell = ws.cell(row_idx + 2, ci, val)
            cell.font      = Font(size=9, name="Calibri")
            cell.border    = THIN_BORDER
            cell.alignment = Alignment(vertical="center")
            if ci == 1:   # # column: centre
                cell.alignment = Alignment(horizontal="center", vertical="center")
            if red_fn:
                try:
                    if red_fn(item, r):
                        cell.fill = RED_FILL
                        cell.font = Font(size=9, name="Calibri", bold=True, color="991B1B")
                        continue
                except Exception:
                    pass
            if sf and ci > 1:
                cell.fill = sf
            elif even:
                cell.fill = EVEN_FILL

    # Freeze header rows
    ws.freeze_panes = "A3"

    # Auto-filter
    ws.auto_filter.ref = f"A2:{get_column_letter(len(cols))}{len(items)+2}"

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
