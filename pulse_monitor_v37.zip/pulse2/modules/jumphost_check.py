"""
SQL Server via Windows Jump Host.

Connection model:
  Pulse (Linux) ──SSH──► Windows Jump Host ──sqlcmd──► SQL Server

Two SQL Server auth modes via the jump host:
  1. Windows / Active Directory (use_windows_auth = true, default)
       sqlcmd -S SERVER -E
       Uses the identity of the SSH session user on the jump host.
       The jump host SSH credential must be an AD account with SQL access.

  2. SQL Server authentication (use_windows_auth = false)
       sqlcmd -S SERVER -U "user" -P "pass"
       Uses the SQL Server credential stored in Pulse credential store.
"""
import re, datetime
from config_store import resolve_credentials, get_jump_hosts


def _get_jh(jh_id):
    if not jh_id:
        return None
    for h in get_jump_hosts():
        if h['id'] == jh_id:
            return h
    return None


def check_via_jumphost(inst, result):
    """
    SSH to the Windows jump host and run sqlcmd against the target SQL Server.
    Populates result dict in-place. Returns True on success, False on failure.
    """
    jh = _get_jh(inst.get('jump_host_id', ''))
    if not jh:
        result['error'] = 'Jump host not found — check Settings → Jump Hosts'
        return False

    jh_host = jh.get('host', '').strip()
    try:   jh_port = int(jh.get('ssh_port', 22))
    except: jh_port = 22

    jh_user, jh_pass = resolve_credentials(jh)
    jh_key  = jh.get('ssh_key_path', '').strip()
    use_win_auth = str(jh.get('use_windows_auth', 'true')).lower() in ('true', '1', 'yes')

    if not jh_host or not jh_user:
        result['error'] = 'Jump host host/credential not configured (Settings → Jump Hosts)'
        return False

    # ── Build target SERVER string ────────────────────────────────────────
    host_raw = inst.get('host', '').strip()
    hostname = host_raw
    instance = ''
    port     = 1433
    bs       = chr(92)           # backslash

    if ',' in hostname:
        h, p = hostname.rsplit(',', 1)
        hostname = h.strip()
        try: port = int(p.strip())
        except ValueError: pass
    else:
        try: port = int(inst.get('port', 1433) or 1433)
        except (ValueError, TypeError): port = 1433

    if bs in hostname:
        hostname, instance = hostname.split(bs, 1)
    hostname = hostname.strip()
    instance = instance.strip()

    if instance:
        server_str = f"{hostname}{bs}{instance},{port}" if port != 1433 \
                     else f"{hostname}{bs}{instance}"
    else:
        server_str = f"{hostname},{port}"

    # SQL auth credentials (used only when use_windows_auth = False)
    sql_user, sql_pass = resolve_credentials(inst)

    try:
        import paramiko  # type: ignore

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kw = dict(hostname=jh_host, port=jh_port, username=jh_user,
                  timeout=15, banner_timeout=10, auth_timeout=10)
        if jh_key:    kw['key_filename'] = jh_key
        elif jh_pass: kw['password']     = jh_pass
        client.connect(**kw)

        def run(cmd):
            try:
                _, out, _ = client.exec_command(cmd, timeout=20)
                return out.read().decode(errors='replace').strip()
            except Exception:
                return ''

        # ── Build sqlcmd auth flags ────────────────────────────────────────
        if use_win_auth:
            # -E = trusted connection (Windows/AD auth of the SSH session user)
            auth_flags = '-E'
        else:
            if not sql_user or not sql_pass:
                result['error'] = 'SQL auth selected but no SQL credentials configured'
                client.close()
                return False
            # Escape double-quotes inside user/pass for cmd.exe
            safe_u = sql_user.replace('"', '\\"')
            safe_p = sql_pass.replace('"', '\\"')
            auth_flags = f'-U "{safe_u}" -P "{safe_p}"'

        def sqlcmd(query):
            """Run a single-line query via sqlcmd, return first result line."""
            # -h -1  = no column headers
            # -W     = strip trailing spaces
            # -l 10  = login timeout 10s
            # Wrap query in double quotes for cmd.exe; escape inner double-quotes
            safe_q = query.replace('"', '\\"')
            cmd = f'sqlcmd -S "{server_str}" {auth_flags} -Q "{safe_q}" -h -1 -W -l 10 2>&1'
            out = run(cmd)
            # Filter sqlcmd noise lines
            lines = [l.strip() for l in out.splitlines()
                     if l.strip()
                     and '----' not in l
                     and 'rows affected' not in l.lower()
                     and 'changed database' not in l.lower()
                     and 'sqlcmd:' not in l.lower()]
            return lines[0] if lines else ''

        # ── Connectivity test ─────────────────────────────────────────────
        ver_raw = sqlcmd('SELECT @@VERSION')
        if not ver_raw or 'error' in ver_raw.lower() or 'login failed' in ver_raw.lower():
            if use_win_auth:
                hint = (f'Windows auth failed. Ensure the SSH user ({jh_user}) '
                        f'is an AD account with SQL Server login on {server_str}.')
            else:
                hint = f'SQL auth failed for user {sql_user} on {server_str}.'
            result['error'] = (
                f'Jump host ({jh_host}) reached but sqlcmd could not connect '
                f'to {server_str}. {hint} Raw: {ver_raw[:150]}'
            )
            client.close()
            return False

        # ── Version ───────────────────────────────────────────────────────
        m = re.search(r'(\d+\.\d+\.\d+\.\d+)', ver_raw)
        if m:
            fv = m.group(1)
            result['full_version'] = fv
            major = fv.split('.')[0]
            result['major_version'] = {
                '16':'2022','15':'2019','14':'2017',
                '13':'2016','12':'2014','11':'2012'
            }.get(major, major)

        result['instance_status'] = 'ONLINE'

        # ── Edition ───────────────────────────────────────────────────────
        ed = sqlcmd("SELECT CAST(SERVERPROPERTY('Edition') AS NVARCHAR(128))")
        if ed:
            el = ed.lower()
            result['edition'] = ('Enterprise' if 'enterprise' in el else
                                 'Standard'   if 'standard'   in el else
                                 'Developer'  if 'developer'  in el else
                                 'Express'    if 'express'    in el else ed.split()[0])

        # ── CU ────────────────────────────────────────────────────────────
        cu = sqlcmd("SELECT CAST(SERVERPROPERTY('ProductUpdateLevel') AS NVARCHAR(64))")
        result['cu'] = cu or '—'

        # ── Agent ─────────────────────────────────────────────────────────
        ag = sqlcmd("SELECT status FROM sys.dm_server_services WHERE servicename LIKE 'SQL Server Agent%'")
        if ag and ag.strip().isdigit():
            result['agent_status'] = 'Up' if int(ag.strip()) == 4 else 'Down'

        # ── OS version ────────────────────────────────────────────────────
        osv = sqlcmd("SELECT CAST(SERVERPROPERTY('WindowsVersion') AS NVARCHAR(128))")
        result['os_version'] = osv or '—'

        # ── Sessions ─────────────────────────────────────────────────────
        sc = sqlcmd("SELECT COUNT(*) FROM sys.dm_exec_sessions WHERE is_user_process=1")
        sm = sqlcmd("SELECT value_in_use FROM sys.configurations WHERE name='max connections'")
        if sc and sc.strip().isdigit(): result['sessions_current'] = int(sc.strip())
        if sm and sm.strip().isdigit(): result['sessions_max']     = int(sm.strip())

        # ── Databases ─────────────────────────────────────────────────────
        dt = sqlcmd("SELECT COUNT(*) FROM sys.databases")
        do = sqlcmd("SELECT COUNT(*) FROM sys.databases WHERE state_desc='ONLINE'")
        if dt and dt.strip().isdigit():
            result['db_total']    = int(dt.strip())
            result['db_online']   = int(do.strip()) if (do and do.strip().isdigit()) else 0
            result['db_mismatch'] = result['db_online'] < result['db_total']

        # ── Last backup ───────────────────────────────────────────────────
        bk = sqlcmd(
            "SELECT TOP 1 CONVERT(VARCHAR(16),backup_finish_date,120) "
            "FROM msdb.dbo.backupset WHERE type='D' ORDER BY backup_finish_date DESC"
        )
        if bk:
            result['last_backup'] = bk
            try:
                dt_bk = datetime.datetime.strptime(bk, '%Y-%m-%d %H:%M')
                result['last_backup_days'] = (datetime.datetime.now() - dt_bk).days
            except Exception:
                pass

        # ── Encryption ────────────────────────────────────────────────────
        et = sqlcmd("SELECT COUNT(*) FROM sys.databases WHERE database_id>4")
        ee = sqlcmd("SELECT COUNT(*) FROM sys.dm_database_encryption_keys WHERE encryption_state=3")
        if et and et.strip().isdigit():
            result['enc_total']     = int(et.strip())
            result['enc_encrypted'] = int(ee.strip()) if (ee and ee.strip().isdigit()) else 0

        client.close()
        auth_label = 'Windows/AD auth' if use_win_auth else 'SQL auth'
        result.update(
            status='healthy', check_status='completed',
            message=f'Via jump host {jh.get("label", jh_host)} ({auth_label})',
            error=''
        )
        return True

    except ImportError:
        result['error'] = 'paramiko not installed on Pulse server (pip install paramiko)'
        return False
    except Exception as e:
        err = str(e)
        result['error'] = f'Jump host SSH error: {err[:200]}'
        return False
