"""SQL Server detail metrics — OEM-style dashboard."""
import datetime, re

def collect_sqlserver_detail(inst):
    from config_store import resolve_credentials, get_jump_hosts
    result = {
        'overview': {}, 'databases': [], 'performance': {},
        'top_sql': [], 'sessions': [], 'logins': [],
        'waits': [], 'configuration': [], 'error': ''
    }

    def run_queries(execute_fn):
        # Instance overview
        row = execute_fn("""
            SELECT
              CAST(SERVERPROPERTY('MachineName') AS NVARCHAR(128)),
              CAST(SERVERPROPERTY('InstanceName') AS NVARCHAR(128)),
              CAST(SERVERPROPERTY('Edition') AS NVARCHAR(128)),
              CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR(128)),
              CAST(SERVERPROPERTY('ProductUpdateLevel') AS NVARCHAR(64)),
              CAST(SERVERPROPERTY('ProductLevel') AS NVARCHAR(64)),
              CAST(SERVERPROPERTY('Collation') AS NVARCHAR(128)),
              CAST(SERVERPROPERTY('IsFullTextInstalled') AS NVARCHAR(8)),
              CAST(SERVERPROPERTY('IsClustered') AS NVARCHAR(8)),
              CAST(SERVERPROPERTY('IsHadrEnabled') AS NVARCHAR(8)),
              @@SERVERNAME
        """, scalar=False)
        if row:
            result['overview'] = {
                'machine': row[0], 'instance': row[1], 'edition': row[2],
                'version': row[3], 'cu': row[4], 'sp': row[5],
                'collation': row[6], 'fulltext': row[7],
                'clustered': row[8], 'hadr': row[9], 'server_name': row[10]
            }

        # Service startup time
        svc = execute_fn("""
            SELECT sqlserver_start_time FROM sys.dm_os_sys_info""", scalar=False)
        if svc:
            result['overview']['startup_time'] = str(svc[0])[:16]

        # Databases
        db_rows = execute_fn("""
            SELECT d.name, d.state_desc, d.recovery_model_desc,
                   d.log_reuse_wait_desc, d.is_encrypted,
                   d.compatibility_level, d.create_date,
                   CAST(SUM(f.size)*8/1024.0/1024.0 AS DECIMAL(10,2)) size_gb,
                   b.last_full, b.last_diff, b.last_log
            FROM sys.databases d
            JOIN sys.master_files f ON d.database_id=f.database_id
            LEFT JOIN (
              SELECT database_name,
                MAX(CASE WHEN type='D' THEN CONVERT(VARCHAR(16),backup_finish_date,120) END) last_full,
                MAX(CASE WHEN type='I' THEN CONVERT(VARCHAR(16),backup_finish_date,120) END) last_diff,
                MAX(CASE WHEN type='L' THEN CONVERT(VARCHAR(16),backup_finish_date,120) END) last_log
              FROM msdb.dbo.backupset GROUP BY database_name
            ) b ON d.name=b.database_name
            GROUP BY d.name,d.state_desc,d.recovery_model_desc,d.log_reuse_wait_desc,
                     d.is_encrypted,d.compatibility_level,d.create_date,
                     b.last_full,b.last_diff,b.last_log
            ORDER BY d.name""", scalar=False, multi=True)
        result['databases'] = [
            {'name':r[0],'state':r[1],'recovery':r[2],'log_reuse':r[3],
             'encrypted':r[4],'compat':r[5],'created':str(r[6])[:10],
             'size_gb':r[7],'last_full':r[8],'last_diff':r[9],'last_log':r[10]}
            for r in (db_rows or [])
        ]

        # Top SQL (last 30 min)
        top_rows = execute_fn("""
            SELECT TOP 20
              r.sql_handle, t.text,
              r.execution_count, r.total_elapsed_time/1000 elapsed_ms,
              r.total_cpu_time/1000 cpu_ms,
              r.total_logical_reads, r.total_physical_reads,
              r.total_worker_time/1000 worker_ms,
              CASE WHEN r.execution_count=0 THEN 0
                   ELSE r.total_elapsed_time/r.execution_count/1000 END avg_ms,
              r.last_execution_time
            FROM sys.dm_exec_query_stats r
            CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) t
            WHERE r.last_execution_time > DATEADD(MINUTE,-30,GETDATE())
            ORDER BY r.total_elapsed_time DESC""", scalar=False, multi=True)
        result['top_sql'] = [
            {'sql_text': str(r[1])[:120], 'executions': r[2],
             'elapsed_ms': r[3], 'cpu_ms': r[4],
             'logical_reads': r[5], 'physical_reads': r[6],
             'worker_ms': r[7], 'avg_ms': r[8],
             'last_exec': str(r[9])[:16] if r[9] else '—'}
            for r in (top_rows or [])
        ]

        # Active sessions
        sess_rows = execute_fn("""
            SELECT TOP 50
              s.session_id, s.login_name, s.status, s.host_name,
              s.program_name, s.database_id, s.cpu_time, s.memory_usage,
              s.total_elapsed_time/1000 elapsed_ms,
              s.reads, s.writes,
              r.wait_type, r.blocking_session_id,
              t.text
            FROM sys.dm_exec_sessions s
            LEFT JOIN sys.dm_exec_requests r ON s.session_id=r.session_id
            OUTER APPLY sys.dm_exec_sql_text(r.sql_handle) t
            WHERE s.is_user_process=1
            ORDER BY s.cpu_time DESC""", scalar=False, multi=True)
        result['sessions'] = [
            {'session_id':r[0],'login':r[1],'status':r[2],'host':r[3],
             'program':r[4],'db_id':r[5],'cpu_ms':r[6],'memory':r[7],
             'elapsed_ms':r[8],'reads':r[9],'writes':r[10],
             'wait_type':r[11],'blocking':r[12],
             'sql_text':str(r[13])[:80] if r[13] else ''}
            for r in (sess_rows or [])
        ]

        # Wait stats (top 15, exclude idle)
        wait_rows = execute_fn("""
            SELECT TOP 15 wait_type, waiting_tasks_count,
                   wait_time_ms, max_wait_time_ms,
                   signal_wait_time_ms
            FROM sys.dm_os_wait_stats
            WHERE wait_type NOT IN ('SLEEP_TASK','BROKER_TO_FLUSH','BROKER_TASK_STOP',
              'CLR_AUTO_EVENT','DISPATCHER_QUEUE_SEMAPHORE','FT_IFTS_SCHEDULER_IDLE_WAIT',
              'HADR_WORK_QUEUE','LOGMGR_QUEUE','ONDEMAND_TASK_QUEUE','REQUEST_FOR_DEADLOCK_SEARCH',
              'RESOURCE_QUEUE','SERVER_IDLE_CHECK','SLEEP_DBSTARTUP','SLEEP_DCOMSTARTUP',
              'SLEEP_MASTERDBREADY','SLEEP_MASTERMDREADY','SLEEP_MASTERUPGRADED',
              'SLEEP_MSDBSTARTUP','SLEEP_SYSTEMTASK','SLEEP_TEMPDBSTARTUP',
              'SNI_HTTP_ACCEPT','SP_SERVER_DIAGNOSTICS_SLEEP','SQLTRACE_BUFFER_FLUSH',
              'WAITFOR','WAIT_XTP_OFFLINE_CKPT_NEW_LOG','XE_DISPATCHER_WAIT','XE_TIMER_EVENT')
              AND waiting_tasks_count > 0
            ORDER BY wait_time_ms DESC""", scalar=False, multi=True)
        result['waits'] = [
            {'wait_type':r[0],'tasks':r[1],'wait_ms':r[2],
             'max_ms':r[3],'signal_ms':r[4]}
            for r in (wait_rows or [])
        ]

        # Logins / Security
        login_rows = execute_fn("""
            SELECT p.name, p.type_desc, p.is_disabled, p.create_date,
                   p.default_database_name, p.is_policy_checked,
                   STUFF((SELECT ','+dp.name FROM sys.database_principals dp
                          JOIN sys.database_role_members drm ON dp.principal_id=drm.role_principal_id
                          JOIN sys.server_principals sp2 ON drm.member_principal_id=sp2.principal_id
                          WHERE sp2.name=p.name FOR XML PATH('')),1,1,'') roles
            FROM sys.server_principals p
            WHERE p.type IN ('S','U','G')
            ORDER BY p.name""", scalar=False, multi=True)
        result['logins'] = [
            {'name':r[0],'type':r[1],'disabled':r[2],
             'created':str(r[3])[:10],'default_db':r[4],
             'policy_checked':r[5],'roles':r[6]}
            for r in (login_rows or [])
        ]

        # Key configuration
        cfg_rows = execute_fn("""
            SELECT name, value_in_use, description
            FROM sys.configurations
            WHERE name IN ('max degree of parallelism','cost threshold for parallelism',
              'max server memory (MB)','min server memory (MB)','max connections',
              'remote login timeout (s)','query wait (s)','fill factor (%)',
              'optimize for ad hoc workloads','database mail XPs',
              'show advanced options','xp_cmdshell','clr enabled',
              'backup compression default')
            ORDER BY name""", scalar=False, multi=True)
        result['configuration'] = [
            {'name':r[0],'value':r[1],'description':r[2]}
            for r in (cfg_rows or [])
        ]

    # Wire up connection
    if inst.get('jump_host_id'):
        # Via jump host sqlcmd
        from modules.jumphost_check import _get_jh
        from config_store import resolve_credentials as rcred
        jh = _get_jh(inst['jump_host_id'])
        if not jh:
            result['error'] = 'Jump host not found'; return result

        jh_user, jh_pass = rcred(jh)
        jh_key  = jh.get('ssh_key_path','')
        use_win = str(jh.get('use_windows_auth','true')).lower() in ('true','1','yes')

        host_raw = inst.get('host','').strip()
        hostname = host_raw; instance_name=''; port=1433; bs=chr(92)
        if ',' in hostname:
            h,p=hostname.rsplit(',',1); hostname=h.strip()
            try: port=int(p.strip())
            except: pass
        if bs in hostname:
            hostname, instance_name = hostname.split(bs,1)
        server_str = (f"{hostname}{bs}{instance_name}" if instance_name else f"{hostname},{port}")
        sql_u, sql_p = rcred(inst)
        auth = '-E' if use_win else f'-U "{sql_u}" -P "{sql_p}"'

        try:
            import paramiko
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            kw = dict(hostname=jh.get('host'), port=int(jh.get('ssh_port',22)),
                      username=jh_user, timeout=15)
            if jh_key: kw['key_filename']=jh_key
            elif jh_pass: kw['password']=jh_pass
            client.connect(**kw)

            def execute_fn(sql, scalar=True, multi=False):
                safe_q = sql.replace('"','\\"')
                cmd = f'sqlcmd -S "{server_str}" {auth} -Q "{safe_q}" -s "|" -W -h -1 -l 10 2>&1'
                _,out,_ = client.exec_command(cmd, timeout=30)
                raw = out.read().decode(errors='replace').strip()
                lines = [l.strip() for l in raw.splitlines()
                         if l.strip() and '---' not in l
                         and 'rows affected' not in l.lower()
                         and 'changed database' not in l.lower()
                         and 'sqlcmd:' not in l.lower()]
                if not lines: return None if not multi else []
                if multi:
                    return [l.split('|') for l in lines]
                row = lines[0].split('|') if '|' in lines[0] else [lines[0]]
                return row[0] if scalar else row

            run_queries(execute_fn)
            client.close()
        except Exception as e:
            result['error'] = str(e)[:300]
    else:
        # Direct pyodbc
        try:
            import pyodbc
            from config_store import resolve_credentials as rcred
            username, password = rcred(inst)
            if not username:
                result['error'] = 'No credentials'; return result
            host_raw = inst.get('host','').strip(); bs=chr(92)
            hostname=host_raw; instance_name=''; port=1433
            if ',' in hostname:
                h,p=hostname.rsplit(',',1); hostname=h.strip()
                try: port=int(p.strip())
                except: pass
            if bs in hostname:
                hostname,instance_name=hostname.split(bs,1)
            dsn = f"{hostname}{bs}{instance_name}" if instance_name else f"{hostname},{port}"
            conn_str = (f"DRIVER={{ODBC Driver 18 for SQL Server}};SERVER={dsn};"
                        f"UID={username};PWD={password};TrustServerCertificate=yes;Encrypt=yes;Connection Timeout=15;")
            conn = pyodbc.connect(conn_str,timeout=15)
            cur  = conn.cursor()

            def execute_fn(sql, scalar=True, multi=False):
                try:
                    cur.execute(sql)
                    rows = cur.fetchall()
                    if not rows: return None if not multi else []
                    if multi: return [list(r) for r in rows]
                    row = list(rows[0])
                    return row[0] if scalar else row
                except Exception as e:
                    return None if not multi else []

            run_queries(execute_fn)
            cur.close(); conn.close()
        except Exception as e:
            result['error'] = str(e)[:300]

    return result
