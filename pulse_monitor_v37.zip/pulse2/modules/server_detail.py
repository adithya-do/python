"""Linux / Windows / Solaris OEM-style detail collector."""
import datetime

def collect_server_detail(srv, module):
    from config_store import resolve_credentials
    result = {
        'system': {}, 'cpu': {}, 'memory': {}, 'disk': [],
        'network': [], 'processes': [], 'services': [],
        'history': [], 'error': ''
    }
    host = srv.get('host','')
    try: port = int(srv.get('ssh_port',22))
    except: port = 22
    username, password = resolve_credentials(srv)
    key_path = srv.get('ssh_key_path','')

    if not username:
        result['error'] = 'No credentials'; return result

    try:
        import paramiko
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kw = dict(hostname=host, port=port, username=username, timeout=15)
        if key_path: kw['key_filename']=key_path
        elif password: kw['password']=password
        client.connect(**kw)

        def run(cmd):
            try:
                _,out,_ = client.exec_command(cmd, timeout=15)
                return out.read().decode(errors='replace').strip()
            except: return ''

        if module == 'windows':
            # Windows via PowerShell over SSH
            def ps(cmd):
                return run(f'powershell -Command "{cmd}"')

            result['system'] = {
                'hostname':   ps('(Get-CimInstance Win32_ComputerSystem).Name'),
                'os':         ps('(Get-CimInstance Win32_OperatingSystem).Caption'),
                'os_version': ps('(Get-CimInstance Win32_OperatingSystem).Version'),
                'os_arch':    ps('(Get-CimInstance Win32_OperatingSystem).OSArchitecture'),
                'manufacturer': ps('(Get-CimInstance Win32_ComputerSystem).Manufacturer'),
                'model':      ps('(Get-CimInstance Win32_ComputerSystem).Model'),
                'domain':     ps('(Get-CimInstance Win32_ComputerSystem).Domain'),
                'last_boot':  ps('(Get-CimInstance Win32_OperatingSystem).LastBootUpTime'),
                'timezone':   ps('[TimeZoneInfo]::Local.DisplayName'),
                'uptime':     ps('(Get-Date) - (gcim Win32_OperatingSystem).LastBootUpTime | '
                                 'Select-Object -ExpandProperty Days'),
            }
            cpu_out = ps('Get-CimInstance Win32_Processor | '
                         'Select-Object Name,NumberOfCores,NumberOfLogicalProcessors,'
                         'MaxClockSpeed,LoadPercentage | ConvertTo-Csv -NoTypeInformation | '
                         'Select-Object -Skip 1')
            parts = [p.strip('"') for p in cpu_out.split(',')]
            result['cpu'] = {
                'model': parts[0] if len(parts)>0 else '—',
                'cores': parts[1] if len(parts)>1 else '—',
                'threads': parts[2] if len(parts)>2 else '—',
                'speed_mhz': parts[3] if len(parts)>3 else '—',
                'load_pct': parts[4] if len(parts)>4 else '—',
            }
            mem_out = ps('$os=Get-CimInstance Win32_OperatingSystem; '
                         '[int]($os.TotalVisibleMemorySize/1MB),' +
                         '[int]($os.FreePhysicalMemory/1MB),' +
                         '[int]($os.TotalVirtualMemorySize/1MB),' +
                         '[int]($os.FreeVirtualMemory/1MB) -join ","')
            mp = mem_out.split(',')
            result['memory'] = {
                'total_gb':  round(int(mp[0])/1024,1) if len(mp)>0 and mp[0].isdigit() else '—',
                'free_gb':   round(int(mp[1])/1024,1) if len(mp)>1 and mp[1].isdigit() else '—',
                'used_pct':  round((1-int(mp[1])/max(int(mp[0]),1))*100,1) if len(mp)>1 and mp[0].isdigit() else '—',
                'virt_total_gb': round(int(mp[2])/1024,1) if len(mp)>2 and mp[2].isdigit() else '—',
            }
            disk_out = ps("Get-PSDrive -PSProvider FileSystem | "
                          "Where-Object{$_.Used -gt 0} | "
                          "Select-Object Name,@{n='UsedGB';e={[math]::Round($_.Used/1GB,1)}},"
                          "@{n='FreeGB';e={[math]::Round($_.Free/1GB,1)}},"
                          "@{n='TotalGB';e={[math]::Round(($_.Used+$_.Free)/1GB,1)}} | "
                          "ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1")
            for line in disk_out.splitlines():
                parts = [p.strip('"') for p in line.split(',')]
                if len(parts) >= 4:
                    try:
                        total = float(parts[3]); used = float(parts[1])
                        result['disk'].append({
                            'mount': parts[0]+':', 'used_gb': parts[1],
                            'free_gb': parts[2], 'total_gb': parts[3],
                            'pct': round(used/max(total,0.01)*100,1)
                        })
                    except: pass
            proc_out = ps("Get-Process | Sort-Object CPU -Descending | "
                          "Select-Object -First 15 Name,Id,CPU,"
                          "@{n='MemMB';e={[math]::Round($_.WorkingSet/1MB,1)}} | "
                          "ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1")
            for line in proc_out.splitlines():
                parts = [p.strip('"') for p in line.split(',')]
                if len(parts) >= 4:
                    result['processes'].append({'name':parts[0],'pid':parts[1],'cpu':parts[2],'mem_mb':parts[3]})
            svc_out = ps("Get-Service | Where-Object{$_.Status -in 'Running','Stopped'} | "
                         "Select-Object Name,DisplayName,Status | "
                         "ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1")
            for line in svc_out.splitlines()[:30]:
                parts = [p.strip('"') for p in line.split(',')]
                if len(parts) >= 3:
                    result['services'].append({'name':parts[0],'display':parts[1],'status':parts[2]})

        else:  # Linux / Solaris
            # OS info
            result['system'] = {
                'hostname':   run('hostname'),
                'os':         run("cat /etc/os-release 2>/dev/null | grep '^PRETTY_NAME' | cut -d= -f2 | tr -d '\"' || uname -s"),
                'kernel':     run('uname -r'),
                'arch':       run('uname -m'),
                'uptime':     run("awk '{d=int($1/86400);h=int(($1%86400)/3600);m=int(($1%3600)/60);printf \"%dd %dh %dm\",d,h,m}' /proc/uptime 2>/dev/null || uptime"),
                'timezone':   run('timedatectl 2>/dev/null | grep "Time zone" | awk \'{print $3}\' || date +%Z'),
                'fqdn':       run('hostname -f 2>/dev/null || hostname'),
                'ip':         run("ip route get 1 2>/dev/null | awk '{print $7;exit}' || hostname -I 2>/dev/null | awk '{print $1}'"),
            }
            # CPU
            cpuinfo = run('cat /proc/cpuinfo 2>/dev/null')
            cpu_model = '—'
            for line in cpuinfo.splitlines():
                if 'model name' in line:
                    cpu_model = line.split(':',1)[-1].strip(); break
            result['cpu'] = {
                'model':      cpu_model,
                'cores':      run('nproc 2>/dev/null || grep -c "^processor" /proc/cpuinfo'),
                'load_1':     run("awk '{print $1}' /proc/loadavg 2>/dev/null"),
                'load_5':     run("awk '{print $2}' /proc/loadavg 2>/dev/null"),
                'load_15':    run("awk '{print $3}' /proc/loadavg 2>/dev/null"),
                'cpu_pct':    run("top -bn1 2>/dev/null | grep '%Cpu' | awk '{print 100-$8}' || echo '—'"),
                'context_switches': run("grep 'ctxt' /proc/stat 2>/dev/null | awk '{print $2}'"),
            }
            # Memory
            mem_raw = run('cat /proc/meminfo 2>/dev/null')
            mvals = {}
            for line in mem_raw.splitlines():
                parts = line.split()
                if len(parts) >= 2:
                    try: mvals[parts[0].rstrip(':')] = int(parts[1])
                    except: pass
            total_kb = mvals.get('MemTotal',0)
            avail_kb = mvals.get('MemAvailable', mvals.get('MemFree',0))
            swap_total = mvals.get('SwapTotal',0)
            swap_free  = mvals.get('SwapFree',0)
            result['memory'] = {
                'total_gb':  round(total_kb/1048576,2),
                'used_gb':   round((total_kb-avail_kb)/1048576,2),
                'avail_gb':  round(avail_kb/1048576,2),
                'used_pct':  round((total_kb-avail_kb)/max(total_kb,1)*100,1),
                'buff_cached_gb': round((mvals.get('Buffers',0)+mvals.get('Cached',0)+mvals.get('SReclaimable',0))/1048576,2),
                'swap_total_gb': round(swap_total/1048576,2),
                'swap_used_gb':  round((swap_total-swap_free)/1048576,2),
                'swap_pct':  round((swap_total-swap_free)/max(swap_total,1)*100,1),
            }
            # Disk
            df_raw = run('df -Pk 2>/dev/null | awk \'NR>1{print $1,$2,$3,$4,$5,$6}\'')
            skip_types = ('/proc','/sys','/dev','/run/user','tmpfs','devtmpfs','udev')
            for line in df_raw.splitlines():
                parts = line.split()
                if len(parts) < 6: continue
                mount = parts[5]
                if any(skip in mount for skip in skip_types): continue
                try:
                    total_kb2 = int(parts[1]); used_kb2 = int(parts[2])
                    result['disk'].append({
                        'fs': parts[0], 'total_gb': round(total_kb2/1048576,2),
                        'used_gb': round(used_kb2/1048576,2),
                        'avail_gb': round(int(parts[3])/1048576,2),
                        'pct': float(parts[4].replace('%','')),
                        'mount': mount
                    })
                except: pass
            result['disk'].sort(key=lambda x: x.get('pct',0), reverse=True)

            # Processes (top 15 by CPU)
            ps_out = run("ps aux --sort=-%cpu 2>/dev/null | awk 'NR>1 && NR<=16{print $1,$2,$3,$4,$11}' || ps -eo user,pid,pcpu,pmem,comm --sort=-%cpu 2>/dev/null | head -16")
            for line in ps_out.splitlines():
                parts = line.split(None, 4)
                if len(parts) >= 5:
                    result['processes'].append({'user':parts[0],'pid':parts[1],'cpu':parts[2],'mem':parts[3],'cmd':parts[4][:40]})

            # Network
            net_out = run("ss -tlnp 2>/dev/null | awk 'NR>1{print $4,$6}' | head -20 || netstat -tlnp 2>/dev/null | awk 'NR>2{print $4,$7}' | head -20")
            for line in net_out.splitlines():
                parts = line.split(None,1)
                if parts: result['network'].append({'addr':parts[0],'process':parts[1] if len(parts)>1 else ''})

        client.close()
    except ImportError:
        result['error'] = 'paramiko not installed'
    except Exception as e:
        result['error'] = str(e)[:300]

    return result
