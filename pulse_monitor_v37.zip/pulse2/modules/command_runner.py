"""
Run Commands against servers or databases via SSH / SQL.
Returns structured output suitable for display and export.
"""
import datetime, socket
from config_store import resolve_credentials, get_jump_hosts

def run_ssh_command(srv, command: str) -> dict:
    """Run a shell command on a Linux/Windows/Solaris server via SSH."""
    host     = srv.get('host','')
    try:   port = int(srv.get('ssh_port', 22))
    except: port = 22
    username, password = resolve_credentials(srv)
    key_path = srv.get('ssh_key_path','')
    name     = srv.get('server_name', host)

    result = {'server': name, 'host': host, 'command': command,
              'output': '', 'error': '', 'duration_ms': None,
              'ran_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

    if not host:
        result['error'] = 'No host configured'
        return result
    if not username:
        result['error'] = 'No credentials configured'
        return result

    try:
        import paramiko
        t0 = datetime.datetime.now()
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kw = dict(hostname=host, port=port, username=username,
                  timeout=15, banner_timeout=10, auth_timeout=10)
        if key_path:   kw['key_filename'] = key_path
        elif password: kw['password']     = password
        client.connect(**kw)
        _, out, err = client.exec_command(command, timeout=30)
        result['output']      = out.read().decode(errors='replace')
        result['error']       = err.read().decode(errors='replace')
        result['duration_ms'] = round((datetime.datetime.now()-t0).total_seconds()*1000, 1)
        client.close()
    except ImportError:
        result['error'] = 'paramiko not installed'
    except Exception as e:
        result['error'] = str(e)[:300]
    return result


def run_oracle_sql(db, sql: str) -> dict:
    """Run a SQL statement on an Oracle database."""
    tns    = db.get('tns_alias','')
    name   = db.get('db_name', tns)
    username, password = resolve_credentials(db)

    result = {'server': name, 'host': tns, 'command': sql,
              'columns': [], 'rows': [], 'output': '', 'error': '',
              'duration_ms': None,
              'ran_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
    if not username:
        result['error'] = 'No credentials configured'
        return result

    try:
        import oracledb
        try:   oracledb.init_oracle_client()
        except Exception as e:
            if 'already been initialized' not in str(e).lower():
                result['error'] = f'Oracle client: {e}'; return result
        t0   = datetime.datetime.now()
        conn = oracledb.connect(user=username, password=password, dsn=tns)
        cur  = conn.cursor()
        cur.execute(sql)
        if cur.description:
            result['columns'] = [d[0] for d in cur.description]
            result['rows']    = [[str(v) if v is not None else '' for v in row]
                                 for row in cur.fetchmany(500)]
        else:
            result['output'] = f'{cur.rowcount} row(s) affected'
        result['duration_ms'] = round((datetime.datetime.now()-t0).total_seconds()*1000,1)
        cur.close(); conn.close()
    except Exception as e:
        result['error'] = str(e)[:400]
    return result


def run_sqlserver_sql(inst, sql: str) -> dict:
    """Run a SQL statement on a SQL Server instance (direct or via jump host)."""
    name = inst.get('instance_name', inst.get('host',''))
    result = {'server': name, 'host': inst.get('host',''), 'command': sql,
              'columns': [], 'rows': [], 'output': '', 'error': '',
              'duration_ms': None,
              'ran_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

    # Via jump host
    if inst.get('jump_host_id'):
        jhs = [h for h in get_jump_hosts() if h['id'] == inst['jump_host_id']]
        jh  = jhs[0] if jhs else None
        if not jh:
            result['error'] = 'Jump host not found'; return result
        jh_user, jh_pass = resolve_credentials(jh)
        jh_key = jh.get('ssh_key_path','')
        use_win = str(jh.get('use_windows_auth','true')).lower() in ('true','1','yes')

        host_raw = inst.get('host','').strip()
        hostname = host_raw; instance_name = ''; port = 1433
        bs = chr(92)
        if ',' in hostname:
            h,p = hostname.rsplit(',',1); hostname=h.strip()
            try: port=int(p.strip())
            except: pass
        else:
            try: port=int(inst.get('port',1433) or 1433)
            except: port=1433
        if bs in hostname:
            hostname, instance_name = hostname.split(bs,1)

        server_str = (f"{hostname}{bs}{instance_name},{port}" if instance_name and port!=1433
                      else f"{hostname}{bs}{instance_name}" if instance_name else f"{hostname},{port}")

        sql_u, sql_p = resolve_credentials(inst)
        auth = '-E' if use_win else f'-U "{sql_u}" -P "{sql_p}"'

        try:
            import paramiko
            t0 = datetime.datetime.now()
            client = paramiko.SSHClient()
            client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            kw = dict(hostname=jh.get('host'), port=int(jh.get('ssh_port',22)),
                      username=jh_user, timeout=15)
            if jh_key: kw['key_filename']=jh_key
            elif jh_pass: kw['password']=jh_pass
            client.connect(**kw)
            safe_q = sql.replace('"','\\"')
            cmd = f'sqlcmd -S "{server_str}" {auth} -Q "{safe_q}" -s "|" -W -l 10 2>&1'
            _, out, _ = client.exec_command(cmd, timeout=30)
            raw = out.read().decode(errors='replace').strip()
            client.close()
            result['duration_ms'] = round((datetime.datetime.now()-t0).total_seconds()*1000,1)
            # Parse sqlcmd pipe-delimited output
            lines = [l.strip() for l in raw.splitlines() if l.strip()
                     and '---' not in l and 'rows affected' not in l.lower()
                     and 'changed database' not in l.lower()]
            if lines:
                result['columns'] = [c.strip() for c in lines[0].split('|')]
                result['rows']    = [[c.strip() for c in l.split('|')] for l in lines[1:]]
        except Exception as e:
            result['error'] = str(e)[:300]
        return result

    # Direct pyodbc
    username, password = resolve_credentials(inst)
    if not username or not password:
        result['error'] = 'No credentials'; return result
    try:
        import pyodbc
        host_raw = inst.get('host','').strip()
        hostname = host_raw; instance_name=''; port=1433; bs=chr(92)
        if ',' in hostname:
            h,p=hostname.rsplit(',',1); hostname=h.strip()
            try: port=int(p.strip())
            except: pass
        if bs in hostname:
            hostname, instance_name = hostname.split(bs,1)
        server_dsn = (f"{hostname}{bs}{instance_name}" if instance_name else f"{hostname},{port}")
        conn_str = (f"DRIVER={{ODBC Driver 18 for SQL Server}};SERVER={server_dsn};"
                    f"UID={username};PWD={password};TrustServerCertificate=yes;Encrypt=yes;Connection Timeout=15;")
        t0 = datetime.datetime.now()
        conn = pyodbc.connect(conn_str, timeout=15)
        cur  = conn.cursor()
        cur.execute(sql)
        if cur.description:
            result['columns'] = [d[0] for d in cur.description]
            result['rows']    = [[str(v) if v is not None else '' for v in row]
                                 for row in cur.fetchmany(500)]
        else:
            result['output'] = f'{cur.rowcount} row(s) affected'
        result['duration_ms'] = round((datetime.datetime.now()-t0).total_seconds()*1000,1)
        cur.close(); conn.close()
    except Exception as e:
        result['error'] = str(e)[:400]
    return result
