"""
Oracle detail metrics — OEM-style dashboard data collector.
Returns structured sections: overview, tablespaces, performance, users, backups.
"""
import datetime, re

def collect_oracle_detail(db):
    from config_store import resolve_credentials
    from modules.oracle_check import _is_ezconnect

    result = {
        'overview': {}, 'instance': {}, 'tablespaces': [],
        'performance': {}, 'top_sql': [], 'sessions': [],
        'users': [], 'roles': [], 'backups': [],
        'registry': [], 'parameters': [], 'oracle_home': '',
        'error': ''
    }

    tns_alias = db.get('tns_alias','')
    username, password = resolve_credentials(db)
    if not username:
        result['error'] = 'No credentials configured'
        return result

    drv = None
    try:
        import oracledb as drv  # type: ignore
    except ImportError:
        try:
            import cx_Oracle as drv  # type: ignore
        except ImportError:
            result['error'] = 'Install oracledb or cx_Oracle'
            return result

    try:
        if hasattr(drv, 'init_oracle_client'):
            try: drv.init_oracle_client()
            except Exception as e:
                if 'already been initialized' not in str(e).lower():
                    result['error'] = str(e); return result
        conn = drv.connect(user=username, password=password, dsn=tns_alias)
        cur  = conn.cursor()

        def q(sql, params=None):
            try:
                if params: cur.execute(sql, params)
                else:      cur.execute(sql)
                return cur.fetchall(), [d[0] for d in (cur.description or [])]
            except Exception as e:
                return [], []

        def q1(sql):
            rows, _ = q(sql)
            return rows[0] if rows else None

        # ── Overview (v$database + v$instance) ───────────────────────────
        row = q1("""SELECT d.NAME, d.DB_UNIQUE_NAME, d.CREATED, d.LOG_MODE,
                    d.OPEN_MODE, d.DATABASE_ROLE, d.PROTECTION_MODE,
                    d.FORCE_LOGGING, d.PLATFORM_NAME,
                    i.INSTANCE_NAME, i.HOST_NAME, i.VERSION, i.STATUS,
                    TO_CHAR(i.STARTUP_TIME,'YYYY-MM-DD HH24:MI'),
                    i.ARCHIVER, i.LOGINS, i.INSTANCE_NUMBER
             FROM   v$database d, v$instance i""")
        if row:
            result['overview'] = {
                'db_name': row[0], 'db_unique_name': row[1],
                'created': str(row[2])[:10] if row[2] else '—',
                'log_mode': row[3], 'open_mode': row[4],
                'db_role': row[5], 'protection_mode': row[6],
                'force_logging': row[7], 'platform': row[8],
                'instance_name': row[9], 'host_name': row[10],
                'version': row[11], 'status': row[12],
                'startup_time': row[13], 'archiver': row[14],
                'logins': row[15], 'instance_number': row[16],
            }
            # patch level from v$version
            patch_rows, _ = q("SELECT BANNER FROM v$version")
            result['overview']['version_banners'] = [r[0] for r in patch_rows]

        # ── Oracle Home (v$diag_info) ─────────────────────────────────────
        oh_row = q1("SELECT VALUE FROM v$diag_info WHERE NAME='Oracle Home'")
        if not oh_row:
            oh_row = q1("SELECT VALUE FROM v$diag_info WHERE NAME='Diag Enabled'")
        result['oracle_home'] = oh_row[0] if oh_row else '—'

        # ── DB Size ───────────────────────────────────────────────────────
        sz = q1("SELECT ROUND(SUM(BYTES)/1073741824,2) FROM dba_data_files")
        result['overview']['db_size_gb'] = sz[0] if sz else '—'

        # ── dba_registry (components) ────────────────────────────────────
        reg_rows, reg_cols = q("""SELECT COMP_NAME, STATUS, VERSION, MODIFIED
                                   FROM dba_registry ORDER BY COMP_NAME""")
        result['registry'] = [dict(zip(reg_cols, r)) for r in reg_rows]

        # ── Tablespaces ───────────────────────────────────────────────────
        ts_rows, ts_cols = q("""
            SELECT t.TABLESPACE_NAME, t.STATUS, t.CONTENTS, t.EXTENT_MANAGEMENT,
                   ROUND(NVL(f.BYTES_FREE,0)/1048576,1) FREE_MB,
                   ROUND(NVL(d.BYTES_ALLOC,0)/1048576,1) ALLOC_MB,
                   ROUND(NVL(d.BYTES_ALLOC,0)/1073741824,2) ALLOC_GB,
                   CASE WHEN NVL(d.BYTES_ALLOC,0)=0 THEN 0
                        ELSE ROUND(100*(1-NVL(f.BYTES_FREE,0)/d.BYTES_ALLOC),1)
                   END PCT_USED, t.BLOCK_SIZE
            FROM dba_tablespaces t
            LEFT JOIN (SELECT TABLESPACE_NAME,SUM(BYTES) BYTES_FREE
                       FROM dba_free_space GROUP BY TABLESPACE_NAME) f
                   ON t.TABLESPACE_NAME=f.TABLESPACE_NAME
            LEFT JOIN (SELECT TABLESPACE_NAME,SUM(BYTES) BYTES_ALLOC
                       FROM dba_data_files GROUP BY TABLESPACE_NAME) d
                   ON t.TABLESPACE_NAME=d.TABLESPACE_NAME
            ORDER BY PCT_USED DESC NULLS LAST""")
        result['tablespaces'] = [
            {'name':r[0],'status':r[1],'contents':r[2],'extent_mgmt':r[3],
             'free_mb':r[4],'alloc_mb':r[5],'alloc_gb':r[6],'pct_used':r[7],'block_size':r[8]}
            for r in ts_rows
        ]

        # ── Active Sessions ───────────────────────────────────────────────
        sess_rows, _ = q("""
            SELECT s.SID, s.SERIAL#, s.USERNAME, s.STATUS, s.OSUSER,
                   s.MACHINE, s.PROGRAM, s.MODULE,
                   TO_CHAR(s.LOGON_TIME,'YYYY-MM-DD HH24:MI'),
                   s.SQL_ID, s.WAIT_CLASS, s.EVENT,
                   ROUND(s.LAST_CALL_ET/60,1) MINS_ACTIVE
            FROM   v$session s
            WHERE  s.TYPE='USER' AND s.USERNAME IS NOT NULL
            ORDER  BY s.STATUS, s.LAST_CALL_ET DESC
            FETCH FIRST 50 ROWS ONLY""")
        result['sessions'] = [
            {'sid':r[0],'serial':r[1],'username':r[2],'status':r[3],
             'osuser':r[4],'machine':r[5],'program':r[6],'module':r[7],
             'logon_time':r[8],'sql_id':r[9],'wait_class':r[10],
             'event':r[11],'mins_active':r[12]}
            for r in sess_rows
        ]

        # ── Performance: system wait events (last 30 min equiv from v$system_event)
        perf_rows, _ = q("""
            SELECT EVENT, WAIT_CLASS, TOTAL_WAITS, TIME_WAITED,
                   ROUND(TIME_WAITED/GREATEST(TOTAL_WAITS,1),2) AVG_MS
            FROM   v$system_event
            WHERE  WAIT_CLASS != 'Idle' AND TOTAL_WAITS > 0
            ORDER  BY TIME_WAITED DESC
            FETCH FIRST 15 ROWS ONLY""")
        result['performance']['wait_events'] = [
            {'event':r[0],'class':r[1],'total_waits':r[2],
             'time_waited_cs':r[3],'avg_ms':r[4]}
            for r in perf_rows
        ]

        # Sysstat (key DB stats)
        sysstat_rows, _ = q("""
            SELECT NAME, VALUE FROM v$sysstat
            WHERE  NAME IN ('user commits','user rollbacks','execute count',
                            'physical reads','physical writes','redo writes',
                            'parse count (total)','parse count (hard)',
                            'db block gets','consistent gets','sorts (disk)',
                            'table fetch by rowid','table scan rows gotten')
            ORDER  BY NAME""")
        result['performance']['sysstat'] = {r[0]: r[1] for r in sysstat_rows}

        # Top SQL (by elapsed time, last ~30 min via v$sql)
        top_sql_rows, _ = q("""
            SELECT SQL_ID, PARSING_USER_ID, EXECUTIONS,
                   ROUND(ELAPSED_TIME/1e6,2) ELAPSED_SEC,
                   ROUND(CPU_TIME/1e6,2) CPU_SEC,
                   ROUND(ELAPSED_TIME/GREATEST(EXECUTIONS,1)/1e6,4) AVG_SEC,
                   BUFFER_GETS, DISK_READS,
                   LAST_ACTIVE_TIME,
                   SUBSTR(SQL_TEXT,1,120) SQL_TEXT
            FROM   v$sql
            WHERE  LAST_ACTIVE_TIME > SYSDATE - 30/1440
              AND  EXECUTIONS > 0
            ORDER  BY ELAPSED_TIME DESC
            FETCH FIRST 20 ROWS ONLY""")
        result['top_sql'] = [
            {'sql_id':r[0],'user_id':r[1],'executions':r[2],
             'elapsed_sec':r[3],'cpu_sec':r[4],'avg_sec':r[5],
             'buffer_gets':r[6],'disk_reads':r[7],
             'last_active':str(r[8])[:16] if r[8] else '—',
             'sql_text':r[9]}
            for r in top_sql_rows
        ]

        # ── Users ─────────────────────────────────────────────────────────
        usr_rows, _ = q("""
            SELECT USERNAME, ACCOUNT_STATUS, DEFAULT_TABLESPACE, TEMPORARY_TABLESPACE,
                   TO_CHAR(CREATED,'YYYY-MM-DD'), TO_CHAR(LOCK_DATE,'YYYY-MM-DD'),
                   TO_CHAR(EXPIRY_DATE,'YYYY-MM-DD'), PROFILE
            FROM   dba_users
            ORDER  BY USERNAME""")
        result['users'] = [
            {'username':r[0],'status':r[1],'default_ts':r[2],'temp_ts':r[3],
             'created':r[4],'lock_date':r[5],'expiry_date':r[6],'profile':r[7]}
            for r in usr_rows
        ]

        # Roles
        role_rows, _ = q("""
            SELECT rp.GRANTED_ROLE, rp.GRANTEE, rp.ADMIN_OPTION, rp.DEFAULT_ROLE
            FROM   dba_role_privs rp
            ORDER  BY rp.GRANTEE, rp.GRANTED_ROLE""")
        result['roles'] = [
            {'role':r[0],'grantee':r[1],'admin_option':r[2],'default_role':r[3]}
            for r in role_rows
        ]

        # ── Backups (v$rman_backup_job_details) ───────────────────────────
        bkp_rows, _ = q("""
            SELECT TO_CHAR(START_TIME,'YYYY-MM-DD HH24:MI'),
                   TO_CHAR(END_TIME,'YYYY-MM-DD HH24:MI'),
                   INPUT_TYPE, STATUS, OUTPUT_DEVICE_TYPE,
                   ROUND(INPUT_BYTES/1073741824,2) INPUT_GB,
                   ROUND(OUTPUT_BYTES/1073741824,2) OUTPUT_GB,
                   ROUND(ELAPSED_SECONDS/60,1) ELAPSED_MIN,
                   COMPRESSION_RATIO, SESSION_RECID
            FROM   v$rman_backup_job_details
            ORDER  BY START_TIME DESC
            FETCH FIRST 30 ROWS ONLY""")
        result['backups'] = [
            {'start_time':r[0],'end_time':r[1],'input_type':r[2],'status':r[3],
             'device':r[4],'input_gb':r[5],'output_gb':r[6],
             'elapsed_min':r[7],'compression':r[8],'session_id':r[9]}
            for r in bkp_rows
        ]

        # ── Key parameters ────────────────────────────────────────────────
        param_rows, _ = q("""
            SELECT NAME, VALUE, DESCRIPTION
            FROM   v$parameter
            WHERE  NAME IN ('db_name','db_unique_name','db_block_size','sga_max_size',
                            'sga_target','pga_aggregate_target','pga_aggregate_limit',
                            'processes','sessions','open_cursors','undo_tablespace',
                            'undo_retention','log_archive_dest_1','log_archive_format',
                            'db_recovery_file_dest','db_recovery_file_dest_size',
                            'compatible','nls_characterset','nls_nchar_characterset',
                            'enable_pluggable_database')
            ORDER  BY NAME""")
        result['parameters'] = [
            {'name':r[0],'value':r[1],'description':r[2]}
            for r in param_rows
        ]

        cur.close(); conn.close()

    except Exception as e:
        result['error'] = str(e)[:400]

    return result
