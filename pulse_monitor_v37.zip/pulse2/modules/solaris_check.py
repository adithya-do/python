"""Solaris server health check via SSH.
All shell commands are kept BARE (no pipes/awk/tr/wc in the command string).
Output parsing is done entirely in Python to avoid shell escaping issues.
"""
import socket, datetime, re
from config_store import resolve_credentials

DASH = '—'


def check_solaris(srv):
    result = {
        'id': srv['id'], 'server_name': srv.get('server_name', ''),
        'environment': srv.get('environment', ''), 'host': srv.get('host', ''),
        'ip_address': DASH,
        'status': 'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'os': 'Solaris', 'os_version': DASH,
        'memory_gb': DASH, 'memory_usage_pct': DASH,
        'cpu_count': DASH, 'cpu_load_avg': DASH,
        'worst_disk': DASH, 'worst_disk_pct': DASH,
        'uptime': DASH,
    }

    host = srv.get('host', '')
    try:
        port = int(srv.get('ssh_port', 22))
    except Exception:
        port = 22

    # ── TCP reachability ──────────────────────────────────────────────────
    start = datetime.datetime.now()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((host, port))
        sock.settimeout(3)
        try:
            sock.recv(256)
        except Exception:
            pass
        sock.close()
        result['response_ms'] = round(
            (datetime.datetime.now() - start).total_seconds() * 1000, 1)
    except Exception as e:
        result.update(status='critical', check_status='completed',
                      error=f'SSH port {port} unreachable: {e}')
        return result

    try:
        result['ip_address'] = socket.gethostbyname(host)
    except Exception:
        result['ip_address'] = host

    username, password = resolve_credentials(srv)
    key_path = srv.get('ssh_key_path', '')
    if not username:
        result.update(status='reachable', check_status='completed',
                      error='No credentials. Add in Settings → Credential Store.')
        return result

    try:
        import paramiko  # type: ignore

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kw = dict(hostname=host, port=port, username=username,
                  timeout=15, banner_timeout=10, auth_timeout=10)
        if key_path:
            kw['key_filename'] = key_path
        elif password:
            kw['password'] = password
        client.connect(**kw)

        def run(cmd):
            """Run a single bare command (no pipes). Return stdout string."""
            try:
                _, out, _ = client.exec_command(cmd, timeout=10)
                return out.read().decode(errors='replace').strip()
            except Exception:
                return ''

        # ── OS version ────────────────────────────────────────────────────
        uname_r = run('uname -r')
        result['os']         = 'Solaris'
        result['os_version'] = f'Solaris {uname_r}' if uname_r else 'Solaris'

        # ── Uptime ────────────────────────────────────────────────────────
        ut = run('uptime')
        if ut:
            dm = re.search(r'up\s+(\d+)\s+day', ut, re.I)
            hm = re.search(r'up\s+(?:\d+\s+days?,\s*)?(\d+):(\d+)', ut, re.I)
            mm = re.search(r'up\s+(\d+)\s+min', ut, re.I)
            if dm:
                days = int(dm.group(1))
                if hm:
                    result['uptime'] = f"{days} days {hm.group(1)}h {hm.group(2)}m"
                else:
                    result['uptime'] = f"{days} days"
            elif hm:
                result['uptime'] = f"{hm.group(1)}h {hm.group(2)}m"
            elif mm:
                result['uptime'] = f"{mm.group(1)} min"

        # ── Load average ──────────────────────────────────────────────────
        if ut and 'average' in ut.lower():
            after = ut.split('average')[-1].replace(':', '').strip()
            result['cpu_load_avg'] = after.split('\n')[0].strip() or DASH

        # ── CPU count — run psrinfo bare, count lines in Python ───────────
        # /usr/sbin/psrinfo prints one line per logical CPU — no pipes needed
        psrinfo_out = run('/usr/sbin/psrinfo')
        if not psrinfo_out:
            psrinfo_out = run('psrinfo')          # try PATH lookup

        if psrinfo_out:
            cpu_lines = [l for l in psrinfo_out.splitlines() if l.strip()]
            if cpu_lines:
                result['cpu_count'] = str(len(cpu_lines))

        # kstat fallback — count cpu_info instances
        if result['cpu_count'] == DASH:
            kstat_out = run('kstat -p cpu_info:::state')
            if kstat_out:
                kstat_lines = [l for l in kstat_out.splitlines() if l.strip()]
                if kstat_lines:
                    result['cpu_count'] = str(len(kstat_lines))

        # ── Memory ────────────────────────────────────────────────────────
        # prtconf: output contains "Memory size: 16384 Megabytes"
        prtconf_out = run('prtconf')
        mem_mb = None
        if prtconf_out:
            for line in prtconf_out.splitlines():
                if 'memory size' in line.lower():
                    m = re.search(
                        r'(\d+)\s*(Megabytes?|Gigabytes?|MB|GB)',
                        line, re.I)
                    if m:
                        val  = int(m.group(1))
                        unit = m.group(2).upper()
                        mem_mb = val * 1024 if unit.startswith('G') else val
                    break

        if mem_mb is None:
            # kstat fallback: physmem pages × pagesize
            pgsz_out = run('pagesize')
            try:
                pgsz = int(pgsz_out) if pgsz_out and pgsz_out.isdigit() else 4096
            except Exception:
                pgsz = 4096
            pm_out = run('kstat -p unix:0:system_pages:physmem')
            if pm_out:
                val = pm_out.split()[-1]
                if val.isdigit():
                    mem_mb = (int(val) * pgsz) // (1024 * 1024)

        if mem_mb and mem_mb > 0:
            result['memory_gb'] = round(mem_mb / 1024, 1)
            # Memory % from kstat freemem
            pgsz_out = run('pagesize')
            try:
                pgsz = int(pgsz_out) if pgsz_out and pgsz_out.isdigit() else 4096
            except Exception:
                pgsz = 4096
            pm_out = run('kstat -p unix:0:system_pages:physmem')
            fm_out = run('kstat -p unix:0:system_pages:freemem')
            if pm_out and fm_out:
                pm_val = pm_out.split()[-1]
                fm_val = fm_out.split()[-1]
                if pm_val.isdigit() and fm_val.isdigit():
                    total_p = int(pm_val); free_p = int(fm_val)
                    if total_p > 0:
                        used_pct = round((1 - free_p / total_p) * 100, 1)
                        result['memory_usage_pct'] = f'{used_pct}%'

        # ── Disk — run df -h bare, parse % column in Python ──────────────
        # Solaris df -h: Filesystem  size  used  avail  capacity%  Mounted
        # Solaris df -k: Filesystem kbytes  used  avail  capacity%  Mounted
        # Both have capacity% as the only field that contains '%'
        df_out = run('df -h')
        if not df_out:
            df_out = run('df -k')

        skip_fs  = ('swap', 'proc', 'fd', 'ctfs', 'objfs', 'sharefs',
                    'lofs', 'mntfs', 'autofs', 'mnttab', 'tmpfs', 'devfs')
        skip_mnt = ('/proc', '/dev', '/tmp', '/dev/fd',
                    '/system', '/platform', '/lib')
        best_pct   = -1
        best_mount = None

        if df_out:
            for line in df_out.splitlines():
                line = line.strip()
                if not line:
                    continue
                # skip header rows
                if line.lower().startswith('filesystem'):
                    continue
                parts = line.split()
                if len(parts) < 5:
                    continue
                fs = parts[0]
                # skip known pseudo-filesystems
                if any(fs.lower().startswith(s) or s == fs.lower()
                       for s in skip_fs):
                    continue
                # find the field that contains '%'  ← this is capacity
                cap_str    = ''
                mount_str  = ''
                for ci, field in enumerate(parts):
                    if '%' in field:
                        cap_str   = field.replace('%', '').strip()
                        mount_str = ' '.join(parts[ci + 1:]).strip()
                        break
                if not cap_str or not mount_str:
                    continue
                if any(mount_str.startswith(s) for s in skip_mnt):
                    continue
                try:
                    pct = float(cap_str)
                    if pct > best_pct:
                        best_pct   = pct
                        best_mount = mount_str
                except ValueError:
                    continue

        if best_mount is not None and best_pct >= 0:
            result['worst_disk']     = best_mount
            result['worst_disk_pct'] = f'{int(best_pct)}%'

        client.close()
        result.update(status='healthy', check_status='completed',
                      message='SSH connected')

    except ImportError:
        result.update(status='reachable', check_status='completed',
                      error='Install paramiko: pip install paramiko '
                            '--break-system-packages')
    except Exception as e:
        err = str(e)
        if 'auth' in err.lower():
            err = ('Authentication failed — check credentials in '
                   'Settings → Credential Store')
        result.update(status='warning', check_status='completed',
                      error=err[:250])

    return result
