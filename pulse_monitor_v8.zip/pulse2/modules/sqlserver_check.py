"""SQL Server health check — ODBC Driver 18, handles sql_variant (type 150)."""
import socket, datetime, re
from config_store import decrypt_password

def check_sqlserver(inst):
    result = {
        'id': inst['id'],
        'instance_name': inst.get('instance_name',''),
        'environment':   inst.get('environment',''),
        'host':          inst.get('host',''),
        'status':     'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'full_version':    '—', 'major_version': '—', 'cu': '—',
        'instance_status': '—', 'agent_status':  '—',
        'db_total': '—', 'db_online': '—',
        'edition':   '—', 'os_version': '—',
        'sessions_current': '—', 'sessions_max': '—',
        'last_backup': '—', 'last_backup_days': None,  # single backup column
    }

    host = inst.get('host','')
    try:   port = int(inst.get('port', 1433))
    except: port = 1433

    # TCP check
    start = datetime.datetime.now()
    try:
        sock = socket.create_connection((host, port), timeout=5)
        sock.close()
        result['response_ms'] = round((datetime.datetime.now()-start).total_seconds()*1000, 1)
    except Exception as e:
        result.update(status='critical', check_status='completed',
                      error=f'TCP unreachable: {e}')
        return result

    username = inst.get('username','')
    password = decrypt_password(inst.get('password_enc',''))
    if not username or not password:
        result.update(status='warning', check_status='completed', error='No credentials')
        return result

    try:
        import pyodbc  # type: ignore

        # Output converter for unsupported ODBC types (sql_variant = type 150 / -150)
        def _safe_converter(raw):
            if raw is None: return None
            try:
                return raw.decode('utf-16-le', errors='replace').rstrip('\x00')
            except Exception:
                return repr(raw)

        conn_str = (
            f"DRIVER={{ODBC Driver 18 for SQL Server}};"
            f"SERVER={host},{port};UID={username};PWD={password};"
            f"Connection Timeout=10;TrustServerCertificate=yes;"
            f"Encrypt=yes;"
        )
        t0 = datetime.datetime.now()
        conn = pyodbc.connect(conn_str, timeout=15)
        result['response_ms'] = round((datetime.datetime.now()-t0).total_seconds()*1000, 1)

        # Register converters for all potentially unsupported SQL Server types
        for type_code in (-150, 150, -151, 151, -155, 155):
            try:
                conn.add_output_converter(type_code, _safe_converter)
            except Exception:
                pass

        cur = conn.cursor()

        def _q(sql):
            try:
                cur.execute(sql)
                return cur.fetchone()
            except Exception as e:
                return None

        def _qall(sql):
            try:
                cur.execute(sql)
                return cur.fetchall()
            except Exception:
                return []

        # Version — use CAST to avoid sql_variant return type
        row = _q("SELECT CAST(@@VERSION AS NVARCHAR(MAX)), "
                 "CAST(SERVERPROPERTY('ProductVersion') AS NVARCHAR(128)), "
                 "CAST(SERVERPROPERTY('Edition') AS NVARCHAR(128)), "
                 "CAST(SERVERPROPERTY('ProductUpdateLevel') AS NVARCHAR(128))")
        if row:
            result['full_version'] = str(row[0])[:120] if row[0] else '—'
            ver = str(row[1]) if row[1] else ''
            major = ver.split('.')[0] if ver else ''
            year_map = {'8':'2000','9':'2005','10':'2008','11':'2012',
                        '12':'2014','13':'2016','14':'2017','15':'2019','16':'2022'}
            result['major_version'] = year_map.get(major, major or '—')
            result['edition'] = str(row[2]) if row[2] else '—'
            result['cu']      = str(row[3]) if row[3] else '—'

        # Instance status
        row = _q("SELECT state_desc FROM sys.databases WHERE name='master'")
        result['instance_status'] = row[0] if row else '—'

        # SQL Agent
        try:
            row = _q("SELECT CAST(dss.[status] AS NVARCHAR(32)) "
                     "FROM sys.dm_server_services dss "
                     "WHERE dss.servicename LIKE N'SQL Server Agent%'")
            result['agent_status'] = str(row[0]) if row and row[0] else '—'
        except Exception:
            result['agent_status'] = 'N/A'

        # DB counts
        row = _q("SELECT COUNT(*), "
                 "SUM(CASE WHEN state_desc='ONLINE' THEN 1 ELSE 0 END) "
                 "FROM sys.databases")
        if row:
            result['db_total']  = row[0]
            result['db_online'] = row[1]

        # Sessions
        row = _q("SELECT @@MAX_CONNECTIONS, "
                 "(SELECT COUNT(*) FROM sys.dm_exec_sessions WHERE is_user_process=1)")
        if row:
            result['sessions_max']     = row[0]
            result['sessions_current'] = row[1]

        # OS info
        row = _q("SELECT host_distribution, host_release FROM sys.dm_os_host_info")
        if row:
            result['os_version'] = f"{row[0]} {row[1]}".strip()

        # Last backup — single column: most recent full backup across user DBs
        row = _q("""SELECT TOP 1
                    CONVERT(NVARCHAR(16), MAX(backup_finish_date), 120)
                    FROM msdb.dbo.backupset
                    WHERE type='D'
                      AND database_name NOT IN ('master','model','msdb','tempdb')
                      AND backup_finish_date IS NOT NULL""")
        if row and row[0]:
            result['last_backup'] = str(row[0])[:16]
            # Calculate days old
            try:
                dt = datetime.datetime.strptime(str(row[0])[:16], '%Y-%m-%d %H:%M')
                result['last_backup_days'] = (datetime.datetime.now() - dt).days
            except Exception:
                pass
        else:
            result['last_backup'] = 'Never'

        cur.close(); conn.close()
        result.update(status='healthy', check_status='completed', message='OK')

    except ImportError:
        result.update(status='reachable', check_status='completed',
                      error='TCP OK. Install pyodbc for full SQL Server checks.')
    except Exception as e:
        result.update(status='critical', check_status='completed', error=str(e)[:300])

    return result
