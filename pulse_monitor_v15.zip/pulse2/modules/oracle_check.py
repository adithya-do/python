"""Oracle health check — uses OS environment (ORACLE_HOME, TNS_ADMIN, LD_LIBRARY_PATH).
No client path configuration needed in Pulse — set env vars at OS/service level.
"""
import os, re, datetime
from config_store import resolve_credentials

def _parse_version(banner):
    """Extract clean version string like 19.0.0.0.0 from Oracle banner."""
    if not banner:
        return '—'
    m = re.search(r'Release\s+(\d+\.\d+\.\d+\.\d+\.\d+)', str(banner))
    if m: return m.group(1)
    m = re.search(r'(\d+\.\d+\.\d+\.\d+\.\d+)', str(banner))
    if m: return m.group(1)
    m = re.search(r'(\d+\.\d+\.\d+)', str(banner))
    if m: return m.group(1)
    return str(banner)[:30]

def _is_ezconnect(alias):
    """True if alias is EZConnect (host:port/service) vs a plain TNS/LDAP name."""
    a = (alias or '').strip()
    return ':' in a or a.startswith('(') or '/' in a

def _q(cur, sql):
    """Run SQL silently, return first row or None."""
    try:
        cur.execute(sql)
        return cur.fetchone()
    except Exception:
        return None

def _fmt_date(val):
    s = str(val)[:16] if val else None
    return s if s and s != 'None' else None

def _days_old(date_str):
    if not date_str or date_str in ('Never', 'N/A', '—', None):
        return None
    try:
        dt = datetime.datetime.strptime(str(date_str)[:16], '%Y-%m-%d %H:%M')
        return (datetime.datetime.now() - dt).days
    except Exception:
        return None


def check_oracle(db):
    result = {
        'id':           db['id'],
        'db_name':      db.get('db_name', ''),
        'environment':  db.get('environment', ''),
        'tns_alias':    db.get('tns_alias', ''),
        'status':       'unknown',
        'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at':   datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms':  None,
        'hostname':          '—',
        'db_version':        '—',
        'db_size_gb':        '—',
        'instance_status':   '—',
        'startup_time':      '—',
        'worst_ts_pct':      '—',
        'worst_ts_name':     '—',
        'worst_ts_num':      0,
        'sessions_current':  '—',
        'sessions_max':      '—',
        'last_backup':       '—',
        'last_backup_days':  None,
        'last_arch_backup':  '—',
        'last_arch_days':    None,
    }

    tns_alias          = (db.get('tns_alias') or '').strip()
    username, password = resolve_credentials(db)

    if not tns_alias:
        result.update(status='critical', check_status='completed',
                      error='No TNS alias / connect string configured')
        return result

    if not username or not password:
        result.update(status='warning', check_status='completed',
                      error='No credentials — add a credential in Settings → Credential Store')
        return result

    # ── Driver selection ──────────────────────────────────────────────────────
    drv = None
    try:
        import oracledb as drv  # type: ignore
    except ImportError:
        try:
            import cx_Oracle as drv  # type: ignore
        except ImportError:
            result.update(status='unknown', check_status='completed',
                          error='Install oracledb or cx_Oracle for Oracle checks')
            return result

    # ── Connection strategy ───────────────────────────────────────────────────
    # thick mode = Oracle Client from OS env (ORACLE_HOME / LD_LIBRARY_PATH)
    #              Supports: TNS alias, LDAP, full descriptors — whatever the
    #              Oracle Client on this host is configured to resolve.
    # thin mode  = pure Python, no client needed.
    #              Supports: EZConnect (host:port/service) and TCPS only.
    #
    # We always try thick first.  For LDAP / TNS names, thin mode cannot
    # help and we skip it to avoid a misleading second error.

    conn       = None
    last_error = ''

    if hasattr(drv, 'init_oracle_client'):
        # ── oracledb: thick mode via OS-provided Oracle Client ────────────
        try:
            # Call with NO arguments — use whatever ORACLE_HOME / LD_LIBRARY_PATH
            # the OS environment already provides.  Passing lib_dir here would
            # override the env and cause "cannot open shared object file" when
            # the path is wrong or the libs have already been loaded.
            drv.init_oracle_client()
        except Exception as init_err:
            err_s = str(init_err).lower()
            if 'already been initialized' not in err_s:
                # Oracle Client not installed / not on LD_LIBRARY_PATH.
                # Fall through to thin mode if alias looks like EZConnect.
                if _is_ezconnect(tns_alias):
                    try:
                        t0   = datetime.datetime.now()
                        conn = drv.connect(user=username, password=password,
                                           dsn=tns_alias, tcp_connect_timeout=10)
                        result['response_ms'] = round(
                            (datetime.datetime.now()-t0).total_seconds()*1000, 1)
                    except Exception as e:
                        last_error = str(e)
                else:
                    result.update(
                        status='critical', check_status='completed',
                        error=(
                            f'Oracle Client not found. '
                            f'Ensure ORACLE_HOME / LD_LIBRARY_PATH are set in the '
                            f'environment where Pulse runs. '
                            f'Detail: {init_err}'
                        )
                    )
                    return result

        if conn is None and last_error == '':
            # thick mode initialised OK — try connecting
            try:
                t0   = datetime.datetime.now()
                conn = drv.connect(user=username, password=password, dsn=tns_alias)
                result['response_ms'] = round(
                    (datetime.datetime.now()-t0).total_seconds()*1000, 1)
            except Exception as e:
                last_error = str(e)
                # Only try thin if the alias is EZConnect-style
                if _is_ezconnect(tns_alias):
                    try:
                        t0   = datetime.datetime.now()
                        conn = drv.connect(user=username, password=password,
                                           dsn=tns_alias, tcp_connect_timeout=10)
                        result['response_ms'] = round(
                            (datetime.datetime.now()-t0).total_seconds()*1000, 1)
                    except Exception as e2:
                        last_error = str(e2)
                else:
                    # Pure TNS / LDAP name — give a helpful error
                    err_upper = last_error.upper()
                    if any(k in err_upper for k in ('ORA-12154','ORA-12541',
                                                     'TNS','NL-00503')):
                        ldap_hint = (
                            ' | LDAP hint: verify ldap.ora has the correct '
                            'LDAP server, and sqlnet.ora contains '
                            'NAMES.DIRECTORY_PATH=(LDAP,TNSNAMES). '
                            f'TNS_ADMIN={os.environ.get("TNS_ADMIN","(not set)")}'
                        )
                        last_error += ldap_hint

    else:
        # ── cx_Oracle: always thick via OS client ─────────────────────────
        try:
            t0   = datetime.datetime.now()
            conn = drv.connect(f"{username}/{password}@{tns_alias}")
            result['response_ms'] = round(
                (datetime.datetime.now()-t0).total_seconds()*1000, 1)
        except Exception as e:
            last_error = str(e)

    if conn is None:
        result.update(status='critical', check_status='completed',
                      error=f'Connection failed: {str(last_error)[:350]}')
        return result

    # ── Run health queries ────────────────────────────────────────────────────
    try:
        cur = conn.cursor()

        # Version
        row = _q(cur, "SELECT BANNER FROM V$VERSION "
                       "WHERE BANNER LIKE 'Oracle%' AND ROWNUM=1")
        result['db_version'] = _parse_version(row[0] if row else None)

        # Instance status + startup + hostname
        row = _q(cur, "SELECT STATUS, "
                       "TO_CHAR(STARTUP_TIME,'YYYY-MM-DD HH24:MI'), "
                       "HOST_NAME "
                       "FROM V$INSTANCE")
        if row:
            result['instance_status'] = row[0] or '—'
            result['startup_time']    = row[1] or '—'
            result['hostname']        = row[2] or '—'

        # DB size
        row = _q(cur, "SELECT ROUND(SUM(BYTES)/1073741824,2) FROM DBA_DATA_FILES")
        if row and row[0] is not None:
            result['db_size_gb'] = f"{row[0]} GB"

        # Sessions: all connected sessions (users + background) / max_sessions
        row = _q(cur, "SELECT COUNT(*) FROM V$SESSION")
        result['sessions_current'] = row[0] if row else 0
        row = _q(cur, "SELECT TO_NUMBER(VALUE) FROM V$PARAMETER WHERE NAME='sessions'")
        result['sessions_max'] = int(row[0]) if row and row[0] else '—'

        # Worst tablespace %
        ts_sql = """SELECT * FROM (
            SELECT a.TABLESPACE_NAME,
                   ROUND((1 - SUM(a.BYTES)/SUM(b.BYTES))*100, 1) PCT
            FROM DBA_FREE_SPACE a
            JOIN DBA_DATA_FILES b ON a.TABLESPACE_NAME = b.TABLESPACE_NAME
            GROUP BY a.TABLESPACE_NAME
            ORDER BY PCT DESC
        ) WHERE ROWNUM = 1"""
        row = _q(cur, ts_sql)
        if row and row[1] is not None:
            pct = float(row[1])
            result['worst_ts_name'] = row[0]
            result['worst_ts_pct']  = f"{pct}%"
            result['worst_ts_num']  = pct

        # Backups
        def _best_date(queries):
            for q in queries:
                row = _q(cur, q)
                if row and row[0]:
                    return _fmt_date(row[0])
            return None

        full_date = _best_date([
            "SELECT TO_CHAR(MAX(END_TIME),'YYYY-MM-DD HH24:MI') "
            "FROM V$RMAN_BACKUP_JOB_DETAILS "
            "WHERE STATUS='COMPLETED' AND INPUT_TYPE IN ('DB FULL','DB INCR LEVEL 0')",
            "SELECT TO_CHAR(MAX(COMPLETION_TIME),'YYYY-MM-DD HH24:MI') "
            "FROM V$BACKUP_SET WHERE BACKUP_TYPE='D' AND STATUS='A'",
        ])
        inc_date = _best_date([
            "SELECT TO_CHAR(MAX(END_TIME),'YYYY-MM-DD HH24:MI') "
            "FROM V$RMAN_BACKUP_JOB_DETAILS "
            "WHERE STATUS='COMPLETED' AND INPUT_TYPE IN ('DB INCR','DB INCR LEVEL 1')",
            "SELECT TO_CHAR(MAX(COMPLETION_TIME),'YYYY-MM-DD HH24:MI') "
            "FROM V$BACKUP_SET WHERE BACKUP_TYPE='I' AND STATUS='A'",
        ])
        arch_date = _best_date([
            "SELECT TO_CHAR(MAX(END_TIME),'YYYY-MM-DD HH24:MI') "
            "FROM V$RMAN_BACKUP_JOB_DETAILS "
            "WHERE STATUS='COMPLETED' AND INPUT_TYPE LIKE 'ARCHIVELOG%'",
            "SELECT TO_CHAR(MAX(COMPLETION_TIME),'YYYY-MM-DD HH24:MI') "
            "FROM V$BACKUP_SET WHERE BACKUP_TYPE='L' AND STATUS='A'",
        ])

        dates = [d for d in [full_date, inc_date] if d]
        if dates:
            most_recent = max(dates)
            result['last_backup']      = most_recent
            result['last_backup_days'] = _days_old(most_recent)
        else:
            result['last_backup'] = 'Never'
        result['last_arch_backup'] = arch_date or 'Never'
        result['last_arch_days']   = _days_old(arch_date)

        cur.close()
        result.update(status='healthy', check_status='completed', message='OK')

    except Exception as e:
        result.update(status='critical', check_status='completed',
                      error=str(e)[:300])
    finally:
        try: conn.close()
        except: pass

    return result
