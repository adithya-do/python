"""Pulse — Infrastructure Health Monitor (Production)"""
import os, sys, json, uuid, datetime, threading, time
from functools import wraps
from flask import (Flask, render_template, redirect, url_for, session,
                   flash, request, jsonify, Response)

sys.path.insert(0, os.path.dirname(__file__))
import config_store as cs

app = Flask(__name__)
app.secret_key = os.environ.get('PULSE_SECRET_KEY', 'CHANGE-IN-PRODUCTION-' + str(uuid.uuid4()))

@app.template_filter('statusbadge')
def statusbadge_filter(status):
    labels = {'healthy':'Healthy','warning':'Warning','critical':'Critical',
              'unknown':'Unknown','reachable':'Reachable','in_progress':'Checking…'}
    s = status or 'unknown'
    return f'<span class="badge badge-{s}">{labels.get(s, s)}</span>'

# ── Auth decorators ───────────────────────────────────────────────────────────
INACTIVITY_TIMEOUT = 45 * 60   # 45 minutes in seconds

def login_required(f):
    @wraps(f)
    def deco(*a, **k):
        if 'uid' not in session:
            flash('Please log in.', 'warning')
            return redirect(url_for('login'))
        # Inactivity timeout — skip if auto-run is active (stored in session)
        last = session.get('last_active', 0)
        auto_running = session.get('auto_run_active', False)
        if not auto_running and time.time() - last > INACTIVITY_TIMEOUT:
            session.clear()
            flash('Session expired due to inactivity (45 min).', 'warning')
            return redirect(url_for('login'))
        session['last_active'] = time.time()
        return f(*a, **k)
    return deco

def admin_required(f):
    @wraps(f)
    def deco(*a, **k):
        if 'uid' not in session:
            return redirect(url_for('login'))
        if session.get('role') != 'admin':
            flash('Admin access required.', 'danger')
            return redirect(url_for('dashboard'))
        return f(*a, **k)
    return deco

# ── Auth routes ───────────────────────────────────────────────────────────────
@app.route('/', methods=['GET','POST'])
@app.route('/login', methods=['GET','POST'])
def login():
    if 'uid' in session:
        return redirect(url_for('dashboard'))
    if request.method == 'POST':
        u = cs.verify_user(request.form.get('username',''), request.form.get('password',''))
        if u:
            session.update({'uid': u['id'], 'username': u['username'],
                            'role': u['role'], 'name': u['name'],
                            'email': u.get('email',''),
                            'module_roles': u.get('module_roles', {}),
                            'login_time': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                            'last_active': time.time()})
            return redirect(url_for('dashboard'))
        flash('Invalid credentials.', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out.', 'info')
    return redirect(url_for('login'))

# ── Dashboard ─────────────────────────────────────────────────────────────────
@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/api/autorun/ping', methods=['POST'])
@login_required
def autorun_ping():
    """Called by client-side auto-run to keep session alive."""
    active = request.json.get('active', False)
    session['auto_run_active'] = bool(active)
    session['last_active'] = time.time()
    return jsonify({'ok': True})

@app.route('/api/summary')
@login_required
def api_summary():
    def counts(items):
        results = [i.get('last_result') or {} for i in items]
        return {
            'total': len(items),
            'healthy': sum(1 for r in results if r.get('status')=='healthy'),
            'warning': sum(1 for r in results if r.get('status')=='warning'),
            'critical': sum(1 for r in results if r.get('status')=='critical'),
        }
    return jsonify({
        'oracle':    counts(cs.get_oracle_dbs()),
        'sqlserver': counts(cs.get_sql_instances()),
        'linux':     counts(cs.get_linux_servers()),
        'windows':   counts(cs.get_windows_servers()),
        'solaris':   counts(cs.get_solaris_servers()),
    })

# ── Oracle ────────────────────────────────────────────────────────────────────
@app.route('/oracle')
@login_required
def oracle():
    dbs = cs.get_oracle_dbs()
    return render_template('oracle.html', databases=dbs)

@app.route('/oracle/add', methods=['GET','POST'])
@admin_required
def oracle_add():
    if request.method == 'POST':
        cs.add_oracle_db(request.form.to_dict())
        flash('Oracle database added.', 'success')
        return redirect(url_for('oracle'))
    return render_template('oracle_form.html', db=None, action='Add')

@app.route('/oracle/edit/<db_id>', methods=['GET','POST'])
@admin_required
def oracle_edit(db_id):
    dbs = cs.get_oracle_dbs()
    db = next((d for d in dbs if d['id']==db_id), None)
    if not db:
        flash('Not found.', 'danger'); return redirect(url_for('oracle'))
    if request.method == 'POST':
        cs.update_oracle_db(db_id, request.form.to_dict())
        flash('Updated.', 'success'); return redirect(url_for('oracle'))
    return render_template('oracle_form.html', db=db, action='Edit')

@app.route('/oracle/delete/<db_id>', methods=['POST'])
@admin_required
def oracle_delete(db_id):
    cs.delete_oracle_db(db_id)
    flash('Deleted.', 'success'); return redirect(url_for('oracle'))

@app.route('/api/oracle/check/<db_id>')
@login_required
def oracle_check(db_id):
    from modules.oracle_check import check_oracle
    dbs = cs.get_oracle_dbs()
    db = next((d for d in dbs if d['id']==db_id), None)
    if not db: return jsonify({'error':'Not found'}), 404
    result = check_oracle(db)
    cs.update_oracle_result(db_id, result)
    return jsonify(result)

@app.route('/api/oracle/check-all')
@login_required
def oracle_check_all():
    from modules.oracle_check import check_oracle
    dbs = cs.get_oracle_dbs()
    results = []
    for db in dbs:
        r = check_oracle(db)
        cs.update_oracle_result(db['id'], r)
        results.append(r)
    return jsonify(results)

# ── SQL Server ────────────────────────────────────────────────────────────────
@app.route('/sqlserver')
@login_required
def sqlserver():
    instances = cs.get_sql_instances()
    return render_template('sqlserver.html', instances=instances)

@app.route('/sqlserver/add', methods=['GET','POST'])
@admin_required
def sqlserver_add():
    if request.method == 'POST':
        cs.add_sql_instance(request.form.to_dict())
        flash('SQL Server instance added.', 'success')
        return redirect(url_for('sqlserver'))
    return render_template('sqlserver_form.html', inst=None, action='Add')

@app.route('/sqlserver/edit/<inst_id>', methods=['GET','POST'])
@admin_required
def sqlserver_edit(inst_id):
    instances = cs.get_sql_instances()
    inst = next((i for i in instances if i['id']==inst_id), None)
    if not inst:
        flash('Not found.', 'danger'); return redirect(url_for('sqlserver'))
    if request.method == 'POST':
        cs.update_sql_instance(inst_id, request.form.to_dict())
        flash('Updated.', 'success'); return redirect(url_for('sqlserver'))
    return render_template('sqlserver_form.html', inst=inst, action='Edit')

@app.route('/sqlserver/delete/<inst_id>', methods=['POST'])
@admin_required
def sqlserver_delete(inst_id):
    cs.delete_sql_instance(inst_id)
    flash('Deleted.', 'success'); return redirect(url_for('sqlserver'))

@app.route('/api/sqlserver/check/<inst_id>')
@login_required
def sqlserver_check(inst_id):
    from modules.sqlserver_check import check_sqlserver
    instances = cs.get_sql_instances()
    inst = next((i for i in instances if i['id']==inst_id), None)
    if not inst: return jsonify({'error':'Not found'}), 404
    result = check_sqlserver(inst)
    cs.update_sql_result(inst_id, result)
    return jsonify(result)

@app.route('/api/sqlserver/check-all')
@login_required
def sqlserver_check_all():
    from modules.sqlserver_check import check_sqlserver
    instances = cs.get_sql_instances()
    results = []
    for inst in instances:
        r = check_sqlserver(inst)
        cs.update_sql_result(inst['id'], r)
        results.append(r)
    return jsonify(results)

# ── Linux ─────────────────────────────────────────────────────────────────────
@app.route('/linux')
@login_required
def linux():
    servers = cs.get_linux_servers()
    return render_template('linux.html', servers=servers)

@app.route('/linux/add', methods=['GET','POST'])
@admin_required
def linux_add():
    if request.method == 'POST':
        cs.add_linux_server(request.form.to_dict())
        flash('Linux server added.', 'success')
        return redirect(url_for('linux'))
    return render_template('server_form.html', srv=None, action='Add', module='linux')

@app.route('/linux/edit/<srv_id>', methods=['GET','POST'])
@admin_required
def linux_edit(srv_id):
    servers = cs.get_linux_servers()
    srv = next((s for s in servers if s['id']==srv_id), None)
    if not srv:
        flash('Not found.', 'danger'); return redirect(url_for('linux'))
    if request.method == 'POST':
        cs.update_linux_server(srv_id, request.form.to_dict())
        flash('Updated.', 'success'); return redirect(url_for('linux'))
    return render_template('server_form.html', srv=srv, action='Edit', module='linux')

@app.route('/linux/delete/<srv_id>', methods=['POST'])
@admin_required
def linux_delete(srv_id):
    cs.delete_linux_server(srv_id)
    flash('Deleted.', 'success'); return redirect(url_for('linux'))

@app.route('/api/linux/check/<srv_id>')
@login_required
def linux_check(srv_id):
    from modules.linux_check import check_linux
    servers = cs.get_linux_servers()
    srv = next((s for s in servers if s['id']==srv_id), None)
    if not srv: return jsonify({'error':'Not found'}), 404
    result = check_linux(srv)
    cs.update_linux_result(srv_id, result)
    return jsonify(result)

@app.route('/api/linux/check-all')
@login_required
def linux_check_all():
    from modules.linux_check import check_linux
    servers = cs.get_linux_servers()
    results = []
    for srv in servers:
        r = check_linux(srv)
        cs.update_linux_result(srv['id'], r)
        results.append(r)
    return jsonify(results)

# ── Windows ───────────────────────────────────────────────────────────────────
@app.route('/windows')
@login_required
def windows():
    servers = cs.get_windows_servers()
    return render_template('windows.html', servers=servers)

@app.route('/windows/add', methods=['GET','POST'])
@admin_required
def windows_add():
    if request.method == 'POST':
        cs.add_windows_server(request.form.to_dict())
        flash('Windows server added.', 'success')
        return redirect(url_for('windows'))
    return render_template('server_form.html', srv=None, action='Add', module='windows')

@app.route('/windows/edit/<srv_id>', methods=['GET','POST'])
@admin_required
def windows_edit(srv_id):
    servers = cs.get_windows_servers()
    srv = next((s for s in servers if s['id']==srv_id), None)
    if not srv:
        flash('Not found.', 'danger'); return redirect(url_for('windows'))
    if request.method == 'POST':
        cs.update_windows_server(srv_id, request.form.to_dict())
        flash('Updated.', 'success'); return redirect(url_for('windows'))
    return render_template('server_form.html', srv=srv, action='Edit', module='windows')

@app.route('/windows/delete/<srv_id>', methods=['POST'])
@admin_required
def windows_delete(srv_id):
    cs.delete_windows_server(srv_id)
    flash('Deleted.', 'success'); return redirect(url_for('windows'))

@app.route('/api/windows/check/<srv_id>')
@login_required
def windows_check(srv_id):
    from modules.windows_check import check_windows
    servers = cs.get_windows_servers()
    srv = next((s for s in servers if s['id']==srv_id), None)
    if not srv: return jsonify({'error':'Not found'}), 404
    result = check_windows(srv)
    cs.update_windows_result(srv_id, result)
    return jsonify(result)

@app.route('/api/windows/check-all')
@login_required
def windows_check_all():
    from modules.windows_check import check_windows
    servers = cs.get_windows_servers()
    results = []
    for srv in servers:
        r = check_windows(srv)
        cs.update_windows_result(srv['id'], r)
        results.append(r)
    return jsonify(results)

# ── Email + Schedule ──────────────────────────────────────────────────────────
@app.route('/api/email/send', methods=['POST'])
@login_required
def email_send():
    from modules.email_report import send_report
    data = request.json
    module = data.get('module','')
    to_email = data.get('to_email','')
    items_map = {
        'oracle': cs.get_oracle_dbs,
        'sqlserver': cs.get_sql_instances,
        'linux': cs.get_linux_servers,
        'windows': cs.get_windows_servers,
        'solaris': cs.get_solaris_servers,
    }
    if module not in items_map:
        return jsonify({'ok': False, 'msg': 'Unknown module'})
    prefs = cs.get_user_prefs(session['uid'])
    hidden = prefs.get(f'cols_{module}', [])
    ok, msg = send_report(module, items_map[module](), to_email, hidden_cols=hidden)
    return jsonify({'ok': ok, 'msg': msg})

@app.route('/settings', methods=['GET','POST'])
@admin_required
def settings():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'email':
            cs.save_email_config(request.form.to_dict())
            flash('Email settings saved.', 'success')
        elif action == 'schedule':
            data = {}
            for mod in ['oracle','sqlserver','linux','windows','solaris']:
                data[f'{mod}_enabled']    = f'{mod}_enabled' in request.form
                data[f'{mod}_interval']   = int(request.form.get(f'{mod}_interval', 60))
                data[f'{mod}_start_time'] = request.form.get(f'{mod}_start_time', '06:00')
                data[f'{mod}_email']      = request.form.get(f'{mod}_email', '').strip()
                all_cols = request.form.getlist(f'{mod}_all_cols')
                checked  = set(request.form.getlist(f'{mod}_report_col'))
                data[f'{mod}_report_cols'] = [col for col in all_cols if col not in checked]
            cs.save_schedules(data)
            flash('Schedule saved.', 'success')
        elif action == 'add_user':
            try:
                module_roles = {}
                for mod in ['oracle','sqlserver','linux','windows','solaris']:
                    mr = request.form.get(f'mrole_{mod}','readonly')
                    if mr: module_roles[mod] = mr
                cs.create_user(
                    request.form['username'], request.form['password'],
                    request.form['name'], request.form['role'],
                    request.form.get('email',''), module_roles=module_roles)
                flash(f'User created.', 'success')
            except ValueError as e:
                flash(str(e), 'danger')
        elif action == 'delete_user':
            cs.delete_user(request.form['user_id'])
            flash('User deleted.', 'success')
        elif action == 'change_user_password':
            uid   = request.form.get('user_id', '')
            new_p = request.form.get('new_password', '')
            conf  = request.form.get('confirm_password', '')
            if len(new_p) < 8:
                flash('Password must be at least 8 characters.', 'danger')
            elif new_p != conf:
                flash('Passwords do not match.', 'danger')
            else:
                update_data = {'password': new_p}
                if request.form.get('role'):
                    update_data['role'] = request.form['role']
                module_roles = {}
                for mod in ['oracle','sqlserver','linux','windows','solaris']:
                    mr = request.form.get(f'mrole_{mod}')
                    if mr: module_roles[mod] = mr
                if module_roles: update_data['module_roles'] = module_roles
                if request.form.get('email') is not None:
                    update_data['email'] = request.form.get('email','')
                cs.update_user_profile(uid, update_data)
                flash('User updated successfully.', 'success')
        elif action == 'add_credential':
            cs.add_credential(request.form.to_dict())
            flash('Credential added.', 'success')
        elif action == 'edit_credential':
            cs.update_credential(request.form['cred_id'], request.form.to_dict())
            flash('Credential updated.', 'success')
        elif action == 'delete_credential':
            cs.delete_credential(request.form['cred_id'])
            flash('Credential deleted.', 'success')
        return redirect(url_for('settings'))

    email_cfg  = cs.get_email_config()
    schedules  = cs.get_schedules()
    users      = cs.get_users()
    credentials = cs.get_credentials()
    return render_template('settings.html',
                           email_cfg=email_cfg, schedules=schedules,
                           users=users, credentials=credentials,
                           cs_jump_hosts=cs.get_jump_hosts())

# ── User profile (self-service, any logged-in user) ───────────────────────────
@app.route('/profile', methods=['GET','POST'])
@login_required
def profile():
    if request.method == 'POST':
        action = request.form.get('action')
        if action == 'update_profile':
            data = {}
            if request.form.get('name'):  data['name']  = request.form['name']
            if request.form.get('email'): data['email'] = request.form['email']
            cs.update_user_profile(session['uid'], data)
            # Update session name
            if data.get('name'): session['name'] = data['name']
            flash('Profile updated.', 'success')
        elif action == 'change_password':
            cur = request.form.get('current_password','')
            new = request.form.get('new_password','')
            confirm = request.form.get('confirm_password','')
            u = cs.verify_user(session['username'], cur)
            if not u:
                flash('Current password is incorrect.', 'danger')
            elif new != confirm:
                flash('New passwords do not match.', 'danger')
            elif len(new) < 8:
                flash('Password must be at least 8 characters.', 'danger')
            else:
                cs.update_user_profile(session['uid'], {'password': new})
                flash('Password changed successfully.', 'success')
        return redirect(url_for('profile'))

    user = cs.get_user(session['username'])
    return render_template('profile.html', user=user)

# ── Credentials API (for dropdown population) ─────────────────────────────────
@app.route('/api/credentials/<module>')
@login_required
def api_credentials(module):
    creds = cs.get_credentials(module)
    # Never send decrypted passwords over API
    return jsonify([{'id': c['id'], 'label': c['label'], 'username': c['username']}
                    for c in creds])

# ── Preview email HTML ────────────────────────────────────────────────────────
@app.route('/api/email/preview/<module>')
@login_required
def email_preview(module):
    from modules.email_report import build_html_report
    items_map = {
        'oracle': cs.get_oracle_dbs,
        'sqlserver': cs.get_sql_instances,
        'linux': cs.get_linux_servers,
        'windows': cs.get_windows_servers,
        'solaris': cs.get_solaris_servers,
    }
    if module not in items_map:
        return 'Unknown module', 404
    # Pass user's hidden columns so report matches screen
    prefs = cs.get_user_prefs(session['uid'])
    hidden = prefs.get(f'cols_{module}', [])
    html = build_html_report(module, items_map[module](), hidden_cols=hidden)
    return Response(html, content_type='text/html')


# ── Column preferences (server-side, persisted per user) ─────────────────────
@app.route('/api/prefs/columns/<module>', methods=['GET','POST'])
@login_required
def column_prefs(module):
    if request.method == 'POST':
        data = request.json or {}
        cs.save_user_pref(session['uid'], f'cols_{module}', data.get('hidden', []))
        return jsonify({'ok': True})
    prefs = cs.get_user_prefs(session['uid'])
    return jsonify({'hidden': prefs.get(f'cols_{module}', [])})


# ── Solaris ───────────────────────────────────────────────────────────────────
@app.route('/solaris')
@login_required
def solaris():
    servers = cs.get_solaris_servers()
    return render_template('solaris.html', servers=servers)

@app.route('/solaris/add', methods=['GET','POST'])
@login_required
def solaris_add():
    if request.method == 'POST':
        cs.add_solaris_server(request.form.to_dict())
        flash('Solaris server added.', 'success')
        return redirect(url_for('solaris'))
    return render_template('server_form.html', srv=None, action='Add', module='solaris')

@app.route('/solaris/edit/<srv_id>', methods=['GET','POST'])
@login_required
def solaris_edit(srv_id):
    servers = cs.get_solaris_servers()
    srv = next((s for s in servers if s['id']==srv_id), None)
    if not srv:
        flash('Not found.', 'danger'); return redirect(url_for('solaris'))
    if request.method == 'POST':
        cs.update_solaris_server(srv_id, request.form.to_dict())
        flash('Updated.', 'success'); return redirect(url_for('solaris'))
    return render_template('server_form.html', srv=srv, action='Edit', module='solaris')

@app.route('/solaris/delete/<srv_id>', methods=['POST'])
@login_required
def solaris_delete(srv_id):
    cs.delete_solaris_server(srv_id)
    flash('Deleted.', 'success'); return redirect(url_for('solaris'))

@app.route('/api/solaris/check/<srv_id>')
@login_required
def solaris_check(srv_id):
    from modules.solaris_check import check_solaris
    servers = cs.get_solaris_servers()
    srv = next((s for s in servers if s['id']==srv_id), None)
    if not srv: return jsonify({'error':'Not found'}), 404
    result = check_solaris(srv)
    cs.update_solaris_result(srv_id, result)
    return jsonify(result)

@app.route('/api/solaris/check-all')
@login_required
def solaris_check_all():
    from modules.solaris_check import check_solaris
    results = []
    for srv in cs.get_solaris_servers():
        r = check_solaris(srv)
        cs.update_solaris_result(srv['id'], r)
        results.append(r)
    return jsonify(results)


@app.route('/api/user/email')
@login_required
def api_user_email():
    return jsonify({'email': session.get('email','')})


# ── SQL Server Jump Hosts ─────────────────────────────────────────────────────
@app.route('/api/jump-hosts')
@login_required
def api_jump_hosts():
    return jsonify(cs.get_jump_hosts())

@app.route('/settings/jump-hosts/add', methods=['POST'])
@login_required
def jump_host_add():
    if session.get('role') != 'admin':
        flash('Admin only.', 'danger')
        return redirect(url_for('settings'))
    cs.add_jump_host(request.form.to_dict())
    flash('Jump host added.', 'success')
    return redirect(url_for('settings') + '#jump-hosts')

@app.route('/settings/jump-hosts/edit/<jh_id>', methods=['POST'])
@login_required
def jump_host_edit(jh_id):
    if session.get('role') != 'admin':
        flash('Admin only.', 'danger')
        return redirect(url_for('settings'))
    cs.update_jump_host(jh_id, request.form.to_dict())
    flash('Jump host updated.', 'success')
    return redirect(url_for('settings') + '#jump-hosts')

@app.route('/settings/jump-hosts/delete/<jh_id>', methods=['POST'])
@login_required
def jump_host_delete(jh_id):
    if session.get('role') != 'admin':
        flash('Admin only.', 'danger')
        return redirect(url_for('settings'))
    cs.delete_jump_host(jh_id)
    flash('Jump host deleted.', 'success')
    return redirect(url_for('settings') + '#jump-hosts')


# ── Excel Export ──────────────────────────────────────────────────────────────
@app.route('/api/<module>/export')
@login_required
def export_excel(module):
    from modules.excel_export import export_module_excel
    items_map = {
        'oracle':    cs.get_oracle_dbs,
        'sqlserver': cs.get_sql_instances,
        'linux':     cs.get_linux_servers,
        'windows':   cs.get_windows_servers,
        'solaris':   cs.get_solaris_servers,
    }
    if module not in items_map:
        return 'Unknown module', 404
    xls = export_module_excel(module, items_map[module]())
    fname = f"pulse3_{module}_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    return Response(xls,
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={'Content-Disposition': f'attachment; filename="{fname}"'})

# ── Run Command ───────────────────────────────────────────────────────────────
@app.route('/api/<module>/run-command', methods=['POST'])
@login_required
def run_command(module):
    import json
    from modules.command_runner import (run_ssh_command, run_oracle_sql,
                                        run_sqlserver_sql)
    data      = request.get_json() or {}
    command   = data.get('command', '').strip()
    target_ids= data.get('target_ids', [])   # empty = all

    if not command:
        return jsonify({'error': 'No command provided'}), 400

    items_map = {
        'oracle':    (cs.get_oracle_dbs,    run_oracle_sql),
        'sqlserver': (cs.get_sql_instances, run_sqlserver_sql),
        'linux':     (cs.get_linux_servers, run_ssh_command),
        'windows':   (cs.get_windows_servers, run_ssh_command),
        'solaris':   (cs.get_solaris_servers, run_ssh_command),
    }
    if module not in items_map:
        return jsonify({'error': 'Unknown module'}), 404

    get_fn, run_fn = items_map[module]
    items = get_fn()
    if target_ids:
        items = [i for i in items if i['id'] in target_ids]

    results = []
    for item in items:
        res = run_fn(item, command)
        results.append(res)

    return jsonify({'results': results})

# ── Server / DB Detail page ───────────────────────────────────────────────────
@app.route('/detail/<module>/<item_id>')
@login_required
def item_detail(module, item_id):
    items_map = {
        'oracle':    cs.get_oracle_dbs,
        'sqlserver': cs.get_sql_instances,
        'linux':     cs.get_linux_servers,
        'windows':   cs.get_windows_servers,
        'solaris':   cs.get_solaris_servers,
    }
    if module not in items_map:
        flash('Unknown module', 'danger')
        return redirect(url_for('dashboard'))
    item = next((i for i in items_map[module]() if i['id'] == item_id), None)
    if not item:
        flash('Not found', 'danger')
        return redirect(url_for(module))
    return render_template('detail.html', module=module, item=item,
                           result=item.get('last_result') or {})


# ── Command output export / email ─────────────────────────────────────────────
@app.route('/api/run-command/export', methods=['POST'])
@login_required
def run_cmd_export():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment
    import io
    data    = request.get_json() or {}
    results = data.get('results', [])
    wb = Workbook(); ws = wb.active; ws.title = 'Command Output'
    ws.append(['Server','Host','Command','Ran At','Duration(ms)','Output/Error'])
    for res in results:
        if res.get('columns'):
            ws.append([res.get('server',''), res.get('host',''),
                       res.get('command',''), res.get('ran_at',''),
                       res.get('duration_ms',''), ''])
            ws.append(res['columns'])
            for row in res.get('rows',[]):
                ws.append(row)
            ws.append([])
        else:
            ws.append([res.get('server',''), res.get('host',''),
                       res.get('command',''), res.get('ran_at',''),
                       res.get('duration_ms',''),
                       (res.get('output') or res.get('error',''))])
    buf = io.BytesIO(); wb.save(buf)
    return Response(buf.getvalue(),
        content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        headers={'Content-Disposition':'attachment;filename="pulse3_cmd.xlsx"'})

@app.route('/api/run-command/email', methods=['POST'])
@login_required
def run_cmd_email():
    from modules.email_report import send_report
    data    = request.get_json() or {}
    results = data.get('results', [])
    to_email= data.get('to_email','')
    module  = data.get('module','')
    if not to_email:
        return jsonify({'ok': False, 'msg': 'No email address'})
    # Build simple HTML body
    html = '<html><body style="font-family:Calibri,sans-serif;font-size:13px">'
    html += f'<h2>Pulse 3 — Command Output</h2>'
    for r in results:
        html += f'<h3>Server: {r.get("server","")} ({r.get("host","")})</h3>'
        html += f'<p><strong>Command:</strong> <code>{r.get("command","")}</code><br>'
        html += f'<strong>Ran:</strong> {r.get("ran_at","")} &nbsp; <strong>Duration:</strong> {r.get("duration_ms","")}ms</p>'
        if r.get('columns'):
            html += '<table border="1" cellpadding="4" style="border-collapse:collapse">'
            html += '<tr>' + ''.join(f'<th>{h}</th>' for h in r['columns']) + '</tr>'
            for row in r.get('rows',[]):
                html += '<tr>' + ''.join(f'<td>{v}</td>' for v in row) + '</tr>'
            html += '</table>'
        else:
            out = r.get('output') or r.get('error','')
            html += f'<pre style="background:#f1f5f9;padding:10px;border-radius:4px">{out}</pre>'
    html += '</body></html>'
    try:
        from modules.email_report import send_report as _
        from config_store import get_email_config, decrypt_password
        import smtplib, ssl
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart
        cfg = get_email_config()
        if not cfg.get('smtp_host'):
            return jsonify({'ok': False, 'msg': 'SMTP not configured'})
        msg = MIMEMultipart('alternative')
        msg['Subject'] = 'Pulse 3 — Command Output'
        msg['From'] = cfg.get('from_email') or cfg.get('smtp_user','')
        msg['To']   = to_email
        msg.attach(MIMEText(html, 'html', 'utf-8'))
        smtp_host = cfg['smtp_host']
        port      = int(cfg.get('smtp_port', 587))
        smtp_pass = decrypt_password(cfg.get('smtp_password_enc',''))
        smtp_user = cfg.get('smtp_user','')
        s = smtplib.SMTP(smtp_host, port, timeout=15)
        s.ehlo(); s.starttls(); s.ehlo()
        if smtp_user and smtp_pass: s.login(smtp_user, smtp_pass)
        s.sendmail(msg['From'], [to_email], msg.as_string()); s.quit()
        return jsonify({'ok': True})
    except Exception as e:
        return jsonify({'ok': False, 'msg': str(e)[:200]})

# ── Scheduler status API ──────────────────────────────────────────────────────
@app.route('/api/scheduler/status')
@login_required
def scheduler_status():
    schedules = cs.get_schedules()
    status = []
    for mod in ['oracle','sqlserver','linux','windows','solaris']:
        enabled    = bool(schedules.get(f'{mod}_enabled', False))
        interval   = int(schedules.get(f'{mod}_interval', 60))
        start_time = schedules.get(f'{mod}_start_time', '06:00')
        email      = schedules.get(f'{mod}_email', '')
        status.append({
            'module':     mod,
            'enabled':    enabled,
            'interval':   interval,
            'start_time': start_time,
            'email':      email,
        })
    running = _scheduler_thread is not None and _scheduler_thread.is_alive()
    return jsonify({'scheduler_running': running, 'modules': status})


# ── Background scheduler (thread-based, no APScheduler needed) ────────────────
_scheduler_thread = None
_stop_scheduler = threading.Event()

def _scheduler_loop():
    """Reliable scheduler: runs checks at configured intervals from start_time.
    - Interval mode: first run at/after start_time, then every N minutes
    - Daily mode: runs once per day at exactly start_time (with ±90s tolerance)
    - Polls every 30s; email sent after each scheduled check run
    """
    import importlib, logging
    log = logging.getLogger('pulse.scheduler')

    # Track last run timestamps and last-daily-run date per module
    last_run   = {}   # mod -> float timestamp
    daily_done = {}   # mod -> 'YYYY-MM-DD' string (daily-only)

    while not _stop_scheduler.is_set():
        try:
            schedules = cs.get_schedules()
            now_dt    = datetime.datetime.now()
            now_ts    = time.time()
            now_hhmm  = now_dt.strftime('%H:%M')
            today_str = now_dt.strftime('%Y-%m-%d')

            modules = {
                'oracle':    (cs.get_oracle_dbs,      'modules.oracle_check',    'check_oracle',    cs.update_oracle_result),
                'sqlserver': (cs.get_sql_instances,   'modules.sqlserver_check', 'check_sqlserver', cs.update_sql_result),
                'linux':     (cs.get_linux_servers,   'modules.linux_check',     'check_linux',     cs.update_linux_result),
                'windows':   (cs.get_windows_servers, 'modules.windows_check',   'check_windows',   cs.update_windows_result),
                'solaris':   (cs.get_solaris_servers, 'modules.solaris_check',   'check_solaris',   cs.update_solaris_result),
            }

            for mod, (get_fn, mod_path, fn_name, update_fn) in modules.items():
                enabled    = bool(schedules.get(f'{mod}_enabled', False))
                interval   = int(schedules.get(f'{mod}_interval', 60))       # minutes
                start_time = str(schedules.get(f'{mod}_start_time', '06:00')) # HH:MM
                email_to   = str(schedules.get(f'{mod}_email', '')).strip()

                if not enabled:
                    continue

                should_run = False

                if interval == 1440:
                    # Daily: run once at start_time (allow ±90 seconds window)
                    try:
                        sh, sm = [int(x) for x in start_time.split(':')]
                        target = now_dt.replace(hour=sh, minute=sm, second=0, microsecond=0)
                        diff   = abs((now_dt - target).total_seconds())
                        if diff <= 90 and daily_done.get(mod) != today_str:
                            should_run = True
                            daily_done[mod] = today_str
                    except Exception:
                        pass
                else:
                    # Interval: first run at/after start_time, then every N minutes
                    interval_secs = interval * 60
                    last          = last_run.get(mod, 0)

                    if last == 0:
                        # First run since startup: wait until start_time has passed today
                        try:
                            sh, sm     = [int(x) for x in start_time.split(':')]
                            start_dt   = now_dt.replace(hour=sh, minute=sm, second=0, microsecond=0)
                            if now_dt >= start_dt:
                                should_run   = True
                                last_run[mod] = now_ts
                        except Exception:
                            # Unparseable start_time — run immediately
                            should_run   = True
                            last_run[mod] = now_ts
                    elif now_ts - last >= interval_secs:
                        should_run   = True
                        last_run[mod] = now_ts

                if not should_run:
                    continue

                # ── Run checks ────────────────────────────────────────────
                log.info(f'Scheduler: running {mod} checks')
                try:
                    m  = importlib.import_module(mod_path)
                    fn = getattr(m, fn_name)
                    for item in get_fn():
                        try:
                            result = fn(item)
                            update_fn(item['id'], result)
                        except Exception as e:
                            log.warning(f'Scheduler: {mod} check failed for {item.get("id")}: {e}')
                except Exception as e:
                    log.error(f'Scheduler: failed to load {mod_path}: {e}')
                    continue

                # ── Send email report ─────────────────────────────────────
                if email_to:
                    try:
                        from modules.email_report import send_report
                        hidden_cols = schedules.get(f'{mod}_report_cols', [])
                        ok, msg = send_report(mod, get_fn(), email_to,
                                              hidden_cols=hidden_cols)
                        log.info(f'Scheduler email {mod} → {email_to}: {msg}')
                    except Exception as e:
                        log.error(f'Scheduler email failed for {mod}: {e}')

        except Exception as e:
            logging.getLogger('pulse.scheduler').error(f'Scheduler loop error: {e}')

        _stop_scheduler.wait(timeout=30)


def start_scheduler():
    global _scheduler_thread
    if _scheduler_thread is None or not _scheduler_thread.is_alive():
        _stop_scheduler.clear()
        _scheduler_thread = threading.Thread(target=_scheduler_loop, daemon=True)
        _scheduler_thread.start()

# ── Generate self-signed cert for HTTPS ───────────────────────────────────────
def ensure_ssl_cert():
    cert_dir = os.path.join(os.path.dirname(__file__), 'certs')
    os.makedirs(cert_dir, exist_ok=True)
    cert_file = os.path.join(cert_dir, 'pulse.crt')
    key_file  = os.path.join(cert_dir, 'pulse.key')
    if os.path.exists(cert_file) and os.path.exists(key_file):
        return cert_file, key_file
    try:
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        import ipaddress
        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        name = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, u'pulse.local'),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, u'Pulse Monitor'),
        ])
        cert = (x509.CertificateBuilder()
            .subject_name(name).issuer_name(name)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(datetime.datetime.utcnow())
            .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=3650))
            .add_extension(x509.SubjectAlternativeName([
                x509.DNSName(u'localhost'),
                x509.DNSName(u'pulse.local'),
                x509.IPAddress(ipaddress.IPv4Address('127.0.0.1')),
            ]), critical=False)
            .sign(key, hashes.SHA256()))
        with open(cert_file, 'wb') as f:
            f.write(cert.public_bytes(serialization.Encoding.PEM))
        with open(key_file, 'wb') as f:
            f.write(key.private_bytes(serialization.Encoding.PEM,
                    serialization.PrivateFormat.TraditionalOpenSSL,
                    serialization.NoEncryption()))
        os.chmod(key_file, 0o600)
        print(f'  ✓ SSL certificate created: {cert_file}')
        return cert_file, key_file
    except Exception as e:
        print(f'  ⚠ SSL cert generation failed: {e}')
        return None, None


# ── Server startup ────────────────────────────────────────────────────────────
def _run_server(use_https=True):
    """Start Pulse with threading + optional TLS.
    Uses Flask/Werkzeug's built-in server (threaded=True) which handles SSL
    correctly and is the most reliable option for an internal monitoring tool.
    The dev-server warning is suppressed via logging config below.
    """
    import logging

    # Silence all werkzeug / Flask startup chatter
    logging.getLogger('werkzeug').setLevel(logging.ERROR)

    # Suppress Flask CLI startup lines ("Serving Flask app", "Debug mode: off")
    try:
        import click as _click
        _orig_echo = _click.echo
        _orig_secho = _click.secho
        _SUPPRESS = {' * Serving Flask', ' * Debug mode', 'Press CTRL+C', 'WARNING'}
        def _quiet_echo(msg='', *a, **k):
            if msg and any(s in str(msg) for s in _SUPPRESS):
                return
            _orig_echo(msg, *a, **k)
        def _quiet_secho(msg='', *a, **k):
            if msg and any(s in str(msg) for s in _SUPPRESS):
                return
            _orig_secho(msg, *a, **k)
        _click.echo  = _quiet_echo
        _click.secho = _quiet_secho
    except Exception:
        pass

    # Suppress werkzeug _log
    try:
        import werkzeug.serving as _ws
        _ws._log = lambda t, m, *a, **k: None
    except Exception:
        pass

    host = '0.0.0.0'

    if use_https:
        cert_file, key_file = ensure_ssl_cert()
        if cert_file and key_file:
            port = int(os.environ.get('PULSE_PORT', '5555'))
            print(f'  ✓ Pulse  →  https://{host}:{port}')
            print(f'  ✓ TLS: enabled  |  Threads: enabled  |  Press Ctrl+C to stop')
            print()
            try:
                app.run(
                    host=host,
                    port=port,
                    ssl_context=(cert_file, key_file),
                    threaded=True,       # handle concurrent requests
                    use_reloader=False,  # no double-process on startup
                    debug=False,
                )
            except KeyboardInterrupt:
                print('\n  Stopping Pulse...')
            return
        else:
            print('  ⚠ SSL cert unavailable — falling back to HTTP')

    # HTTP fallback
    port = int(os.environ.get('PULSE_PORT', '5555'))
    print(f'  ✓ Pulse  →  http://{host}:{port}')
    print(f'  ✓ Threads: enabled  |  Press Ctrl+C to stop')
    print()
    try:
        app.run(
            host=host,
            port=port,
            threaded=True,
            use_reloader=False,
            debug=False,
        )
    except KeyboardInterrupt:
        print('\n  Stopping Pulse...')


if __name__ == '__main__':
    import warnings, logging
    warnings.filterwarnings('ignore', category=DeprecationWarning)

    print()
    print('  ⬡  PULSE — Infrastructure Health Monitor')
    print('  ' + '─' * 44)

    cs.init_default_users()
    start_scheduler()

    use_https = os.environ.get('PULSE_HTTP_ONLY', '').lower() not in ('1', 'true', 'yes')
    _run_server(use_https=use_https)
