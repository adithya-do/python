"""Oracle health check — multi-mode connection (TNS/LDAP/EZConnect/thick/thin)."""
import os, re, datetime
from config_store import resolve_credentials

def _is_ezconnect(alias):
    """True if alias is EZConnect (host:port/service) vs a plain TNS/LDAP name."""
    a = (alias or '').strip()
    return ':' in a or a.startswith('(') or '/' in a

def _set_oracle_env(db):
    if db.get('oracle_home'):
        os.environ['ORACLE_HOME'] = db['oracle_home']
        lib = os.path.join(db['oracle_home'], 'lib')
        existing = os.environ.get('LD_LIBRARY_PATH', '')
        os.environ['LD_LIBRARY_PATH'] = f"{lib}:{existing}" if existing else lib
    if db.get('tns_admin'):
        os.environ['TNS_ADMIN'] = db['tns_admin']

def _parse_version(banner):
    if not banner: return '—'
    m = re.search(r'Release\s+(\d+\.\d+\.\d+\.\d+\.\d+)', banner)
    if m: return m.group(1)
    m = re.search(r'(\d+\.\d+\.\d+\.\d+\.\d+)', banner)
    if m: return m.group(1)
    m = re.search(r'(\d+\.\d+\.\d+)', banner)
    if m: return m.group(1)
    return str(banner)[:30]

def _q(cur, sql):
    """Run SQL, return first row silently or None."""
    try:
        cur.execute(sql)
        return cur.fetchone()
    except Exception:
        return None

def _format_date(val):
    if not val: return None
    s = str(val)[:16]
    return s if s and s != 'None' else None

def _days_old(date_str):
    """Return days since date string, or None if unparseable."""
    if not date_str or date_str in ('Never','N/A','—',None): return None
    try:
        dt = datetime.datetime.strptime(date_str[:16], '%Y-%m-%d %H:%M')
        return (datetime.datetime.now() - dt).days
    except Exception:
        return None

def check_oracle(db):
    result = {
        'id': db['id'],
        'db_name':     db.get('db_name',''),
        'environment': db.get('environment',''),
        'tns_alias':   db.get('tns_alias',''),
        'status':      'unknown',
        'check_status':'in_progress',
        'message': '', 'error': '',
        'checked_at':  datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'db_version':       '—',
        'db_size_gb':       '—',
        'instance_status':  '—',
        'startup_time':     '—',
        'worst_ts_pct':     '—',
        'worst_ts_name':    '—',
        'worst_ts_num':     0,      # numeric for sorting
        'sessions_current': '—',
        'sessions_max':     '—',
        'last_backup':      '—',    # single merged column (most recent of full/inc)
        'last_backup_days': None,   # days old (for color coding)
        'last_arch_backup': '—',
    }

    _set_oracle_env(db)
    tns_alias = db.get('tns_alias','').strip()
    username, password = resolve_credentials(db)

    if not tns_alias:
        result.update(status='critical', check_status='completed', error='No TNS alias / connect string configured')
        return result
    if not username or not password:
        result.update(status='warning', check_status='completed', error='No credentials configured')
        return result

    conn = None
    drv  = None

    # ── Driver selection ──────────────────────────────────────────────────────
    try:
        import oracledb as _drv  # type: ignore
        drv = _drv
    except ImportError:
        try:
            import cx_Oracle as _drv  # type: ignore
            drv = _drv
        except ImportError:
            result.update(status='unknown', check_status='completed',
                          error='Install oracledb or cx_Oracle for Oracle checks')
            return result

    # ── Connection strategy ───────────────────────────────────────────────────
    # thick mode = Oracle Client libs → supports TNS alias, LDAP, full descriptor
    # thin mode  = pure Python → only EZConnect (host:port/service) or TCPS
    #
    # LDAP / TNS alias resolution REQUIRES thick mode (Oracle Client must be
    # configured with ldap.ora / sqlnet.ora NAMES.DIRECTORY_PATH=(LDAP,...)).
    # We therefore try thick first and only fall through to thin when the alias
    # looks like an EZConnect string (contains ':' or '/').

    def _try_connect_thick():
        """oracledb thick mode — full TNS/LDAP support via Oracle Client."""
        if not hasattr(drv, 'init_oracle_client'):
            return None, "driver is not oracledb (cannot use thick mode)"
        lib_dir = db.get('oracle_home') or os.environ.get('ORACLE_HOME')
        if lib_dir and not os.path.isdir(lib_dir):
            lib_dir = None          # ignore invalid path, let oracledb auto-detect
        try:
            drv.init_oracle_client(lib_dir=lib_dir)
        except Exception as e:
            err = str(e).lower()
            if 'already been initialized' not in err:
                # Thick init failed — no Oracle Client available
                return None, f"Oracle Client init failed: {e}"
        try:
            t0 = datetime.datetime.now()
            conn = drv.connect(user=username, password=password, dsn=tns_alias)
            ms   = round((datetime.datetime.now()-t0).total_seconds()*1000, 1)
            return conn, ms
        except Exception as e:
            return None, str(e)

    def _try_connect_thin():
        """oracledb thin mode — EZConnect / TCPS only, no Oracle Client needed."""
        try:
            t0   = datetime.datetime.now()
            conn = drv.connect(user=username, password=password, dsn=tns_alias,
                               tcp_connect_timeout=10)
            ms   = round((datetime.datetime.now()-t0).total_seconds()*1000, 1)
            return conn, ms
        except Exception as e:
            return None, str(e)

    def _try_connect_cx():
        """cx_Oracle style connect — always thick (requires Oracle Client)."""
        try:
            t0   = datetime.datetime.now()
            conn = drv.connect(f"{username}/{password}@{tns_alias}")
            ms   = round((datetime.datetime.now()-t0).total_seconds()*1000, 1)
            return conn, ms
        except Exception as e:
            return None, str(e)

    conn       = None
    last_error = ''

    if hasattr(drv, 'init_oracle_client'):   # oracledb
        # Always try thick first — it is the ONLY mode that works with LDAP/TNS
        conn, info = _try_connect_thick()
        if conn is None:
            last_error = str(info)
            # Only fall through to thin when alias is an EZConnect string.
            # A pure TNS name / LDAP alias will fail in thin mode with an unhelpful
            # error, so we do NOT try thin for bare alias names.
            if _is_ezconnect(tns_alias):
                conn, info = _try_connect_thin()
                if conn is None:
                    last_error = str(info)
            else:
                # Report thick-mode error with a helpful hint for LDAP setups
                err_msg = str(last_error)
                if any(k in err_msg.upper() for k in ('TNS', 'ORA-12154', 'ORA-12541',
                                                        'TNSNAMES', 'NL-00503')):
                    last_error = (
                        f"{err_msg} | "
                        "Hint: For LDAP, ensure Oracle Client ldap.ora is configured "
                        "with the correct LDAP server and NAMES.DIRECTORY_PATH in "
                        "sqlnet.ora includes LDAP (e.g. NAMES.DIRECTORY_PATH=(LDAP,TNSNAMES)). "
                        f"TNS_ADMIN={os.environ.get('TNS_ADMIN','not set')}"
                    )
    else:  # cx_Oracle — thick only, no thin fallback
        conn, info = _try_connect_cx()
        if conn is None:
            last_error = str(info)

    if conn is None:
        result.update(status='critical', check_status='completed',
                      error=f'Connection failed: {str(last_error)[:350]}')
        return result

    result['response_ms'] = info if isinstance(info, (int,float)) else None

    try:
        cur = conn.cursor()

        # Version
        row = _q(cur, "SELECT BANNER FROM V$VERSION WHERE BANNER LIKE 'Oracle%' AND ROWNUM=1")
        result['db_version'] = _parse_version(row[0] if row else None)

        # Instance status + startup
        row = _q(cur, "SELECT STATUS, TO_CHAR(STARTUP_TIME,'YYYY-MM-DD HH24:MI') FROM V$INSTANCE")
        if row:
            result['instance_status'] = row[0] or '—'
            result['startup_time']    = row[1] or '—'

        # DB size
        row = _q(cur, "SELECT ROUND(SUM(BYTES)/1073741824,2) FROM DBA_DATA_FILES")
        if row and row[0] is not None:
            result['db_size_gb'] = f"{row[0]} GB"

        # Sessions (user sessions / max)
        row = _q(cur, "SELECT COUNT(*) FROM V$SESSION WHERE TYPE='USER'")
        current = row[0] if row else 0
        row2 = _q(cur, "SELECT TO_NUMBER(VALUE) FROM V$PARAMETER WHERE NAME='sessions'")
        result['sessions_current'] = current
        result['sessions_max']     = int(row2[0]) if row2 and row2[0] else '—'

        # Worst tablespace % (compatible with Oracle 10g+)
        ts_sql = """SELECT * FROM (
            SELECT a.TABLESPACE_NAME,
                   ROUND((1 - SUM(a.BYTES)/SUM(b.BYTES))*100, 1) PCT
            FROM DBA_FREE_SPACE a
            JOIN DBA_DATA_FILES b ON a.TABLESPACE_NAME = b.TABLESPACE_NAME
            GROUP BY a.TABLESPACE_NAME
            ORDER BY PCT DESC
        ) WHERE ROWNUM = 1"""
        row = _q(cur, ts_sql)
        if row and row[1] is not None:
            pct = float(row[1])
            result['worst_ts_name'] = row[0]
            result['worst_ts_pct']  = f"{pct}%"
            result['worst_ts_num']  = pct

        # Backups — use most recent of (Full, Incremental)
        # Primary: V$RMAN_BACKUP_JOB_DETAILS
        bkp_queries = [
            ("SELECT TO_CHAR(MAX(END_TIME),'YYYY-MM-DD HH24:MI') FROM V$RMAN_BACKUP_JOB_DETAILS "
             "WHERE STATUS='COMPLETED' AND INPUT_TYPE IN ('DB FULL','DB INCR LEVEL 0')"),
            ("SELECT TO_CHAR(MAX(COMPLETION_TIME),'YYYY-MM-DD HH24:MI') FROM V$BACKUP_SET "
             "WHERE BACKUP_TYPE IN ('D') AND STATUS='A'"),
        ]
        bkp_inc_queries = [
            ("SELECT TO_CHAR(MAX(END_TIME),'YYYY-MM-DD HH24:MI') FROM V$RMAN_BACKUP_JOB_DETAILS "
             "WHERE STATUS='COMPLETED' AND INPUT_TYPE IN ('DB INCR','DB INCR LEVEL 1')"),
            ("SELECT TO_CHAR(MAX(COMPLETION_TIME),'YYYY-MM-DD HH24:MI') FROM V$BACKUP_SET "
             "WHERE BACKUP_TYPE='I' AND STATUS='A'"),
        ]
        arch_queries = [
            ("SELECT TO_CHAR(MAX(END_TIME),'YYYY-MM-DD HH24:MI') FROM V$RMAN_BACKUP_JOB_DETAILS "
             "WHERE STATUS='COMPLETED' AND INPUT_TYPE LIKE 'ARCHIVELOG%'"),
            ("SELECT TO_CHAR(MAX(COMPLETION_TIME),'YYYY-MM-DD HH24:MI') FROM V$BACKUP_SET "
             "WHERE BACKUP_TYPE='L' AND STATUS='A'"),
        ]

        def _best_date(queries):
            for q in queries:
                row = _q(cur, q)
                if row and row[0]:
                    return _format_date(row[0])
            return None

        full_date = _best_date(bkp_queries)
        inc_date  = _best_date(bkp_inc_queries)
        arch_date = _best_date(arch_queries)

        # Pick most recent of full/inc for the single backup column
        dates = [d for d in [full_date, inc_date] if d]
        if dates:
            most_recent = max(dates)  # lexicographic works for YYYY-MM-DD HH:MI
            days = _days_old(most_recent)
            result['last_backup']      = most_recent
            result['last_backup_days'] = days
        else:
            result['last_backup'] = 'Never'

        result['last_arch_backup'] = arch_date or 'Never'

        cur.close()
        result.update(status='healthy', check_status='completed', message='OK')

    except Exception as e:
        result.update(status='critical', check_status='completed', error=str(e)[:300])
    finally:
        try: conn.close()
        except: pass

    return result
