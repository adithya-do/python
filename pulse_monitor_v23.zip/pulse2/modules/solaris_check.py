"""Solaris server health check via SSH — robust Solaris-specific commands."""
import socket, datetime, re
from config_store import resolve_credentials

DASH = '—'

def check_solaris(srv):
    result = {
        'id': srv['id'], 'server_name': srv.get('server_name', ''),
        'environment': srv.get('environment', ''), 'host': srv.get('host', ''),
        'ip_address': DASH,
        'status': 'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'os': 'Solaris', 'os_version': DASH,
        'memory_gb': DASH, 'memory_usage_pct': DASH,
        'cpu_count': DASH, 'cpu_load_avg': DASH,
        'worst_disk': DASH, 'worst_disk_pct': DASH,
        'uptime': DASH,
    }

    host = srv.get('host', '')
    try:   port = int(srv.get('ssh_port', 22))
    except: port = 22

    # ── TCP reachability ──────────────────────────────────────────────────
    start = datetime.datetime.now()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((host, port))
        sock.settimeout(3)
        try:   sock.recv(256)
        except Exception: pass
        sock.close()
        result['response_ms'] = round((datetime.datetime.now() - start).total_seconds() * 1000, 1)
    except Exception as e:
        result.update(status='critical', check_status='completed',
                      error=f'SSH port {port} unreachable: {e}')
        return result

    try:
        result['ip_address'] = socket.gethostbyname(host)
    except Exception:
        result['ip_address'] = host

    username, password = resolve_credentials(srv)
    key_path = srv.get('ssh_key_path', '')
    if not username:
        result.update(status='reachable', check_status='completed',
                      error='No credentials. Add in Settings → Credential Store.')
        return result

    try:
        import paramiko  # type: ignore

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kw = dict(hostname=host, port=port, username=username, timeout=15,
                  banner_timeout=10, auth_timeout=10)
        if key_path:   kw['key_filename'] = key_path
        elif password: kw['password']     = password
        client.connect(**kw)

        def run(cmd):
            try:
                _, out, _ = client.exec_command(cmd, timeout=10)
                return out.read().decode(errors='replace').strip()
            except Exception:
                return ''

        # ── OS version ────────────────────────────────────────────────────
        uname_r = run("uname -r")
        result['os']         = 'Solaris'
        result['os_version'] = f"Solaris {uname_r}" if uname_r else 'Solaris'

        # ── Uptime ────────────────────────────────────────────────────────
        # Uptime — prefer `uptime` command (shows what users see, e.g. "706 days")
        # Fall back to /proc/uptime for sub-day precision when no day count shown
        ut = run("uptime 2>/dev/null")
        if ut:
            import re as _re
            d_match = _re.search(r'up\s+(\d+)\s+day', ut, _re.I)
            h_match = _re.search(r'up\s+(?:\d+\s+days?,\s*)?(\d+):(\d+)', ut, _re.I)
            m_match = _re.search(r'up\s+(\d+)\s+min', ut, _re.I)
            if d_match:
                days = int(d_match.group(1))
                if h_match:
                    hrs, mn = int(h_match.group(1)), int(h_match.group(2))
                    result['uptime'] = f"{days} days {hrs}h {mn}m"
                else:
                    result['uptime'] = f"{days} days"
            elif h_match:
                hrs, mn = int(h_match.group(1)), int(h_match.group(2))
                result['uptime'] = f"{hrs}h {mn}m"
            elif m_match:
                result['uptime'] = f"{m_match.group(1)} min"
            else:
                # Last resort: parse /proc/uptime seconds
                uptime_sec = run("awk '{print $1}' /proc/uptime 2>/dev/null")
                if uptime_sec and uptime_sec.replace('.','',1).isdigit():
                    secs = float(uptime_sec)
                    days = int(secs // 86400)
                    hrs  = int((secs % 86400) // 3600)
                    mn   = int((secs % 3600) // 60)
                    result['uptime'] = f"{days} days {hrs}h {mn}m" if days > 0 else f"{hrs}h {mn}m"

        # ── CPU count ─────────────────────────────────────────────────────
        # psrinfo: one line per logical CPU
        ncpu = run("psrinfo 2>/dev/null | wc -l | tr -d ' \t'")
        if not (ncpu and ncpu.isdigit()):
            ncpu = run("kstat -p cpu_info:::core_id 2>/dev/null | wc -l | tr -d ' \t'")
        if not (ncpu and ncpu.isdigit()):
            ncpu = run("isainfo -n 2>/dev/null | awk '{print $1}'")
        result['cpu_count'] = ncpu.strip() if ncpu and ncpu.strip().isdigit() else DASH

        # ── Load average ──────────────────────────────────────────────────
        uptime_out = run("uptime 2>/dev/null")
        if uptime_out and 'average' in uptime_out.lower():
            parts = uptime_out.split('average')
            if len(parts) > 1:
                load_str = parts[1].replace(':','').strip().split('\n')[0].strip()
                result['cpu_load_avg'] = load_str or DASH
        else:
            result['cpu_load_avg'] = DASH

        # ── Memory (total RAM) ────────────────────────────────────────────
        # Strategy 1: prtconf
        prtconf_out = run("prtconf 2>/dev/null | grep -i 'Memory size'")
        mem_mb = None

        if prtconf_out:
            # e.g. "Memory size: 16384 Megabytes" or "Memory size: 16384"
            m = re.search(r'Memory size:\s*(\d+)\s*(Megabytes?|Gigabytes?|MB|GB)?',
                          prtconf_out, re.I)
            if m:
                val  = int(m.group(1))
                unit = (m.group(2) or 'MB').upper()   # default to MB if no unit
                mem_mb = val * 1024 if unit.startswith('G') else val

        # Strategy 2: kstat total-pages * pagesize
        if mem_mb is None:
            page_sz_str = run("pagesize 2>/dev/null")
            page_sz = int(page_sz_str) if (page_sz_str and page_sz_str.isdigit()) else 4096

            physmem_str = run("kstat -p unix:0:system_pages:physmem 2>/dev/null | awk '{print $NF}'")
            if physmem_str and physmem_str.isdigit():
                mem_mb = (int(physmem_str) * page_sz) // (1024 * 1024)

        # Strategy 3: /proc/meminfo (available in some Solaris 11 zones)
        if mem_mb is None:
            meminfo_raw = run("cat /proc/meminfo 2>/dev/null")
            if meminfo_raw:
                for line in meminfo_raw.splitlines():
                    if 'MemTotal' in line:
                        parts = line.split()
                        if len(parts) >= 2:
                            try:
                                mem_mb = int(parts[1]) // 1024   # kB → MB
                            except ValueError:
                                pass
                        break

        if mem_mb and mem_mb > 0:
            result['memory_gb'] = round(mem_mb / 1024, 1)

            # ── Memory % (free vs total) ──────────────────────────────────
            # Strategy 1: kstat freemem pages
            page_sz_str = run("pagesize 2>/dev/null")
            page_sz = int(page_sz_str) if (page_sz_str and page_sz_str.isdigit()) else 4096

            physmem_p = run("kstat -p unix:0:system_pages:physmem 2>/dev/null | awk '{print $NF}'")
            freemem_p = run("kstat -p unix:0:system_pages:freemem 2>/dev/null | awk '{print $NF}'")

            if physmem_p and freemem_p and physmem_p.isdigit() and freemem_p.isdigit():
                total_p = int(physmem_p); free_p = int(freemem_p)
                if total_p > 0:
                    used_pct = round((1 - free_p / total_p) * 100, 1)
                    result['memory_usage_pct'] = f"{used_pct}%"
            else:
                # Strategy 2: vmstat one-shot
                vmstat = run("vmstat 1 1 2>/dev/null | tail -1")
                # Solaris vmstat fields: r b w swap free re mf pi po fr de sr ...
                # field 5 (0-indexed 4) = free pages (KB on older, pages on newer)
                if vmstat:
                    fields = vmstat.split()
                    if len(fields) >= 5:
                        try:
                            free_kb = float(fields[4]) * 4    # rough: 1 page ~ 4KB
                            total_kb = mem_mb * 1024
                            if total_kb > 0:
                                used_pct = round((1 - free_kb / total_kb) * 100, 1)
                                result['memory_usage_pct'] = f"{max(0, min(100, used_pct))}%"
                        except (ValueError, ZeroDivisionError):
                            pass

        # ── Disk ──────────────────────────────────────────────────────────
        # Solaris df -k: Filesystem kbytes used avail capacity% Mounted
        df_raw = run("df -k 2>/dev/null | awk 'NR>1 && $5~/[0-9]+%/{gsub(/%/,\"\",$5); print $5, $6}' | sort -rn | head -10")
        if df_raw:
            skip = ('/proc', '/dev', '/system', '/platform', '/tmp', 'swap')
            for line in df_raw.splitlines():
                parts = line.split(None, 1)
                if len(parts) == 2:
                    pct_raw, mount = parts[0], parts[1].strip()
                    if any(s in mount for s in skip):
                        continue
                    try:
                        pct = float(pct_raw)
                        result['worst_disk']     = mount
                        result['worst_disk_pct'] = f"{int(pct)}%"
                        break
                    except ValueError:
                        continue

        client.close()
        result.update(status='healthy', check_status='completed', message='SSH connected')

    except ImportError:
        result.update(status='reachable', check_status='completed',
                      error='Install paramiko: pip install paramiko --break-system-packages')
    except Exception as e:
        err = str(e)
        if 'auth' in err.lower():
            err = 'Authentication failed — check credentials in Settings → Credential Store'
        result.update(status='warning', check_status='completed', error=err[:250])

    return result
