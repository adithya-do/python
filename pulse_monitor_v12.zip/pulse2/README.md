# ⬡ Pulse — Infrastructure Health Monitor

Unified health monitoring for Oracle, SQL Server, Linux, and Windows infrastructure.

## Features

| Feature | Details |
|---|---|
| 🎨 Theme | Light/white background, DM Sans font, clean dashboard |
| 🔐 Security | HTTPS (self-signed cert), Fernet AES-128 encrypted passwords |
| 📁 Storage | JSON config files per resource type in `data/` |
| ⬡ Oracle | Full health check: version, size, TS%, sessions, RMAN backups |
| 🔷 SQL Server | Version/CU, agent, DB counts, edition, OS, backups (pyodbc) |
| 🐧 Linux | CPU/memory/disk/uptime via SSH + paramiko |
| 🪟 Windows | RDP/WinRM reachability + full metrics via pywinrm |
| ⊞ Columns | Per-module column picker — hide/show any column |
| ▶ Check All | Sequential check-all with live progress counter |
| ⏱ Schedule | Client-side auto-run + server-side background scheduler |
| 📧 Email | HTML health reports via SMTP; preview in browser |
| 👤 Users | Admin/User roles, add/delete users in Settings |

## Quick Start

```bash
cd pulse2
pip install flask werkzeug cryptography --break-system-packages
bash start.sh
```

Open: https://localhost:5443 (accept the self-signed cert warning)

Default credentials: **admin / admin123** and **user / user123**

## Directory Structure

```
pulse2/
├── app.py                  # Flask app, all routes
├── config_store.py         # JSON store + encryption
├── start.sh                # Start script
├── requirements.txt
├── pulse.service           # systemd unit file
├── data/                   # Auto-created JSON files (gitignore this!)
│   ├── .pulse_key          # Fernet encryption key (chmod 600)
│   ├── users.json
│   ├── oracle_databases.json
│   ├── sqlserver_instances.json
│   ├── linux_servers.json
│   ├── windows_servers.json
│   ├── email_config.json
│   └── schedules.json
├── certs/                  # Auto-generated SSL certificate
│   ├── pulse.crt
│   └── pulse.key
├── modules/
│   ├── oracle_check.py
│   ├── sqlserver_check.py
│   ├── linux_check.py
│   ├── windows_check.py
│   └── email_report.py
└── templates/
    ├── base.html, login.html, dashboard.html
    ├── oracle.html, oracle_form.html
    ├── sqlserver.html, sqlserver_form.html
    ├── linux.html, windows.html, server_form.html
    └── settings.html
```

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `PULSE_SECRET_KEY` | Random | Flask session secret (change for production!) |
| `PULSE_HTTP_ONLY` | `0` | Set to `1` to disable HTTPS, use HTTP port 5000 |

## Optional DB Driver Installation

```bash
# Oracle full check (install ONE of):
pip install oracledb               # Modern Python driver, no client required
pip install cx_Oracle              # Classic driver (needs Oracle Instant Client)

# SQL Server full check:
pip install pyodbc
# Also install ODBC Driver 17/18:
# Ubuntu: apt-get install -y msodbcsql17
# RHEL: yum install msodbcsql17

# Linux server metrics via SSH:
pip install paramiko

# Windows server metrics:
pip install pywinrm
```

Without these, Pulse falls back to TCP-only checks (still shows host reachability).

## Oracle User Permissions

```sql
-- Minimum required permissions for Oracle check user
CREATE USER pulse_monitor IDENTIFIED BY "SecurePass123";
GRANT CREATE SESSION TO pulse_monitor;
GRANT SELECT ON V_$VERSION TO pulse_monitor;
GRANT SELECT ON V_$INSTANCE TO pulse_monitor;
GRANT SELECT ON V_$SESSION TO pulse_monitor;
GRANT SELECT ON V_$PARAMETER TO pulse_monitor;
GRANT SELECT ON V_$BACKUP_SET TO pulse_monitor;
GRANT SELECT ON DBA_DATA_FILES TO pulse_monitor;
GRANT SELECT ON DBA_FREE_SPACE TO pulse_monitor;
```

## SQL Server Login Permissions

```sql
CREATE LOGIN pulse_monitor WITH PASSWORD = 'SecurePass123!';
GRANT VIEW SERVER STATE TO pulse_monitor;
GRANT VIEW ANY DATABASE TO pulse_monitor;
USE msdb;
CREATE USER pulse_monitor FOR LOGIN pulse_monitor;
GRANT SELECT ON dbo.backupset TO pulse_monitor;
```

## Production Deployment (systemd)

```bash
# Copy to /opt/pulse
sudo cp -r pulse2/ /opt/pulse
sudo useradd -r -s /bin/false pulse
sudo chown -R pulse:pulse /opt/pulse
sudo chmod 600 /opt/pulse/data/.pulse_key

# Edit service file with correct secret key
sudo cp /opt/pulse/pulse.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable pulse
sudo systemctl start pulse
sudo systemctl status pulse
```

## Security Notes

- All passwords stored encrypted with Fernet AES-128 symmetric encryption
- Encryption key at `data/.pulse_key` — back this up securely
- Self-signed SSL cert auto-generated on first run (10-year validity)
- For production, replace with a proper certificate from Let's Encrypt or your CA
- Change `PULSE_SECRET_KEY` to a long random string in production
- Default passwords (`admin123`) should be changed immediately in Settings
