"""
config_store.py — JSON-based persistent config for Pulse
Passwords stored Fernet-encrypted. User prefs stored per-user.
"""
import warnings
# Suppress CryptographyDeprecationWarning on older Python versions
warnings.filterwarnings("ignore", category=DeprecationWarning, module="cryptography")

import json, os, uuid, datetime, secrets, string
from cryptography.fernet import Fernet

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE, 'data')
os.makedirs(DATA_DIR, exist_ok=True)

# ── Encryption ─────────────────────────────────────────────────────────────────
KEY_FILE = os.path.join(DATA_DIR, '.pulse_key')

def _get_key():
    if os.path.exists(KEY_FILE):
        with open(KEY_FILE, 'rb') as f:
            return f.read()
    key = Fernet.generate_key()
    with open(KEY_FILE, 'wb') as f:
        f.write(key)
    os.chmod(KEY_FILE, 0o600)
    return key

_fernet = Fernet(_get_key())

def encrypt_password(plain):
    if not plain:
        return ''
    return _fernet.encrypt(plain.encode()).decode()

def decrypt_password(enc):
    if not enc:
        return ''
    try:
        return _fernet.decrypt(enc.encode()).decode()
    except Exception:
        return ''

# ── Generic JSON store ────────────────────────────────────────────────────────
def _path(name):
    return os.path.join(DATA_DIR, f'{name}.json')

def _load(name):
    p = _path(name)
    if not os.path.exists(p):
        return []
    with open(p) as f:
        return json.load(f)

def _save(name, data):
    with open(_path(name), 'w') as f:
        json.dump(data, f, indent=2, default=str)

# ── Users ─────────────────────────────────────────────────────────────────────
from werkzeug.security import generate_password_hash, check_password_hash

USERS_FILE = _path('users')

def _gen_password(length=16):
    """Generate a secure random password."""
    alphabet = string.ascii_letters + string.digits + '!@#$%^&*'
    while True:
        pwd = ''.join(secrets.choice(alphabet) for _ in range(length))
        # Ensure complexity
        if (any(c.islower() for c in pwd) and any(c.isupper() for c in pwd)
                and any(c.isdigit() for c in pwd) and any(c in '!@#$%^&*' for c in pwd)):
            return pwd

def init_default_users():
    if not os.path.exists(USERS_FILE):
        admin_pass = _gen_password(16)
        users = [{
            'id': str(uuid.uuid4()), 'username': 'admin',
            'password_hash': generate_password_hash(admin_pass),
            'role': 'admin', 'name': 'Administrator',
            'email': 'admin@company.com'
        }]
        _save('users', users)
        # Print ONE TIME to console — not stored or shown in UI
        print('\n' + '='*54)
        print('  PULSE — INITIAL ADMIN CREDENTIALS (one-time display)')
        print(f'  Username : admin')
        print(f'  Password : {admin_pass}')
        print('  Change this in Settings → User Management')
        print('='*54 + '\n')

def get_users():
    init_default_users()
    return _load('users')

def get_user(username):
    return next((u for u in get_users() if u['username'] == username), None)

def verify_user(username, password):
    u = get_user(username)
    if u and check_password_hash(u['password_hash'], password):
        return u
    return None

def save_user(user):
    users = get_users()
    idx = next((i for i, u in enumerate(users) if u['id'] == user['id']), None)
    if idx is not None:
        users[idx] = user
    else:
        users.append(user)
    _save('users', users)

def create_user(username, password, name, role, email):
    users = get_users()
    if any(u['username'] == username for u in users):
        raise ValueError(f'Username "{username}" already exists')
    user = {'id': str(uuid.uuid4()), 'username': username,
            'password_hash': generate_password_hash(password),
            'role': role, 'name': name, 'email': email}
    users.append(user)
    _save('users', users)
    return user

def change_password(username, new_password):
    users = get_users()
    for u in users:
        if u['username'] == username:
            u['password_hash'] = generate_password_hash(new_password)
            break
    _save('users', users)

def delete_user(user_id):
    users = [u for u in get_users() if u['id'] != user_id]
    _save('users', users)

# ── User Preferences (column selection, etc.) ─────────────────────────────────
def get_user_prefs(user_id):
    all_prefs = _load('user_prefs')
    return next((p for p in all_prefs if p.get('user_id') == user_id), {})

def save_user_pref(user_id, key, value):
    all_prefs = _load('user_prefs')
    prefs = next((p for p in all_prefs if p.get('user_id') == user_id), None)
    if prefs is None:
        prefs = {'user_id': user_id}
        all_prefs.append(prefs)
    prefs[key] = value
    _save('user_prefs', all_prefs)

# ── Oracle Databases ──────────────────────────────────────────────────────────
def get_oracle_dbs():
    return _load('oracle_databases')

def add_oracle_db(data):
    dbs = get_oracle_dbs()
    entry = {
        'id':          str(uuid.uuid4()),
        'db_name':     data.get('db_name', ''),
        'environment': data.get('environment', 'Non-Prod'),
        'tns_alias':   data.get('tns_alias', ''),
        'cred_id':     data.get('cred_id', ''),
        'description': data.get('description', ''),
        'created':     datetime.datetime.now().isoformat(),
        'last_check': None, 'last_result': None,
    }
    dbs.append(entry)
    _save('oracle_databases', dbs)
    return entry

def update_oracle_db(db_id, data):
    dbs = get_oracle_dbs()
    for db in dbs:
        if db['id'] == db_id:
            for k in ['db_name','environment','tns_alias','cred_id','description']:
                if k in data:
                    db[k] = data[k]
            db['updated'] = datetime.datetime.now().isoformat()
            break
    _save('oracle_databases', dbs)

def delete_oracle_db(db_id):
    _save('oracle_databases', [d for d in get_oracle_dbs() if d['id'] != db_id])

def update_oracle_result(db_id, result):
    dbs = get_oracle_dbs()
    for db in dbs:
        if db['id'] == db_id:
            db['last_check'] = datetime.datetime.now().isoformat()
            db['last_result'] = result
            break
    _save('oracle_databases', dbs)

# ── SQL Server ────────────────────────────────────────────────────────────────
def get_sql_instances():
    return _load('sqlserver_instances')

def add_sql_instance(data):
    instances = get_sql_instances()
    entry = {
        'id':            str(uuid.uuid4()),
        'instance_name': data.get('instance_name', ''),
        'environment':   data.get('environment', 'Non-Prod'),
        'host':          data.get('host', ''),
        'port':          data.get('port', '1433'),
        'cred_id':       data.get('cred_id', ''),
        'description':   data.get('description', ''),
        'created':       datetime.datetime.now().isoformat(),
        'last_check': None, 'last_result': None,
    }
    instances.append(entry)
    _save('sqlserver_instances', instances)
    return entry

def update_sql_instance(inst_id, data):
    instances = get_sql_instances()
    for inst in instances:
        if inst['id'] == inst_id:
            for k in ['instance_name','environment','host','port','cred_id','description']:
                if k in data: inst[k] = data[k]
            inst['updated'] = datetime.datetime.now().isoformat()
            break
    _save('sqlserver_instances', instances)

def delete_sql_instance(inst_id):
    _save('sqlserver_instances', [i for i in get_sql_instances() if i['id'] != inst_id])

def update_sql_result(inst_id, result):
    instances = get_sql_instances()
    for inst in instances:
        if inst['id'] == inst_id:
            inst['last_check'] = datetime.datetime.now().isoformat()
            inst['last_result'] = result
            break
    _save('sqlserver_instances', instances)

# ── Linux Servers ─────────────────────────────────────────────────────────────
def get_linux_servers():
    return _load('linux_servers')

def add_linux_server(data):
    servers = get_linux_servers()
    entry = {
        'id':          str(uuid.uuid4()),
        'server_name': data.get('server_name', ''),
        'host':        data.get('host', ''),
        'environment': data.get('environment', 'Non-Prod'),
        'ssh_port':    data.get('ssh_port', '22'),
        'cred_id':     data.get('cred_id', ''),
        'ssh_key_path':data.get('ssh_key_path', ''),
        'description': data.get('description', ''),
        'created':     datetime.datetime.now().isoformat(),
        'last_check': None, 'last_result': None,
    }
    servers.append(entry)
    _save('linux_servers', servers)
    return entry

def update_linux_server(srv_id, data):
    servers = get_linux_servers()
    for srv in servers:
        if srv['id'] == srv_id:
            for k in ['server_name','host','environment','ssh_port','cred_id','ssh_key_path','description']:
                if k in data: srv[k] = data[k]
            srv['updated'] = datetime.datetime.now().isoformat()
            break
    _save('linux_servers', servers)

def delete_linux_server(srv_id):
    _save('linux_servers', [s for s in get_linux_servers() if s['id'] != srv_id])

def update_linux_result(srv_id, result):
    servers = get_linux_servers()
    for srv in servers:
        if srv['id'] == srv_id:
            srv['last_check'] = datetime.datetime.now().isoformat()
            srv['last_result'] = result
            break
    _save('linux_servers', servers)

# ── Windows Servers ───────────────────────────────────────────────────────────
def get_windows_servers():
    return _load('windows_servers')

def add_windows_server(data):
    servers = get_windows_servers()
    entry = {
        'id':          str(uuid.uuid4()),
        'server_name': data.get('server_name', ''),
        'host':        data.get('host', ''),
        'environment': data.get('environment', 'Non-Prod'),
        'cred_id':     data.get('cred_id', ''),
        'description': data.get('description', ''),
        'created':     datetime.datetime.now().isoformat(),
        'last_check': None, 'last_result': None,
    }
    servers.append(entry)
    _save('windows_servers', servers)
    return entry

def update_windows_server(srv_id, data):
    servers = get_windows_servers()
    for srv in servers:
        if srv['id'] == srv_id:
            for k in ['server_name','host','environment','cred_id','description']:
                if k in data: srv[k] = data[k]
            srv['updated'] = datetime.datetime.now().isoformat()
            break
    _save('windows_servers', servers)

def delete_windows_server(srv_id):
    _save('windows_servers', [s for s in get_windows_servers() if s['id'] != srv_id])

def update_windows_result(srv_id, result):
    servers = get_windows_servers()
    for srv in servers:
        if srv['id'] == srv_id:
            srv['last_check'] = datetime.datetime.now().isoformat()
            srv['last_result'] = result
            break
    _save('windows_servers', servers)

# ── Email / Schedule ──────────────────────────────────────────────────────────
def get_email_config():
    configs = _load('email_config')
    return configs[0] if configs else {
        'smtp_host': '', 'smtp_port': '587', 'smtp_user': '',
        'smtp_password_enc': '', 'from_email': '', 'tls': True,
    }

def save_email_config(data):
    existing = get_email_config()
    entry = {
        'smtp_host':  data.get('smtp_host', ''),
        'smtp_port':  data.get('smtp_port', '587'),
        'smtp_user':  data.get('smtp_user', ''),
        'smtp_password_enc': encrypt_password(data['smtp_password']) if data.get('smtp_password') else existing.get('smtp_password_enc',''),
        'from_email': data.get('from_email', ''),
        'tls': 'tls' in data,
    }
    _save('email_config', [entry])

def get_schedules():
    sched = _load('schedules')
    return sched[0] if sched else {
        'oracle_interval': 60, 'oracle_enabled': False, 'oracle_email': '',
        'sqlserver_interval': 60, 'sqlserver_enabled': False, 'sqlserver_email': '',
        'linux_interval': 60, 'linux_enabled': False, 'linux_email': '',
        'windows_interval': 60, 'windows_enabled': False, 'windows_email': '',
    }

def save_schedules(data):
    _save('schedules', [data])

# ── Credential Store (per-module monitor accounts) ────────────────────────────
def get_credentials(module=None):
    """Get all stored credentials, optionally filtered by module."""
    all_creds = _load('credentials')
    if module:
        return [c for c in all_creds if c.get('module') == module]
    return all_creds

def add_credential(data):
    creds = _load('credentials')
    entry = {
        'id':          str(uuid.uuid4()),
        'module':      data.get('module', ''),      # oracle/sqlserver/linux/windows
        'label':       data.get('label', ''),        # display name
        'username':    data.get('username', ''),
        'password_enc':encrypt_password(data.get('password', '')),
        'description': data.get('description', ''),
        'created':     datetime.datetime.now().isoformat(),
    }
    creds.append(entry)
    _save('credentials', creds)
    return entry

def update_credential(cred_id, data):
    creds = _load('credentials')
    for c in creds:
        if c['id'] == cred_id:
            for k in ['module','label','username','description']:
                if k in data: c[k] = data[k]
            if data.get('password'):
                c['password_enc'] = encrypt_password(data['password'])
            c['updated'] = datetime.datetime.now().isoformat()
            break
    _save('credentials', creds)

def delete_credential(cred_id):
    creds = [c for c in _load('credentials') if c['id'] != cred_id]
    _save('credentials', creds)

def get_credential(cred_id):
    return next((c for c in _load('credentials') if c['id'] == cred_id), None)

# ── User profile update ───────────────────────────────────────────────────────
def update_user_profile(user_id, data):
    users = get_users()
    for u in users:
        if u['id'] == user_id:
            if data.get('name'):    u['name']  = data['name']
            if data.get('email'):   u['email'] = data['email']
            if data.get('password'):
                u['password_hash'] = generate_password_hash(data['password'])
            break
    _save('users', users)


# ── Credential resolution helper ──────────────────────────────────────────────
def resolve_credentials(resource):
    """Given a DB/server dict, return (username, password).
    Falls back to legacy username/password_enc fields for old records.
    """
    cred_id = resource.get('cred_id', '')
    if cred_id:
        cred = get_credential(cred_id)
        if cred:
            return cred.get('username', ''), decrypt_password(cred.get('password_enc', ''))
    # Legacy fallback for records saved before credential store
    return resource.get('username', ''), decrypt_password(resource.get('password_enc', ''))
