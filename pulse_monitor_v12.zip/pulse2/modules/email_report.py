"""Email health report — columns match screen selection, smart SSL."""
import smtplib, datetime, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from config_store import get_email_config, decrypt_password

STATUS_COLOR = {
    'healthy': '#16a34a', 'warning': '#d97706', 'critical': '#dc2626',
    'unknown': '#6b7280', 'reachable': '#2563eb',
}

def _badge(status):
    c = STATUS_COLOR.get(status, '#6b7280')
    lbl = {'healthy':'Healthy','warning':'Warning','critical':'Critical',
           'unknown':'Unknown','reachable':'Reachable'}.get(status, status or '—')
    return (f'<span style="background:{c};color:#fff;padding:2px 10px;'
            f'border-radius:20px;font-size:11px;font-weight:600">{lbl}</span>')

def _days_old(date_str):
    if not date_str or date_str in ('—','Never','N/A'): return None
    try:
        dt = datetime.datetime.strptime(str(date_str)[:16], '%Y-%m-%d %H:%M')
        return (datetime.datetime.now() - dt).days
    except Exception:
        return None

def _bkp_color(date_str):
    d = _days_old(date_str)
    return 'color:#dc2626;font-weight:700' if d is not None and d > 3 else ''

def _pct_color(pct_str, warn=75, danger=90):
    try:
        v = float(str(pct_str).replace('%',''))
        if v >= danger: return 'color:#dc2626;font-weight:700'
        if v >= warn:   return 'color:#d97706;font-weight:600'
    except Exception: pass
    return ''


# ── Column definitions per module ─────────────────────────────────────────────
# Each entry: (css_class, header_text, lambda item,result -> cell_html)
_ORACLE_COLS = [
    ('c-env',    'Env',            lambda i,r: i.get('environment','—')),
    ('c-tns',    'TNS Alias',      lambda i,r: i.get('tns_alias','—')),
    ('c-ver',    'DB Version',     lambda i,r: r.get('db_version','—')),
    ('c-size',   'DB Size',        lambda i,r: r.get('db_size_gb','—')),
    # status col always shown — handled separately
    ('c-inst',   'Instance',       lambda i,r: r.get('instance_status','—')),
    ('c-uptime', 'Startup Time',   lambda i,r: r.get('startup_time','—')),
    ('c-ts',     'Worst TS%',      lambda i,r: (
        '<span style="' + _pct_color(r.get('worst_ts_pct','0'),85,95) + '">' +
        r.get('worst_ts_name','') + '&nbsp;' + r.get('worst_ts_pct','—') + '</span>')),
    ('c-sess',   'Sessions',       lambda i,r:
        f'{r.get("sessions_current","—")}/{r.get("sessions_max","—")}'),
    ('c-bkp',    'Last Backup',    lambda i,r: (
        '<span style="' + _bkp_color(r.get('last_backup')) + '">' +
        r.get('last_backup','—') + '</span>')),
    ('c-arch',   'Last Arch',      lambda i,r: r.get('last_arch_backup','—')),
    ('c-check',  'Last Checked',   lambda i,r: r.get('checked_at','—')),
    ('c-err',    'Error',          lambda i,r:
        f'<span style="color:#dc2626;font-size:10px">{r.get("error","")}</span>'),
]

_SQL_COLS = [
    ('c-env',   'Env',           lambda i,r: i.get('environment','—')),
    ('c-ver',   'Full Version',  lambda i,r: r.get('full_version','—')),
    ('c-year',  'Version',       lambda i,r: r.get('major_version','—')),
    ('c-cu',    'CU',            lambda i,r: r.get('cu','—')),
    ('c-inst',  'Instance',      lambda i,r: r.get('instance_status','—')),
    ('c-agent', 'Agent',         lambda i,r: r.get('agent_status','—')),
    ('c-dbs',   'Databases',     lambda i,r:
        f'{r.get("db_online","—")}/{r.get("db_total","—")}'),
    ('c-edit',  'Edition',       lambda i,r: r.get('edition','—')),
    ('c-os',    'OS',            lambda i,r: r.get('os_version','—')),
    ('c-sess',  'Sessions',      lambda i,r:
        f'{r.get("sessions_current","—")}/{r.get("sessions_max","—")}'),
    ('c-enc',   'Encryption',    lambda i,r:
        f'{r.get("enc_encrypted","—")}/{r.get("enc_total","—")}'),
    ('c-bkp',   'Last Backup',   lambda i,r: (
        '<span style="' + _bkp_color(r.get('last_backup')) + '">' +
        r.get('last_backup','—') + '</span>')),
    ('c-err',   'Error',         lambda i,r:
        f'<span style="color:#dc2626;font-size:10px">{r.get("error","")}</span>'),
]

_SERVER_COLS = [
    ('c-env',    'Env',          lambda i,r: i.get('environment','—')),
    ('c-os',     'OS',           lambda i,r: r.get('os','—')),
    ('c-osver',  'OS Version',   lambda i,r: r.get('os_version','—')),
    ('c-mem',    'Mem (GB)',      lambda i,r: r.get('memory_gb','—')),
    ('c-mempct', 'Mem %',        lambda i,r: (
        '<span style="' + _pct_color(r.get('memory_usage_pct','0')) + '">' +
        r.get('memory_usage_pct','—') + '</span>')),
    ('c-cpu',    'CPUs',         lambda i,r: r.get('cpu_count','—')),
    ('c-load',   'Load Avg',     lambda i,r: r.get('cpu_load_avg','—')),
    ('c-disk',   'Worst Disk%',  lambda i,r: (
        '<span style="' + _pct_color(r.get('worst_disk_pct','0')) + '">' +
        r.get('worst_disk','—') + '&nbsp;' + r.get('worst_disk_pct','') + '</span>')),
    ('c-up',     'Uptime',       lambda i,r: r.get('uptime','—')),
    ('c-err',    'Error',        lambda i,r:
        f'<span style="color:#dc2626;font-size:10px">{r.get("error","")}</span>'),
]

_MODULE_COLS = {
    'oracle':    _ORACLE_COLS,
    'sqlserver': _SQL_COLS,
    'linux':     _SERVER_COLS,
    'windows':   _SERVER_COLS,
}

_NAME_COL = {
    'oracle':    lambda i: i.get('db_name',''),
    'sqlserver': lambda i: i.get('instance_name',''),
    'linux':     lambda i: i.get('server_name',''),
    'windows':   lambda i: i.get('server_name',''),
}


def build_html_report(module: str, items: list, hidden_cols: list = None) -> str:
    """Build HTML report respecting the same columns visible on screen."""
    hidden = set(hidden_cols or [])
    now    = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    total   = len(items)
    healthy = sum(1 for i in items if (i.get('last_result') or {}).get('status') == 'healthy')
    critical= sum(1 for i in items if (i.get('last_result') or {}).get('status') == 'critical')

    col_defs   = _MODULE_COLS.get(module, _SERVER_COLS)
    visible    = [(cls, hdr, fn) for cls, hdr, fn in col_defs if cls not in hidden]
    name_fn    = _NAME_COL.get(module, lambda i: '—')
    icon_map   = {'oracle':'🔶','sqlserver':'🔷','linux':'🐧','windows':'🪟'}

    # Table header
    th_cells = '<th>#</th><th>Name</th>'
    for cls, hdr, _ in visible:
        th_cells += f'<th>{hdr}</th>'
    th_cells += '<th>Status</th>'

    # Table rows
    rows = ''
    for idx, item in enumerate(items, 1):
        r = item.get('last_result') or {}
        status = r.get('status','unknown')
        sc = STATUS_COLOR.get(status, '#6b7280')
        td_cells = f'<td style="font-family:monospace">{idx}</td>'
        td_cells += f'<td><strong>{name_fn(item)}</strong></td>'
        for cls, hdr, fn in visible:
            try:   cell = fn(item, r)
            except: cell = '—'
            td_cells += f'<td style="white-space:nowrap">{cell}</td>'
        td_cells += f'<td>{_badge(status)}</td>'
        rows += f'<tr>{"".join(td_cells)}</tr>'

    mod_label = {'oracle':'Oracle','sqlserver':'SQL Server',
                 'linux':'Linux','windows':'Windows'}.get(module, module.upper())

    return f'''<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<style>
  body{{font-family:Segoe UI,Arial,sans-serif;background:#f8fafc;color:#1e293b;margin:0;padding:20px}}
  .hdr{{background:linear-gradient(135deg,#1a2744,#2563eb);color:#fff;padding:20px 28px;border-radius:12px;margin-bottom:20px}}
  .hdr h1{{margin:0;font-size:22px}} .hdr p{{margin:4px 0 0;opacity:.75;font-size:12px}}
  .summary{{display:flex;gap:14px;margin-bottom:20px}}
  .sc{{background:#fff;border-radius:8px;padding:14px 20px;flex:1;border:1px solid #e2e8f0;text-align:center}}
  .sc .n{{font-size:28px;font-weight:700;font-family:monospace}}
  .sc .l{{font-size:11px;color:#64748b;margin-top:2px}}
  .healthy{{color:#16a34a}} .critical{{color:#dc2626}} .total{{color:#2563eb}} .warn{{color:#d97706}}
  table{{width:100%;border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.1)}}
  th{{background:#1a2744;color:#fff;padding:9px 11px;font-size:10px;font-weight:700;text-align:left;white-space:nowrap;letter-spacing:.4px}}
  td{{padding:8px 11px;border-bottom:1px solid #f1f5f9;font-size:11px;white-space:nowrap}}
  tr:hover td{{background:#f8fafc}}
  .footer{{text-align:center;color:#94a3b8;font-size:10px;margin-top:16px}}
  .col-note{{font-size:10px;color:#94a3b8;margin-bottom:8px;font-style:italic}}
</style></head><body>
<div class="hdr">
  <h1>{icon_map.get(module,'')} Pulse — {mod_label} Health Report</h1>
  <p>Generated: {now}</p>
</div>
<div class="summary">
  <div class="sc"><div class="n total">{total}</div><div class="l">Total</div></div>
  <div class="sc"><div class="n healthy">{healthy}</div><div class="l">Healthy</div></div>
  <div class="sc"><div class="n critical">{critical}</div><div class="l">Critical</div></div>
  <div class="sc"><div class="n warn">{total-healthy-critical}</div><div class="l">Other</div></div>
</div>
<p class="col-note">Showing {len(visible)+2} of {len(col_defs)+2} columns (matches your screen selection)</p>
<table><thead><tr>{th_cells}</tr></thead><tbody>{rows}</tbody></table>
<div class="footer">Pulse Infrastructure Monitor &bull; {now}</div>
</body></html>'''


def send_report(module: str, items: list, to_email: str,
                hidden_cols: list = None) -> tuple:
    """Send HTML report via SMTP with smart SSL auto-detection."""
    cfg = get_email_config()
    if not cfg.get('smtp_host'):
        return False, 'SMTP not configured. Set it in Settings → Email.'

    html = build_html_report(module, items, hidden_cols=hidden_cols)
    mod_label = {'oracle':'Oracle','sqlserver':'SQL Server',
                 'linux':'Linux','windows':'Windows'}.get(module, module.upper())

    msg = MIMEMultipart('alternative')
    msg['Subject'] = (f'Pulse Health Report — {mod_label} — '
                      f'{datetime.datetime.now().strftime("%Y-%m-%d %H:%M")}')
    msg['From'] = cfg.get('from_email') or cfg.get('smtp_user', '')
    msg['To']   = to_email
    msg.attach(MIMEText(html, 'html', 'utf-8'))

    smtp_host = cfg['smtp_host']
    smtp_pass = decrypt_password(cfg.get('smtp_password_enc', ''))
    smtp_user = cfg.get('smtp_user', '')
    port      = int(cfg.get('smtp_port', 587))
    use_tls   = cfg.get('tls', True)  # True = STARTTLS, False = SSL_wrap

    # ── Smart SSL strategy ────────────────────────────────────────────────────
    # Port 465 → implicit SSL (SMTP_SSL); Port 587/25 → STARTTLS.
    # If the user setting disagrees with the port, we auto-correct.
    # Strategy order: try user's choice first, then the alternative, then plain.

    ssl_ctx = ssl.create_default_context()
    # For internal SMTP relays that use self-signed certs:
    ssl_ctx_nocheck = ssl.create_default_context()
    ssl_ctx_nocheck.check_hostname = False
    ssl_ctx_nocheck.verify_mode = ssl.CERT_NONE

    def _try_send(server):
        if smtp_user and smtp_pass:
            server.login(smtp_user, smtp_pass)
        elif smtp_user:
            server.login(smtp_user, '')
        server.sendmail(msg['From'], [to_email], msg.as_string())
        server.quit()

    attempts = []

    if port == 465 or not use_tls:
        # Implicit SSL first
        attempts = [
            ('SMTP_SSL verified',   lambda: smtplib.SMTP_SSL(smtp_host, port, timeout=15, context=ssl_ctx)),
            ('SMTP_SSL no-verify',  lambda: smtplib.SMTP_SSL(smtp_host, port, timeout=15, context=ssl_ctx_nocheck)),
            ('STARTTLS verified',   lambda: _starttls(smtp_host, port, ssl_ctx)),
            ('STARTTLS no-verify',  lambda: _starttls(smtp_host, port, ssl_ctx_nocheck)),
            ('Plain SMTP',          lambda: _plain_smtp(smtp_host, port)),
        ]
    else:
        # STARTTLS first (port 587 default)
        attempts = [
            ('STARTTLS verified',   lambda: _starttls(smtp_host, port, ssl_ctx)),
            ('STARTTLS no-verify',  lambda: _starttls(smtp_host, port, ssl_ctx_nocheck)),
            ('SMTP_SSL verified',   lambda: smtplib.SMTP_SSL(smtp_host, port, timeout=15, context=ssl_ctx)),
            ('SMTP_SSL no-verify',  lambda: smtplib.SMTP_SSL(smtp_host, port, timeout=15, context=ssl_ctx_nocheck)),
            ('Plain SMTP',          lambda: _plain_smtp(smtp_host, port)),
        ]

    errors = []
    for label, factory in attempts:
        try:
            _try_send(factory())
            return True, f'Email sent via {label}'
        except Exception as e:
            errors.append(f'{label}: {str(e)[:80]}')
            continue

    return False, 'All SMTP attempts failed:\n' + '\n'.join(errors)


def _starttls(host, port, ctx):
    s = smtplib.SMTP(host, port, timeout=15)
    s.ehlo()
    s.starttls(context=ctx)
    s.ehlo()
    return s


def _plain_smtp(host, port):
    s = smtplib.SMTP(host, port, timeout=15)
    s.ehlo()
    return s
