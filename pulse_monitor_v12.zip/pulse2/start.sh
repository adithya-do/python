#!/bin/bash
# Pulse Infrastructure Monitor — Start Script

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo "  ⬡ PULSE Infrastructure Health Monitor"
echo "  ─────────────────────────────────────────────"

# Check Python
python3 --version >/dev/null 2>&1 || { echo "  ✗ Python 3 not found"; exit 1; }

# Install deps if needed
if ! python3 -c "import flask, cryptography, werkzeug" 2>/dev/null; then
  echo "  Installing dependencies..."
  pip3 install flask werkzeug cryptography --break-system-packages -q || \
  pip3 install flask werkzeug cryptography -q
fi

# Create directories
mkdir -p data certs logs

# Set production secret key (change this!)
export PULSE_SECRET_KEY="${PULSE_SECRET_KEY:-$(python3 -c 'import secrets; print(secrets.token_hex(32))')}"

echo "  Starting Pulse..."
echo "  ─────────────────────────────────────────────"
echo "  HTTPS: https://localhost:5443"
echo "  HTTP:  Set PULSE_HTTP_ONLY=1 for port 5000"
echo "  Login: admin / admin123"
echo "  ─────────────────────────────────────────────"
echo ""

python3 app.py "$@"
