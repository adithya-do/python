"""Windows server health check — SSH + PowerShell (pwsh/powershell).
Does NOT use WinRM. Requires OpenSSH Server on the Windows host.
"""
import socket, datetime, re
from config_store import resolve_credentials

def check_windows(srv):
    result = {
        'id': srv['id'], 'server_name': srv.get('server_name',''),
        'environment': srv.get('environment',''), 'host': srv.get('host',''),
        'ip_address': '—',
        'status': 'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'os': 'Windows', 'os_version': '—',
        'memory_gb': '—', 'memory_usage_pct': '—',
        'cpu_count': '—', 'cpu_load_avg': '—',
        'worst_disk': '—', 'worst_disk_pct': '—',
        'uptime': '—',
    }

    host = srv.get('host','')
    try:   port = int(srv.get('ssh_port', 22))
    except: port = 22

    # TCP reachability
    start = datetime.datetime.now()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((host, port))
        sock.settimeout(3)
        try: sock.recv(256)
        except Exception: pass
        sock.close()
        result['response_ms'] = round((datetime.datetime.now()-start).total_seconds()*1000, 1)
        try:
            result['ip_address'] = socket.gethostbyname(host)
        except Exception:
            result['ip_address'] = host
    except Exception as e:
        result.update(status='critical', check_status='completed',
                      error=f'SSH port {port} unreachable: {e}. Ensure OpenSSH Server is installed and running on the Windows host.')
        return result

    username, password = resolve_credentials(srv)
    key_path = srv.get('ssh_key_path','')
    if not username:
        result.update(status='reachable', check_status='completed',
                      error='No credentials. Add in Settings → Credential Store.')
        return result

    try:
        import paramiko  # type: ignore

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kw = dict(hostname=host, port=port, username=username, timeout=15,
                  banner_timeout=10, auth_timeout=10)
        if key_path:   kw['key_filename'] = key_path
        elif password: kw['password']     = password
        client.connect(**kw)

        # Detect PowerShell binary (pwsh = PS 7+, fallback powershell = PS 5)
        def run(cmd):
            try:
                _, out, _ = client.exec_command(cmd, timeout=15)
                return out.read().decode(errors='replace').strip()
            except Exception:
                return ''

        pwsh = 'pwsh'
        test = run('pwsh -Command "Write-Output ok"')
        if test.strip() != 'ok':
            pwsh = 'powershell'

        def ps(script):
            """Run a PowerShell one-liner."""
            cmd = f'{pwsh} -NoProfile -NonInteractive -Command "{script}"'
            return run(cmd)

        # OS version
        os_ver = ps('(Get-CimInstance Win32_OperatingSystem).Caption')
        result['os_version'] = os_ver or 'Windows'
        result['os'] = 'Windows'

        # Uptime
        uptime_days = ps(
            '$os=(Get-CimInstance Win32_OperatingSystem);'
            '$u=[math]::Round(($os.LocalDateTime-$os.LastBootUpTime).TotalDays,1);'
            'Write-Output $u')
        if uptime_days:
            try:
                d = float(uptime_days)
                days  = int(d)
                hours = int((d - days) * 24)
                result['uptime'] = f"{days}d {hours}h"
            except ValueError:
                result['uptime'] = uptime_days

        # CPU count
        ncpu = ps('(Get-CimInstance Win32_ComputerSystem).NumberOfLogicalProcessors')
        result['cpu_count'] = ncpu.strip() if ncpu.strip().isdigit() else '—'

        # CPU load (average %)
        cpu_load = ps(
            '$l=Get-Counter "\\Processor(_Total)\\% Processor Time" -SampleInterval 1 -MaxSamples 1;'
            'Write-Output ([math]::Round($l.CounterSamples[0].CookedValue,1))')
        if cpu_load:
            try:
                result['cpu_load_avg'] = f"{float(cpu_load):.1f}%"
            except ValueError:
                result['cpu_load_avg'] = cpu_load

        # Memory
        mem_out = ps(
            '$os=Get-CimInstance Win32_OperatingSystem;'
            '$total=[math]::Round($os.TotalVisibleMemorySize/1MB,1);'
            '$free=[math]::Round($os.FreePhysicalMemory/1MB,1);'
            'Write-Output "$total,$free"')
        if mem_out and ',' in mem_out:
            parts = mem_out.split(',')
            try:
                total_gb = float(parts[0])
                free_gb  = float(parts[1])
                used_pct = round((1 - free_gb/total_gb)*100, 1) if total_gb > 0 else 0
                result['memory_gb']         = total_gb
                result['memory_usage_pct']  = f"{used_pct}%"
            except (ValueError, ZeroDivisionError):
                pass

        # Worst disk
        disk_out = ps(
            'Get-PSDrive -PSProvider FileSystem |'
            ' Where-Object{$_.Used -gt 0} |'
            ' ForEach-Object{'
            '   $t=$_.Used+$_.Free;'
            '   $p=[math]::Round($_.Used/$t*100,1);'
            '   Write-Output "$p,$($_.Name):"'
            ' }')
        if disk_out:
            best_pct   = -1
            best_mount = None
            for line in disk_out.splitlines():
                parts = line.split(',', 1)
                if len(parts) == 2:
                    try:
                        pct = float(parts[0])
                        if pct > best_pct:
                            best_pct   = pct
                            best_mount = parts[1].strip()
                    except ValueError:
                        pass
            if best_mount:
                result['worst_disk']     = best_mount
                result['worst_disk_pct'] = f"{int(best_pct)}%"

        client.close()
        result.update(status='healthy', check_status='completed',
                      message=f'SSH + {pwsh} connected')

    except ImportError:
        result.update(status='reachable', check_status='completed',
                      error='Install paramiko: pip install paramiko --break-system-packages')
    except paramiko.AuthenticationException:
        result.update(status='critical', check_status='completed',
                      error='SSH authentication failed — check credentials in Settings → Credential Store')
    except Exception as e:
        result.update(status='warning', check_status='completed',
                      error=f'SSH/PS error: {str(e)[:200]}')

    return result
