"""
Jump host relay for SQL Server checks.
SSHes into a Windows host and runs sqlcmd/PowerShell to collect metrics.
"""
import re, datetime
from config_store import resolve_credentials, get_jump_hosts


def _get_jump_host(jh_id):
    if not jh_id:
        return None
    for h in get_jump_hosts():
        if h['id'] == jh_id:
            return h
    return None


def check_via_jumphost(inst, result):
    """
    Connect to the configured jump host via SSH, run sqlcmd/PowerShell
    against the target SQL Server, populate result dict.
    Returns True if jump host check succeeded, False otherwise.
    """
    jh_id = inst.get('jump_host_id', '')
    jh    = _get_jump_host(jh_id)
    if not jh:
        return False

    jh_host = jh.get('host', '')
    try:   jh_port = int(jh.get('ssh_port', 22))
    except: jh_port = 22

    jh_user, jh_pass = resolve_credentials(jh)
    jh_key  = jh.get('ssh_key_path', '')

    if not jh_host or not jh_user:
        result['error'] = 'Jump host misconfigured — check label/host/credentials in Settings'
        return False

    # Target SQL Server connection details (from inst)
    host_raw = inst.get('host', '').strip()
    hostname = host_raw
    instance = ''
    port     = 1433
    if ',' in hostname:
        h, p = hostname.rsplit(',', 1)
        hostname = h.strip()
        try: port = int(p.strip())
        except ValueError: pass
    else:
        try: port = int(inst.get('port', 1433) or 1433)
        except (ValueError, TypeError): port = 1433
    bs = chr(92)
    if bs in hostname:
        hostname, instance = hostname.split(bs, 1)

    # Build the SERVER string for sqlcmd / SqlConnection
    if instance:
        server_str = f"{hostname}{bs}{instance}"
        if port != 1433:
            server_str += f",{port}"
    else:
        server_str = f"{hostname},{port}"

    tgt_user, tgt_pass = resolve_credentials(inst)
    if not tgt_user or not tgt_pass:
        result['error'] = 'No SQL Server credentials configured'
        return False

    try:
        import paramiko  # type: ignore

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kw = dict(hostname=jh_host, port=jh_port, username=jh_user,
                  timeout=15, banner_timeout=10, auth_timeout=10)
        if jh_key:   kw['key_filename'] = jh_key
        elif jh_pass: kw['password']    = jh_pass
        client.connect(**kw)

        def run(cmd):
            try:
                _, out, err = client.exec_command(cmd, timeout=20)
                return out.read().decode(errors='replace').strip()
            except Exception:
                return ''

        # ── Detect sqlcmd availability ────────────────────────────────────
        sqlcmd_path = run('where sqlcmd 2>nul || which sqlcmd 2>/dev/null')
        if not sqlcmd_path:
            sqlcmd_path = r'sqlcmd'   # rely on PATH

        # Escape password for cmd.exe (wrap in double-quotes, escape embedded ones)
        safe_pass = tgt_pass.replace('"', '\\"')
        safe_user = tgt_user.replace('"', '\\"')

        def sqlcmd(query, extra_flags=''):
            """Run a query via sqlcmd, return first non-header line."""
            cmd = (
                f'sqlcmd -S "{server_str}" -U "{safe_user}" -P "{safe_pass}" '
                f'-Q "{query}" -h -1 -W -l 10 {extra_flags} 2>&1'
            )
            out = run(cmd)
            # Strip common sqlcmd noise
            lines = [l.strip() for l in out.splitlines()
                     if l.strip() and '----' not in l
                     and 'rows affected' not in l.lower()
                     and 'changed database' not in l.lower()]
            return lines[0] if lines else ''

        # ── Connectivity test ─────────────────────────────────────────────
        ver_raw = sqlcmd("SELECT @@VERSION")
        if not ver_raw:
            # Try PowerShell as fallback
            ps_cmd = (
                f"powershell -Command \""
                f"$c=New-Object System.Data.SqlClient.SqlConnection;"
                f"$c.ConnectionString='Server={server_str};"
                f"User ID={safe_user};Password={safe_pass};"
                f"TrustServerCertificate=True;Connection Timeout=10;';"
                f"$c.Open();Write-Output $c.ServerVersion;$c.Close()\""
            )
            ver_raw = run(ps_cmd)
            if not ver_raw:
                result['error'] = (
                    f'Jump host ({jh_host}) reached but sqlcmd could not '
                    f'connect to {server_str}. Ensure sqlcmd is installed on '
                    f'the jump host and the SQL Server is reachable from it.'
                )
                client.close()
                return False

        # ── Version ───────────────────────────────────────────────────────
        m = re.search(r'(\d+\.\d+\.\d+\.\d+)', ver_raw)
        if m:
            full_ver = m.group(1)
            result['full_version'] = full_ver
            major = full_ver.split('.')[0]
            year_map = {'16':'2022','15':'2019','14':'2017',
                        '13':'2016','12':'2014','11':'2012'}
            result['major_version'] = year_map.get(major, major)

        # ── Instance status ───────────────────────────────────────────────
        result['instance_status'] = 'ONLINE'

        # ── Edition ───────────────────────────────────────────────────────
        edition_raw = sqlcmd(
            "SELECT CAST(SERVERPROPERTY('Edition') AS NVARCHAR(128))")
        if edition_raw:
            r = edition_raw.lower()
            result['edition'] = ('Enterprise' if 'enterprise' in r else
                                 'Standard'   if 'standard'   in r else
                                 'Developer'  if 'developer'  in r else
                                 'Express'    if 'express'    in r else
                                 edition_raw.split()[0])

        # ── CU / patch level ──────────────────────────────────────────────
        cu_raw = sqlcmd("SELECT CAST(SERVERPROPERTY('ProductUpdateLevel') AS NVARCHAR(64))")
        result['cu'] = cu_raw or '—'

        # ── Agent status ──────────────────────────────────────────────────
        agent_raw = sqlcmd(
            "SELECT status FROM sys.dm_server_services "
            "WHERE servicename LIKE 'SQL Server Agent%'")
        if agent_raw and agent_raw.isdigit():
            result['agent_status'] = 'Up' if int(agent_raw) == 4 else 'Down'

        # ── OS version ────────────────────────────────────────────────────
        os_raw = sqlcmd(
            "SELECT CAST(SERVERPROPERTY('WindowsVersion') AS NVARCHAR(128))")
        result['os_version'] = os_raw or '—'

        # ── Sessions ─────────────────────────────────────────────────────
        sess_cur = sqlcmd("SELECT COUNT(*) FROM sys.dm_exec_sessions WHERE is_user_process=1")
        sess_max = sqlcmd("SELECT value_in_use FROM sys.configurations WHERE name='max connections'")
        if sess_cur and sess_cur.isdigit(): result['sessions_current'] = int(sess_cur)
        if sess_max and sess_max.isdigit(): result['sessions_max']     = int(sess_max)

        # ── DB counts ─────────────────────────────────────────────────────
        db_total  = sqlcmd("SELECT COUNT(*) FROM sys.databases")
        db_online = sqlcmd(
            "SELECT COUNT(*) FROM sys.databases WHERE state_desc='ONLINE'")
        if db_total and db_total.isdigit():
            result['db_total']    = int(db_total)
            result['db_online']   = int(db_online) if (db_online and db_online.isdigit()) else 0
            result['db_mismatch'] = result['db_online'] < result['db_total']

        # ── Last backup ───────────────────────────────────────────────────
        bkp_raw = sqlcmd(
            "SELECT TOP 1 CONVERT(VARCHAR(16),backup_finish_date,120) "
            "FROM msdb.dbo.backupset WHERE type='D' ORDER BY backup_finish_date DESC")
        if bkp_raw:
            result['last_backup'] = bkp_raw
            try:
                dt  = datetime.datetime.strptime(bkp_raw, '%Y-%m-%d %H:%M')
                result['last_backup_days'] = (datetime.datetime.now() - dt).days
            except Exception:
                pass

        # ── Encryption ────────────────────────────────────────────────────
        enc_total = sqlcmd(
            "SELECT COUNT(*) FROM sys.databases WHERE database_id>4")
        enc_enc   = sqlcmd(
            "SELECT COUNT(*) FROM sys.dm_database_encryption_keys "
            "WHERE encryption_state=3")
        if enc_total and enc_total.isdigit():
            result['enc_total']     = int(enc_total)
            result['enc_encrypted'] = int(enc_enc) if (enc_enc and enc_enc.isdigit()) else 0

        client.close()
        result.update(status='healthy', check_status='completed',
                      message=f'Via jump host {jh.get("label", jh_host)}',
                      error='')
        return True

    except ImportError:
        result['error'] = 'paramiko not installed — needed for jump host SSH'
        return False
    except Exception as e:
        result['error'] = f'Jump host SSH error: {str(e)[:200]}'
        return False
