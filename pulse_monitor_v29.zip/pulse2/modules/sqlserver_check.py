"""SQL Server health check — ODBC Driver 18, full metrics."""
import socket, datetime
from config_store import resolve_credentials

# Agent service status codes from sys.dm_server_services
_AGENT_STATUS = {1:'Down', 2:'Down', 3:'Down', 4:'Up', 5:'Down', 6:'Down', 7:'Down'}

# Edition normalisation
def _short_edition(raw):
    if not raw: return '—'
    r = str(raw).lower()
    if 'enterprise' in r: return 'Enterprise'
    if 'standard'   in r: return 'Standard'
    if 'developer'  in r: return 'Developer'
    if 'express'    in r: return 'Express'
    if 'web'        in r: return 'Web'
    if 'datacenter' in r: return 'Datacenter'
    return str(raw).split(' ')[0]   # fallback: first word

def check_sqlserver(inst):
    result = {
        'id': inst['id'],
        'instance_name': inst.get('instance_name', ''),
        'environment':   inst.get('environment', ''),
        'host':          inst.get('host', ''),
        'status':        'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms':     None,
        'full_version':    '—',   # digits only e.g. 16.0.4250.0
        'major_version':   '—',   # year e.g. 2022
        'cu':              '—',
        'instance_status': '—',
        'agent_status':    '—',   # Up / Down
        'db_total':  '—', 'db_online': '—', 'db_mismatch': False,
        'edition':   '—',          # Enterprise / Standard / Developer
        'os_version': '—',
        'sessions_current': '—', 'sessions_max': '—',
        'last_backup': '—', 'last_backup_days': None,
        # New: Encryption column  "X/Y" (encrypted/total user DBs)
        'enc_total':     '—',
        'enc_encrypted': '—',
    }

    host_raw = inst.get('host', '').strip()
    port_raw = inst.get('port', '1433')

    # ── Parse host field — supports all SQL Server naming formats: ────────
    #   HOSTNAME               → plain TCP port 1433
    #   HOSTNAME\INSTANCE      → named instance, ODBC handles port discovery
    #   HOSTNAME,PORT          → explicit port
    #   HOSTNAME\INSTANCE,PORT → named instance with explicit port
    hostname = host_raw
    instance = ''
    port     = 1433

    # Extract explicit port (suffix ",PORT")
    if ',' in host_raw:
        h_part, p_part = host_raw.rsplit(',', 1)
        hostname = h_part.strip()
        try:   port = int(p_part.strip())
        except ValueError: pass
    else:
        try:   port = int(port_raw or 1433)
        except (ValueError, TypeError): port = 1433

    # Extract instance name (suffix "\INSTANCE")
    if '\\' in hostname:
        hostname, instance = hostname.split('\\', 1)
    elif chr(92) in hostname:
        hostname, instance = hostname.split(chr(92), 1)

    hostname = hostname.strip()
    instance = instance.strip()

    # ── TCP reachability — connect to hostname only (no backslash) ────────
    start = datetime.datetime.now()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((hostname, port))
        sock.close()
        result['response_ms'] = round(
            (datetime.datetime.now() - start).total_seconds() * 1000, 1)
    except Exception as e:
        tcp_err = (f'Direct TCP {hostname}:{port} unreachable: {e}. '
                   f'For named instances ensure SQL Server Browser is running '
                   f'or specify port explicitly (HOST\\INSTANCE,PORT).')
        # ── Try jump host if configured ───────────────────────────────────
        if inst.get('jump_host_id'):
            from modules.jumphost_check import check_via_jumphost
            result['error'] = tcp_err
            if check_via_jumphost(inst, result):
                return result
            # jump host also failed — show both errors
            result['error'] = tcp_err + ' | Jump host: ' + result.get('error','failed')
        else:
            result['error'] = tcp_err
        result.update(status='critical', check_status='completed')
        return result

    username, password = resolve_credentials(inst)
    if not username or not password:
        result.update(status='warning', check_status='completed',
                      error='No credentials configured')
        return result

    try:
        import pyodbc  # type: ignore

        def _sql_variant_conv(raw):
            """Convert sql_variant bytes to string safely."""
            if raw is None: return None
            try:   return raw.decode('utf-16-le', errors='replace').rstrip('\x00')
            except: return repr(raw)

        # Build SERVER value for ODBC connection string:
        #   Named instance without explicit port → SERVER=HOST\INSTANCE
        #     (ODBC driver uses SQL Browser on UDP 1434 to resolve port)
        #   Named instance with explicit port   → SERVER=HOST\INSTANCE,PORT
        #   Default instance                    → SERVER=HOST,PORT
        if instance:
            server_dsn = (f"{hostname}\\{instance},{port}"
                          if port != 1433 else f"{hostname}\\{instance}")
        else:
            server_dsn = f"{hostname},{port}"

        conn_str = (
            f"DRIVER={{ODBC Driver 18 for SQL Server}};"
            f"SERVER={server_dsn};UID={username};PWD={password};"
            f"Connection Timeout=15;TrustServerCertificate=yes;Encrypt=yes;"
        )
        t0 = datetime.datetime.now()
        conn = pyodbc.connect(conn_str, timeout=15)
        result['response_ms'] = round(
            (datetime.datetime.now() - t0).total_seconds() * 1000, 1)

        for tc in (-150, 150, -151, 151, -155, 155):
            try: conn.add_output_converter(tc, _sql_variant_conv)
            except: pass

        cur = conn.cursor()

        def _q(sql):
            try:
                cur.execute(sql)
                return cur.fetchone()
            except Exception:
                return None

        # ── Version (digits only) ──────────────────────────────────────────
        row = _q(
            "SELECT "
            "  CAST(SERVERPROPERTY('ProductVersion')     AS NVARCHAR(64)), "
            "  CAST(SERVERPROPERTY('Edition')            AS NVARCHAR(128)), "
            "  CAST(SERVERPROPERTY('ProductUpdateLevel') AS NVARCHAR(64))"
        )
        if row:
            ver_str = str(row[0]).strip() if row[0] else ''
            result['full_version'] = ver_str or '—'
            major = ver_str.split('.')[0] if ver_str else ''
            year_map = {'8':'2000','9':'2005','10':'2008','11':'2012',
                        '12':'2014','13':'2016','14':'2017','15':'2019','16':'2022'}
            result['major_version'] = year_map.get(major, major or '—')
            result['edition'] = _short_edition(row[1])
            result['cu']      = str(row[2]).strip() if row[2] else '—'

        # ── Instance status ────────────────────────────────────────────────
        row = _q("SELECT state_desc FROM sys.databases WHERE name = 'master'")
        result['instance_status'] = str(row[0]) if row and row[0] else '—'

        # ── SQL Server Agent — sys.dm_server_services ─────────────────────
        # status column is TINYINT: 1=Stopped,2=StartPending,3=StopPending,
        # 4=Running,5=ContinuePending,6=PausePending,7=Paused
        row = _q(
            "SELECT TOP 1 status "
            "FROM sys.dm_server_services "
            "WHERE servicename LIKE N'SQL Server Agent%'"
        )
        if row and row[0] is not None:
            try:   result['agent_status'] = _AGENT_STATUS.get(int(row[0]), 'Down')
            except: result['agent_status'] = 'Down'
        else:
            result['agent_status'] = '—'

        # ── DB counts ──────────────────────────────────────────────────────
        row = _q(
            "SELECT COUNT(*), "
            "SUM(CASE WHEN state_desc='ONLINE' THEN 1 ELSE 0 END) "
            "FROM sys.databases"
        )
        if row:
            result['db_total']    = row[0]
            result['db_online']   = row[1] if row[1] is not None else 0
            result['db_mismatch'] = (row[1] is not None and row[1] < row[0])

        # ── Sessions ───────────────────────────────────────────────────────
        row = _q(
            "SELECT @@MAX_CONNECTIONS, "
            "(SELECT COUNT(*) FROM sys.dm_exec_sessions WHERE is_user_process=1)"
        )
        if row:
            result['sessions_max']     = row[0]
            result['sessions_current'] = row[1]

        # ── OS info ────────────────────────────────────────────────────────
        row = _q("SELECT host_distribution, host_release FROM sys.dm_os_host_info")
        if row:
            import re
            dist = str(row[0] or '')
            rel  = str(row[1] or '')
            # Normalise: "Windows Server 2019 Standard" → "2019 Standard"
            yr = re.search(r'(20\d\d)', dist + ' ' + rel)
            ed_kw = next((k for k in ('Datacenter','Standard','Essentials','Enterprise')
                          if k.lower() in dist.lower()), '')
            result['os_version'] = (
                ((yr.group(1) + ' ') if yr else '') + ed_kw
            ).strip() or (dist + ' ' + rel).strip() or '—'

        # ── Last full backup ───────────────────────────────────────────────
        row = _q(
            "SELECT TOP 1 "
            "  CONVERT(NVARCHAR(16), MAX(backup_finish_date), 120) "
            "FROM msdb.dbo.backupset "
            "WHERE type = 'D' "
            "  AND database_name NOT IN ('master','model','msdb','tempdb') "
            "  AND backup_finish_date IS NOT NULL"
        )
        if row and row[0]:
            bkp = str(row[0])[:16]
            result['last_backup'] = bkp
            try:
                dt  = datetime.datetime.strptime(bkp, '%Y-%m-%d %H:%M')
                result['last_backup_days'] = (datetime.datetime.now() - dt).days
            except Exception:
                pass
        else:
            result['last_backup'] = 'Never'

        # ── Encryption (TDE) ──────────────────────────────────────────────
        # Count user databases + how many have TDE enabled (encryption_state=3)
        row = _q(
            "SELECT "
            "  COUNT(*) AS total_user_dbs, "
            "  SUM(CASE WHEN de.encryption_state = 3 THEN 1 ELSE 0 END) AS encrypted "
            "FROM sys.databases d "
            "LEFT JOIN sys.dm_database_encryption_keys de "
            "  ON d.database_id = de.database_id "
            "WHERE d.name NOT IN ('master','model','msdb','tempdb') "
            "  AND d.database_id > 4"
        )
        if row and row[0] is not None:
            result['enc_total']     = int(row[0])
            result['enc_encrypted'] = int(row[1]) if row[1] is not None else 0
        else:
            # Fallback without dm_database_encryption_keys (limited perms)
            row2 = _q(
                "SELECT COUNT(*) FROM sys.databases "
                "WHERE name NOT IN ('master','model','msdb','tempdb') "
                "  AND database_id > 4"
            )
            result['enc_total']     = int(row2[0]) if row2 else '—'
            result['enc_encrypted'] = 0

        cur.close()
        conn.close()
        result.update(status='healthy', check_status='completed', message='OK')

    except ImportError:
        result.update(status='reachable', check_status='completed',
                      error='TCP OK. Install pyodbc for full SQL Server checks.')
    except Exception as e:
        result.update(status='critical', check_status='completed',
                      error=str(e)[:300])

    return result
