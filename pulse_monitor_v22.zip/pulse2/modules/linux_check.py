"""Linux server health check — robust SSH + /proc-based metrics."""
import socket, datetime
from config_store import resolve_credentials

DASH = '—'  # em dash placeholder (not stored in result when we have real data)

def check_linux(srv):
    result = {
        'id': srv['id'], 'server_name': srv.get('server_name', ''),
        'environment': srv.get('environment', ''), 'host': srv.get('host', ''),
        'ip_address': DASH,
        'status': 'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'os': DASH, 'os_version': DASH,
        'memory_gb': DASH, 'memory_usage_pct': DASH,
        'cpu_count': DASH, 'cpu_load_avg': DASH,
        'worst_disk': DASH, 'worst_disk_pct': DASH,
        'uptime': DASH,
    }

    host = srv.get('host', '')
    try:   port = int(srv.get('ssh_port', 22))
    except: port = 22

    # ── TCP reachability ──────────────────────────────────────────────────
    start = datetime.datetime.now()
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(5)
        sock.connect((host, port))
        sock.settimeout(3)                 # short timeout for banner recv
        try:   sock.recv(256)
        except Exception: pass             # banner optional — don't fail
        sock.close()
        result['response_ms'] = round((datetime.datetime.now() - start).total_seconds() * 1000, 1)
    except Exception as e:
        result.update(status='critical', check_status='completed',
                      error=f'SSH port {port} unreachable: {e}')
        return result

    # Resolve actual IP (non-blocking, best-effort)
    try:
        result['ip_address'] = socket.gethostbyname(host)
    except Exception:
        result['ip_address'] = host

    # ── Credentials ───────────────────────────────────────────────────────
    username, password = resolve_credentials(srv)
    key_path = srv.get('ssh_key_path', '')
    if not username:
        result.update(status='reachable', check_status='completed',
                      error='No credentials. Add in Settings → Credential Store.')
        return result

    # ── SSH connect ───────────────────────────────────────────────────────
    try:
        import paramiko  # type: ignore

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kw = dict(hostname=host, port=port, username=username, timeout=15,
                  banner_timeout=10, auth_timeout=10)
        if key_path:   kw['key_filename'] = key_path
        elif password: kw['password']     = password
        client.connect(**kw)

        def run(cmd):
            """Execute command, return stripped stdout or empty string."""
            try:
                _, out, _ = client.exec_command(cmd, timeout=10)
                data = out.read().decode(errors='replace').strip()
                return data
            except Exception:
                return ''

        # ── OS ────────────────────────────────────────────────────────────
        result['os'] = run("uname -s") or 'Linux'
        os_ver = (run("grep '^PRETTY_NAME' /etc/os-release 2>/dev/null | cut -d= -f2 | tr -d '\"'") or
                  run("cat /etc/redhat-release 2>/dev/null") or
                  run("cat /etc/debian_version 2>/dev/null") or
                  run("uname -r"))
        result['os_version'] = os_ver or DASH

        # ── Uptime ────────────────────────────────────────────────────────
        uptime_sec = run("awk '{print $1}' /proc/uptime 2>/dev/null")
        if uptime_sec:
            try:
                secs  = float(uptime_sec)
                days  = int(secs // 86400)
                hours = int((secs % 86400) // 3600)
                mins  = int((secs % 3600) // 60)
                result['uptime'] = f"{days}d {hours}h {mins}m" if days > 0 else f"{hours}h {mins}m"
            except ValueError:
                result['uptime'] = run("uptime") or DASH
        else:
            result['uptime'] = run("uptime") or DASH

        # ── CPU ───────────────────────────────────────────────────────────
        ncpu = (run("nproc 2>/dev/null") or
                run("grep -c '^processor' /proc/cpuinfo 2>/dev/null"))
        result['cpu_count'] = ncpu.strip() if ncpu.strip().isdigit() else DASH

        load = run("awk '{print $1, $2, $3}' /proc/loadavg 2>/dev/null")
        result['cpu_load_avg'] = load or DASH

        # ── Memory via /proc/meminfo ─────────────────────────────────────
        meminfo_raw = run("cat /proc/meminfo 2>/dev/null")
        if meminfo_raw:
            vals = {}
            for line in meminfo_raw.splitlines():
                parts = line.split()
                if len(parts) >= 2:
                    key = parts[0].rstrip(':')
                    try: vals[key] = int(parts[1])
                    except ValueError: pass

            total_kb = vals.get('MemTotal', 0)
            avail_kb = vals.get('MemAvailable', vals.get('MemFree', 0))
            if total_kb > 0:
                used_kb = total_kb - avail_kb
                result['memory_gb']         = round(total_kb / 1048576, 1)
                result['memory_usage_pct']  = f"{round(used_kb / total_kb * 100, 1)}%"

        # ── Disk via POSIX df -P ──────────────────────────────────────────
        # df -P: Filesystem 512-blocks Used Available Capacity% Mounted
        df_raw = run("df -Pk 2>/dev/null | awk 'NR>1{print $5, $6}' | sort -rn")
        if df_raw:
            for line in df_raw.splitlines():
                parts = line.split(None, 1)
                if len(parts) == 2:
                    pct_raw = parts[0].replace('%', '')
                    mount   = parts[1].strip()
                    skip_mounts = ('/proc', '/sys', '/dev', '/run/lock', '/run/user',
                                   'devtmpfs', 'tmpfs', 'udev', 'cgmfs')
                    if any(mount.startswith(s) or s in mount for s in skip_mounts):
                        continue
                    try:
                        pct = float(pct_raw)
                        result['worst_disk']     = mount
                        result['worst_disk_pct'] = f"{int(pct)}%"
                        break
                    except ValueError:
                        continue

        client.close()
        result.update(status='healthy', check_status='completed', message='SSH connected')

    except ImportError:
        result.update(status='reachable', check_status='completed',
                      error='Install paramiko: pip install paramiko --break-system-packages')
    except paramiko.AuthenticationException:
        result.update(status='critical', check_status='completed',
                      error='SSH auth failed — check credentials in Settings → Credential Store')
    except Exception as e:
        result.update(status='warning', check_status='completed',
                      error=f'SSH error: {str(e)[:200]}')

    return result
