"""SQL Server health check — comprehensive metrics."""
import socket, datetime, re
from config_store import decrypt_password

def check_sqlserver(inst: dict) -> dict:
    result = {
        'id': inst['id'], 'instance_name': inst.get('instance_name',''),
        'environment': inst.get('environment',''), 'host': inst.get('host',''),
        'status': 'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'full_version': '—', 'major_version': '—', 'cu': '—',
        'instance_status': '—', 'agent_status': '—',
        'db_total': '—', 'db_online': '—',
        'edition': '—', 'os_version': '—', 'os_edition': '—',
        'sessions_current': '—', 'sessions_max': '—',
        'last_full_backup': '—', 'last_inc_backup': '—', 'last_arch_backup': '—',
    }

    host = inst.get('host','')
    try:
        port = int(inst.get('port', 1433))
    except ValueError:
        port = 1433

    start = datetime.datetime.now()
    try:
        sock = socket.create_connection((host, port), timeout=5)
        sock.close()
        result['response_ms'] = round((datetime.datetime.now()-start).total_seconds()*1000, 1)
    except Exception as e:
        result['status'] = 'critical'
        result['check_status'] = 'completed'
        result['error'] = f'TCP unreachable: {e}'
        return result

    username = inst.get('username','')
    password = decrypt_password(inst.get('password_enc',''))
    if not username or not password:
        result['status'] = 'warning'
        result['check_status'] = 'completed'
        result['error'] = 'No credentials configured'
        return result

    try:
        import pyodbc  # type: ignore
        conn_str = (
            f"DRIVER={{ODBC Driver 18 for SQL Server}};"
            f"SERVER={host},{port};UID={username};PWD={password};"
            f"Connection Timeout=10;TrustServerCertificate=yes;"
        )
        t0 = datetime.datetime.now()
        conn = pyodbc.connect(conn_str, timeout=15)
        result['response_ms'] = round((datetime.datetime.now()-t0).total_seconds()*1000, 1)
        cur = conn.cursor()

        cur.execute("SELECT @@VERSION, SERVERPROPERTY('ProductVersion'), SERVERPROPERTY('Edition'), SERVERPROPERTY('ProductUpdateLevel')")
        row = cur.fetchone()
        if row:
            result['full_version'] = str(row[0])[:120]
            ver = str(row[1])
            major = ver.split('.')[0]
            year_map = {'8':'2000','9':'2005','10':'2008','11':'2012',
                        '12':'2014','13':'2016','14':'2017','15':'2019','16':'2022'}
            result['major_version'] = year_map.get(major, major)
            result['edition'] = str(row[2]) if row[2] else '—'
            result['cu'] = str(row[3]) if row[3] else '—'

        cur.execute("SELECT state_desc FROM sys.databases WHERE name='master'")
        row = cur.fetchone()
        result['instance_status'] = 'ONLINE' if row and row[0]=='ONLINE' else 'ISSUE'

        try:
            cur.execute("SELECT status_desc FROM msdb.dbo.syssessions WHERE agent_id=0")
            row = cur.fetchone()
            result['agent_status'] = row[0] if row else 'Unknown'
        except:
            try:
                cur.execute("EXEC master..xp_servicecontrol 'QUERYSTATE','SQLSERVERAGENT'")
                row = cur.fetchone()
                result['agent_status'] = row[0] if row else '—'
            except:
                result['agent_status'] = 'N/A'

        cur.execute("SELECT COUNT(*), SUM(CASE WHEN state_desc='ONLINE' THEN 1 ELSE 0 END) FROM sys.databases")
        row = cur.fetchone()
        if row:
            result['db_total'] = row[0]
            result['db_online'] = row[1]

        cur.execute("SELECT @@MAX_CONNECTIONS, (SELECT COUNT(*) FROM sys.dm_exec_sessions WHERE is_user_process=1)")
        row = cur.fetchone()
        if row:
            result['sessions_max'] = row[0]
            result['sessions_current'] = row[1]

        try:
            cur.execute("""SELECT MAX(backup_finish_date) FROM msdb.dbo.backupset
                           WHERE type='D' AND database_name NOT IN ('master','model','msdb','tempdb')""")
            row = cur.fetchone()
            result['last_full_backup'] = str(row[0])[:16] if row and row[0] else 'Never'

            cur.execute("""SELECT MAX(backup_finish_date) FROM msdb.dbo.backupset
                           WHERE type='I' AND database_name NOT IN ('master','model','msdb','tempdb')""")
            row = cur.fetchone()
            result['last_inc_backup'] = str(row[0])[:16] if row and row[0] else 'Never'

            cur.execute("""SELECT MAX(backup_finish_date) FROM msdb.dbo.backupset
                           WHERE type='L' AND database_name NOT IN ('master','model','msdb','tempdb')""")
            row = cur.fetchone()
            result['last_arch_backup'] = str(row[0])[:16] if row and row[0] else 'Never'
        except:
            result['last_full_backup'] = result['last_inc_backup'] = result['last_arch_backup'] = 'N/A'

        try:
            cur.execute("SELECT host_distribution, host_release FROM sys.dm_os_host_info")
            row = cur.fetchone()
            if row:
                result['os_version'] = str(row[1])
                result['os_edition'] = str(row[0])
        except:
            pass

        cur.close(); conn.close()
        result['status'] = 'healthy'
        result['check_status'] = 'completed'
        result['message'] = 'Connected successfully'

    except ImportError:
        result['status'] = 'reachable'
        result['check_status'] = 'completed'
        result['error'] = 'TCP OK. Install pyodbc for full check.'
    except Exception as e:
        result['status'] = 'critical'
        result['check_status'] = 'completed'
        result['error'] = str(e)[:300]

    return result
