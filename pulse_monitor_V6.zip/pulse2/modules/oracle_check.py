"""Oracle health check — TNS alias-based connection, comprehensive metrics."""
import os, re, socket, datetime
from config_store import decrypt_password

def _set_oracle_env(db):
    if db.get('oracle_home'):
        os.environ['ORACLE_HOME'] = db['oracle_home']
        lib = os.path.join(db['oracle_home'], 'lib')
        existing = os.environ.get('LD_LIBRARY_PATH', '')
        os.environ['LD_LIBRARY_PATH'] = f"{lib}:{existing}" if existing else lib
    if db.get('tns_admin'):
        os.environ['TNS_ADMIN'] = db['tns_admin']

def _parse_version(banner):
    """Extract clean version like 19.0.0.0.0 from Oracle banner string."""
    if not banner:
        return '—'
    # Match 'Release 19.0.0.0.0' pattern
    m = re.search(r'Release\s+([\d]+\.[\d]+\.[\d]+\.[\d]+\.[\d]+)', banner)
    if m:
        return m.group(1)
    # Fallback: any x.y.z.w.v pattern
    m = re.search(r'(\d+\.\d+\.\d+\.\d+\.\d+)', banner)
    if m:
        return m.group(1)
    # Fallback: x.y.z
    m = re.search(r'(\d+\.\d+\.\d+)', banner)
    if m:
        return m.group(1)
    return banner[:30]

def _run_query(cur, sql, params=None):
    """Run query, return first row or None — never raises."""
    try:
        cur.execute(sql, params or [])
        return cur.fetchone()
    except Exception:
        return None

def check_oracle(db):
    result = {
        'id': db['id'],
        'db_name':    db.get('db_name', ''),
        'environment':db.get('environment', ''),
        'tns_alias':  db.get('tns_alias', ''),
        'status':     'unknown',
        'check_status':'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'db_version':      '—',
        'db_size_gb':      '—',
        'instance_status': '—',
        'startup_time':    '—',
        'worst_ts_pct':    '—',
        'worst_ts_name':   '—',
        'sessions_current':'—',
        'sessions_max':    '—',
        'last_full_inc_backup': '—',   # merged column
        'last_arch_backup':     '—',
    }

    _set_oracle_env(db)
    tns_alias = db.get('tns_alias', '')
    username  = db.get('username', '')
    password  = decrypt_password(db.get('password_enc', ''))

    if not tns_alias:
        result['status'] = 'critical'
        result['check_status'] = 'completed'
        result['error'] = 'No TNS alias configured'
        return result

    if not username or not password:
        result['status'] = 'warning'
        result['check_status'] = 'completed'
        result['error'] = 'No credentials configured'
        return result

    conn = None
    try:
        try:
            import oracledb as drv  # type: ignore
            try:
                drv.init_oracle_client(lib_dir=db.get('oracle_home') or None)
            except Exception:
                pass
        except ImportError:
            try:
                import cx_Oracle as drv  # type: ignore
            except ImportError:
                result['status'] = 'unknown'
                result['check_status'] = 'completed'
                result['error'] = 'Install oracledb or cx_Oracle for full check.'
                return result

        t0 = datetime.datetime.now()
        conn = drv.connect(user=username, password=password, dsn=tns_alias)
        result['response_ms'] = round((datetime.datetime.now() - t0).total_seconds() * 1000, 1)
        cur = conn.cursor()

        # ── Version
        row = _run_query(cur, "SELECT BANNER FROM V$VERSION WHERE BANNER LIKE 'Oracle%' AND ROWNUM=1")
        result['db_version'] = _parse_version(row[0] if row else None)

        # ── Instance status + startup time
        row = _run_query(cur, "SELECT STATUS, TO_CHAR(STARTUP_TIME,'YYYY-MM-DD HH24:MI') FROM V$INSTANCE")
        if row:
            result['instance_status'] = row[0] or '—'
            result['startup_time']    = row[1] or '—'

        # ── DB size
        row = _run_query(cur, "SELECT ROUND(SUM(BYTES)/1073741824, 2) FROM DBA_DATA_FILES")
        if row and row[0] is not None:
            result['db_size_gb'] = f"{row[0]} GB"

        # ── Sessions: current user sessions / max sessions
        row = _run_query(cur, "SELECT COUNT(*) FROM V$SESSION WHERE TYPE='USER'")
        current_sessions = row[0] if row else 0

        row2 = _run_query(cur, "SELECT TO_NUMBER(VALUE) FROM V$PARAMETER WHERE NAME='sessions'")
        max_sessions = row2[0] if row2 and row2[0] else '—'

        result['sessions_current'] = current_sessions
        result['sessions_max']     = max_sessions

        # ── Worst tablespace %
        ts_sql = """
            SELECT ts_name, pct_used FROM (
                SELECT d.TABLESPACE_NAME ts_name,
                       ROUND((NVL(t.BYTES_USED,0) / NULLIF(d.BYTES,0)) * 100, 1) pct_used
                FROM (SELECT TABLESPACE_NAME, SUM(BYTES) BYTES FROM DBA_DATA_FILES
                      GROUP BY TABLESPACE_NAME) d
                LEFT JOIN (SELECT TABLESPACE_NAME, SUM(BYTES_USED) BYTES_USED
                           FROM DBA_TEMP_FREE_SPACE GROUP BY TABLESPACE_NAME
                           UNION ALL
                           SELECT TABLESPACE_NAME,
                                  SUM(BYTES) - SUM(FREE_BLOCKS * BLOCK_SIZE)
                           FROM V$TEMP_EXTENT_POOL GROUP BY TABLESPACE_NAME) t
                  ON d.TABLESPACE_NAME = t.TABLESPACE_NAME
                ORDER BY 2 DESC NULLS LAST
            ) WHERE ROWNUM = 1"""

        # Simpler fallback approach
        ts_sql_simple = """
            SELECT a.TABLESPACE_NAME,
                   ROUND((1 - SUM(a.BYTES) / SUM(b.BYTES)) * 100, 1) PCT
            FROM (SELECT TABLESPACE_NAME, BYTES FROM DBA_FREE_SPACE) a
            JOIN (SELECT TABLESPACE_NAME, BYTES FROM DBA_DATA_FILES) b
              ON a.TABLESPACE_NAME = b.TABLESPACE_NAME
            GROUP BY a.TABLESPACE_NAME
            ORDER BY PCT DESC
            FETCH FIRST 1 ROWS ONLY"""

        # Even simpler without FETCH (works on older Oracle)
        ts_sql_compat = """
            SELECT * FROM (
                SELECT a.TABLESPACE_NAME,
                       ROUND((1 - SUM(a.BYTES) / SUM(b.BYTES)) * 100, 1) PCT
                FROM DBA_FREE_SPACE a
                JOIN DBA_DATA_FILES b ON a.TABLESPACE_NAME = b.TABLESPACE_NAME
                GROUP BY a.TABLESPACE_NAME
                ORDER BY PCT DESC
            ) WHERE ROWNUM = 1"""

        row = _run_query(cur, ts_sql_compat)
        if row and len(row) >= 2 and row[1] is not None:
            result['worst_ts_name'] = row[0]
            result['worst_ts_pct']  = f"{row[1]}%"

        # ── Backups via V$RMAN_BACKUP_JOB_DETAILS (most reliable)
        # Full / Incremental — merged into one column
        bkp_full_sql = """
            SELECT TO_CHAR(MAX(END_TIME),'YYYY-MM-DD HH24:MI')
            FROM V$RMAN_BACKUP_JOB_DETAILS
            WHERE STATUS = 'COMPLETED'
              AND INPUT_TYPE IN ('DB FULL', 'DB INCR LEVEL 0')"""

        bkp_inc_sql = """
            SELECT TO_CHAR(MAX(END_TIME),'YYYY-MM-DD HH24:MI')
            FROM V$RMAN_BACKUP_JOB_DETAILS
            WHERE STATUS = 'COMPLETED'
              AND INPUT_TYPE = 'DB INCR'"""

        bkp_arch_sql = """
            SELECT TO_CHAR(MAX(END_TIME),'YYYY-MM-DD HH24:MI')
            FROM V$RMAN_BACKUP_JOB_DETAILS
            WHERE STATUS = 'COMPLETED'
              AND INPUT_TYPE LIKE 'ARCHIVELOG%'"""

        # Fallback to V$BACKUP_SET if V$RMAN_BACKUP_JOB_DETAILS not available
        bkp_full_fallback = """
            SELECT TO_CHAR(MAX(COMPLETION_TIME),'YYYY-MM-DD HH24:MI')
            FROM V$BACKUP_SET
            WHERE BACKUP_TYPE IN ('D','L0') AND STATUS='A'"""

        bkp_inc_fallback = """
            SELECT TO_CHAR(MAX(COMPLETION_TIME),'YYYY-MM-DD HH24:MI')
            FROM V$BACKUP_SET
            WHERE BACKUP_TYPE='I' AND STATUS='A'"""

        bkp_arch_fallback = """
            SELECT TO_CHAR(MAX(COMPLETION_TIME),'YYYY-MM-DD HH24:MI')
            FROM V$BACKUP_SET
            WHERE BACKUP_TYPE='L' AND STATUS='A'"""

        full_row = _run_query(cur, bkp_full_sql)
        if full_row is None or full_row[0] is None:
            full_row = _run_query(cur, bkp_full_fallback)

        inc_row = _run_query(cur, bkp_inc_sql)
        if inc_row is None or inc_row[0] is None:
            inc_row = _run_query(cur, bkp_inc_fallback)

        arch_row = _run_query(cur, bkp_arch_sql)
        if arch_row is None or arch_row[0] is None:
            arch_row = _run_query(cur, bkp_arch_fallback)

        full_ts = (full_row[0] if full_row else None) or 'Never'
        inc_ts  = (inc_row[0]  if inc_row  else None) or 'Never'
        # Merged Full/Inc column: show both
        result['last_full_inc_backup'] = f"Full:{full_ts} / Inc:{inc_ts}"
        result['last_arch_backup']     = (arch_row[0] if arch_row else None) or 'Never'

        cur.close()
        result['status']       = 'healthy'
        result['check_status'] = 'completed'
        result['message']      = 'Connected successfully'

    except Exception as e:
        result['status']       = 'critical'
        result['check_status'] = 'completed'
        result['error']        = str(e)[:300]
    finally:
        if conn:
            try:
                conn.close()
            except Exception:
                pass

    return result
