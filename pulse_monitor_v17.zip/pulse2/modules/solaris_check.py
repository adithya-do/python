"""Solaris server health check via SSH — uses Solaris-specific commands."""
import socket, datetime
from config_store import resolve_credentials

def check_solaris(srv):
    result = {
        'id': srv['id'], 'server_name': srv.get('server_name',''),
        'environment': srv.get('environment',''), 'host': srv.get('host',''),
        'ip_address': srv.get('host',''),
        'status': 'unknown', 'check_status': 'in_progress',
        'message': '', 'error': '',
        'checked_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'response_ms': None,
        'os': 'Solaris', 'os_version': '—',
        'memory_gb': '—', 'memory_usage_pct': '—',
        'cpu_count': '—', 'cpu_load_avg': '—',
        'worst_disk': '—', 'worst_disk_pct': '—',
        'uptime': '—',
    }

    host = srv.get('host','')
    try:   port = int(srv.get('ssh_port', 22))
    except: port = 22

    # TCP check
    start = datetime.datetime.now()
    try:
        sock = socket.create_connection((host, port), timeout=5)
        sock.recv(256)
        sock.close()
        result['response_ms'] = round((datetime.datetime.now()-start).total_seconds()*1000, 1)
    except Exception as e:
        result.update(status='critical', check_status='completed', error=f'SSH port unreachable: {e}')
        return result

    username, password = resolve_credentials(srv)
    key_path = srv.get('ssh_key_path','')

    try:
        import paramiko  # type: ignore
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        kwargs = dict(hostname=host, port=port, username=username, timeout=15)
        if key_path:  kwargs['key_filename'] = key_path
        elif password: kwargs['password'] = password
        client.connect(**kwargs)

        def run(cmd):
            _, out, _ = client.exec_command(cmd, timeout=10)
            return out.read().decode(errors='replace').strip()

        # OS version — Solaris-specific
        uname = run("uname -a")
        ver   = run("uname -r")       # e.g. 5.11
        result['os']         = 'Solaris'
        result['os_version'] = f"Solaris {ver}" if ver else uname[:40]

        # Uptime in days using /proc/uptime if available, fallback to uptime cmd
        uptime_raw = run("cat /proc/uptime 2>/dev/null | awk '{print $1}'")
        if uptime_raw and uptime_raw.replace('.','').isdigit():
            secs = float(uptime_raw)
            days  = int(secs // 86400)
            hours = int((secs % 86400) // 3600)
            mins  = int((secs % 3600)  // 60)
            result['uptime'] = f"{days}d {hours}h {mins}m" if days else f"{hours}h {mins}m"
        else:
            # Solaris uptime command
            ut = run("uptime")
            result['uptime'] = ut.split(',')[0].strip() if ut else '—'

        # CPU count (Solaris)
        ncpu = run("psrinfo -p 2>/dev/null | tail -1")
        if not ncpu or not ncpu.isdigit():
            ncpu = run("kstat -m cpu_info 2>/dev/null | grep -c 'module: cpu_info'")
        result['cpu_count'] = ncpu or '—'

        # Load average
        load = run("uptime | awk -F'average:' '{print $2}' | awk '{print $1}' | tr -d ','")
        result['cpu_load_avg'] = load or '—'

        # Memory (Solaris uses prtconf or kstat)
        mem_mb_str = run("prtconf 2>/dev/null | grep 'Memory size' | awk '{print $3}'")
        if mem_mb_str and mem_mb_str.isdigit():
            mem_mb = int(mem_mb_str)
            result['memory_gb'] = round(mem_mb / 1024, 1)
            # Used memory from kstat
            pages_total = run("kstat -m unix -n system_pages -s physmem 2>/dev/null | awk '{print $2}'")
            pages_free  = run("kstat -m unix -n system_pages -s freemem 2>/dev/null | awk '{print $2}'")
            try:
                pt = int(pages_total); pf = int(pages_free)
                used_pct = round((1 - pf/pt) * 100, 1)
                result['memory_usage_pct'] = f"{used_pct}%"
            except Exception:
                result['memory_usage_pct'] = '—'

        # Disk usage (Solaris df)
        df = run("df -k 2>/dev/null | awk 'NR>1 && $5~/[0-9]/ {print $5, $6}' | sort -rn | head -5")
        if df:
            for line in df.strip().split('\n'):
                parts = line.split()
                if len(parts) >= 2:
                    pct_str = parts[0].replace('%','')
                    try:
                        result['worst_disk']     = parts[1]
                        result['worst_disk_pct'] = f"{pct_str}%"
                        break
                    except Exception:
                        pass

        client.close()
        result.update(status='healthy', check_status='completed', message='SSH connected')

    except ImportError:
        result.update(status='reachable', check_status='completed',
                      error='SSH port open. Install paramiko for full metrics.')
    except Exception as e:
        result.update(status='warning', check_status='completed',
                      error=f'SSH error: {str(e)[:200]}')

    return result
